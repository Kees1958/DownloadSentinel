"use strict";

import { test, describe, beforeEach, afterEach } from "node:test";
import assert from "node:assert/strict";

import { installChromeMock, uninstallChromeMock } from "./helpers/chromeMock.js";
import { FilterDataLoader } from "../../EXTENSION/util/FilterDataLoader.js";
import { SuspiciousDomains } from "../../EXTENSION/util/SuspiciousDomains.js";
import { BrandDomains } from "../../EXTENSION/util/BrandDomains.js";
import { HostList } from "../../EXTENSION/util/HostList.js";
import { RiskyHostingSites } from "../../EXTENSION/util/RiskyHostingSites.js";
import { PublicSuffixList } from "../../EXTENSION/util/PublicSuffixList.js";
import { TopSitesFilter } from "../../EXTENSION/util/TopSitesFilter.js";
import { BloomFilter } from "../../EXTENSION/util/BloomFilter.js";

// No live network in this test file, ever — every test either never reaches
// fetchRemote() (fetch deliberately left undefined) or installs its own
// fully-synthetic globalThis.fetch stub.

let originalFetch;

beforeEach(() => {
    installChromeMock();
    originalFetch = globalThis.fetch;
});

afterEach(() => {
    FilterDataLoader.clear();
    uninstallChromeMock();
    if (originalFetch === undefined) delete globalThis.fetch;
    else globalThis.fetch = originalFetch;
});

describe("FilterDataLoader — shape validators (pure, no chrome.*)", () => {
    const v = FilterDataLoader._validators;

    test("validateArrayOfStrings accepts a non-empty string array", () => {
        assert.equal(v.validateArrayOfStrings(["a.com", "b.com"]), true);
    });
    test("validateArrayOfStrings rejects empty array, non-array, mixed types", () => {
        assert.equal(v.validateArrayOfStrings([]), false);
        assert.equal(v.validateArrayOfStrings("not-an-array"), false);
        assert.equal(v.validateArrayOfStrings(null), false);
        assert.equal(v.validateArrayOfStrings(["a.com", 123]), false);
    });

    test("validateObjectOfNumbers accepts a non-empty string->number map", () => {
        assert.equal(v.validateObjectOfNumbers({ "a.com": 10, "b.com": 20 }), true);
    });
    test("validateObjectOfNumbers rejects arrays, empty objects, non-number values", () => {
        assert.equal(v.validateObjectOfNumbers([]), false);
        assert.equal(v.validateObjectOfNumbers({}), false);
        assert.equal(v.validateObjectOfNumbers({ "a.com": "10" }), false);
        assert.equal(v.validateObjectOfNumbers(null), false);
    });

    test("validateRiskyHostingSitesShape accepts well-formed entries", () => {
        assert.equal(v.validateRiskyHostingSitesShape([{ host: "x.com", score: -10, exact: true }]), true);
    });
    test("validateRiskyHostingSitesShape rejects a missing/mistyped field", () => {
        assert.equal(v.validateRiskyHostingSitesShape([{ host: "x.com", score: -10 }]), false);
        assert.equal(v.validateRiskyHostingSitesShape([{ host: "x.com", score: "-10", exact: true }]), false);
        assert.equal(v.validateRiskyHostingSitesShape([]), false);
    });

    test("validateHostListShape accepts well-formed entries", () => {
        assert.equal(v.validateHostListShape({ "x.com": { score: 60, source: "Test" } }), true);
    });
    test("validateHostListShape rejects a malformed entry", () => {
        assert.equal(v.validateHostListShape({ "x.com": { score: "60", source: "Test" } }), false);
        assert.equal(v.validateHostListShape({ "x.com": { score: 60 } }), false);
    });

    test("validatePublicSuffixListShape accepts well-formed data, including empty wildcard/exceptions", () => {
        const wellFormed = { rules: Array(5000).fill("x").map((_, i) => `tld${i}`), wildcardRules: [], exceptions: [] };
        assert.equal(v.validatePublicSuffixListShape(wellFormed), true);
    });
    test("validatePublicSuffixListShape rejects too few rules, wrong types, missing keys", () => {
        assert.equal(v.validatePublicSuffixListShape({ rules: ["com"], wildcardRules: [], exceptions: [] }), false); // too few
        assert.equal(v.validatePublicSuffixListShape({ rules: "not-an-array", wildcardRules: [], exceptions: [] }), false);
        assert.equal(v.validatePublicSuffixListShape({ wildcardRules: [], exceptions: [] }), false); // missing rules
        assert.equal(v.validatePublicSuffixListShape(null), false);
        assert.equal(v.validatePublicSuffixListShape([]), false);
    });

    test("validateTopSitesFilterShape accepts well-formed data", () => {
        const wellFormed = { size: 1000, numHashes: 7, entryCount: 100_001, bitsBase64: "QQ==" };
        assert.equal(v.validateTopSitesFilterShape(wellFormed), true);
    });
    test("validateTopSitesFilterShape rejects too-few entries, wrong types, missing keys", () => {
        assert.equal(v.validateTopSitesFilterShape({ size: 1000, numHashes: 7, entryCount: 10, bitsBase64: "QQ==" }), false); // too few
        assert.equal(v.validateTopSitesFilterShape({ size: "1000", numHashes: 7, entryCount: 200_000, bitsBase64: "QQ==" }), false);
        assert.equal(v.validateTopSitesFilterShape({ numHashes: 7, entryCount: 200_000, bitsBase64: "QQ==" }), false); // missing size
        assert.equal(v.validateTopSitesFilterShape({ size: 1000, numHashes: 7, entryCount: 200_000, bitsBase64: "" }), false);
        assert.equal(v.validateTopSitesFilterShape(null), false);
        assert.equal(v.validateTopSitesFilterShape([]), false);
    });
});

describe("FilterDataLoader.refreshAll — remote fetch applied when valid", () => {
    test("a valid remote list is applied to the matching module, others fall back to default", async () => {
        globalThis.fetch = async (url) => {
            if (url.endsWith("/BrandDomains.json")) {
                return { ok: true, json: async () => ["totallyfake.com"] };
            }
            return { ok: false }; // every other source: fetch fails -> no cache -> stays on default
        };

        const results = await FilterDataLoader.refreshAll();
        assert.equal(results.BrandDomains, "remote");
        assert.ok(BrandDomains.set.has("totallyfake.com"));
        assert.equal(results.SuspiciousDomains, "default");
    });

    test("malformed remote JSON is rejected and the default is kept", async () => {
        globalThis.fetch = async (url) => {
            if (url.endsWith("/BrandDomains.json")) {
                return { ok: true, json: async () => ({ not: "an array" }) }; // wrong shape
            }
            return { ok: false };
        };

        const results = await FilterDataLoader.refreshAll();
        assert.equal(results.BrandDomains, "default");
        assert.ok(BrandDomains.set.has("amazon.com")); // bundled default still active
    });

    test("a network error (thrown fetch) never throws out of refreshAll", async () => {
        globalThis.fetch = async () => { throw new Error("network down"); };
        await assert.doesNotReject(() => FilterDataLoader.refreshAll());
    });

    test("falls back to a last-known-good cached copy when the fresh fetch fails", async () => {
        // First run: a good fetch, cached to chrome.storage.local.
        globalThis.fetch = async (url) => {
            if (url.endsWith("/HostList.json")) {
                return { ok: true, json: async () => ({ "cached-host.example": { score: 70, source: "Test" } }) };
            }
            return { ok: false };
        };
        let results = await FilterDataLoader.refreshAll();
        assert.equal(results.HostList, "remote");
        assert.ok(HostList.lookup("cached-host.example"));

        // Reset the in-memory module back to its default (simulating a
        // service-worker restart that re-imports a clean module instance,
        // without clearing chrome.storage.local — the cache survives).
        HostList.resetToDefault();
        assert.equal(HostList.lookup("cached-host.example"), null);

        // Second run: the live fetch now fails for everything; HostList
        // should recover from the cache written during the first run.
        globalThis.fetch = async () => ({ ok: false });
        results = await FilterDataLoader.refreshAll();
        assert.equal(results.HostList, "cached");
        assert.ok(HostList.lookup("cached-host.example"));
    });

    test("RiskyHostingSites array-of-objects shape round-trips through fetch -> validate -> apply", async () => {
        globalThis.fetch = async (url) => {
            if (url.endsWith("/RiskyHostingSites.json")) {
                return { ok: true, json: async () => ([{ host: "evil-host.example", score: -90, exact: true }]) };
            }
            return { ok: false };
        };
        await FilterDataLoader.refreshAll();
        const hit = RiskyHostingSites.lookup("evil-host.example");
        assert.ok(hit);
        assert.equal(hit.score, -90);
    });

    test("SuspiciousDomains falls back to default when fetch is entirely unavailable", async () => {
        delete globalThis.fetch;
        const results = await FilterDataLoader.refreshAll();
        assert.equal(results.SuspiciousDomains, "default");
        assert.ok(SuspiciousDomains.lookup("duckdns.org")); // bundled default entry still present
    });

    test("PublicSuffixList round-trips through fetch -> validate -> apply", async () => {
        globalThis.fetch = async (url) => {
            if (url.endsWith("/PublicSuffixList.json")) {
                return {
                    ok: true,
                    json: async () => ({
                        rules: Array(5000).fill("x").map((_, i) => `tld${i}`).concat(["example"]),
                        wildcardRules: [],
                        exceptions: [],
                    }),
                };
            }
            return { ok: false };
        };
        const results = await FilterDataLoader.refreshAll();
        assert.equal(results.PublicSuffixList, "remote");
        // "example" is now a registered rule in the fetched set, so
        // "sub.example" resolves against IT rather than the bundled
        // default's real-world rules.
        assert.equal(PublicSuffixList.getRegisteredDomain("sub.example"), "sub.example");
    });

    test("TopSitesFilter round-trips through fetch -> validate -> apply", async () => {
        const { size, numHashes } = BloomFilter.sizeFor(10, 0.01);
        const filter = BloomFilter.create(size, numHashes);
        filter.add("remote-fetched-domain.example");

        globalThis.fetch = async (url) => {
            if (url.endsWith("/TopSitesFilter.json")) {
                return {
                    ok: true,
                    json: async () => ({
                        size, numHashes, entryCount: 100_001, bitsBase64: filter.toBase64(),
                    }),
                };
            }
            return { ok: false };
        };
        const results = await FilterDataLoader.refreshAll();
        assert.equal(results.TopSitesFilter, "remote");
        assert.equal(TopSitesFilter.mightBeTopSite("remote-fetched-domain.example"), true);
    });
});

describe("FilterDataLoader.init / clear — idempotent lifecycle", () => {
    test("init() is safe to call more than once and only creates one alarm", async () => {
        globalThis.fetch = async () => ({ ok: false });
        const p1 = FilterDataLoader.init();
        const p2 = FilterDataLoader.init();
        assert.equal(p1, p2); // same in-flight/settled promise, not a second run
        await p1;
        assert.equal(FilterDataLoader.isInitialized(), true);

        let alarmCount = 0;
        const existing = await chrome.alarms.get("filterDataRefresh");
        if (existing) alarmCount++;
        assert.equal(alarmCount, 1);
    });

    test("clear() resets every extracted module back to its bundled default", async () => {
        globalThis.fetch = async (url) => {
            if (url.endsWith("/BrandDomains.json")) {
                return { ok: true, json: async () => ["custom-brand.example"] };
            }
            return { ok: false };
        };
        await FilterDataLoader.init();
        assert.ok(BrandDomains.set.has("custom-brand.example"));

        FilterDataLoader.clear();
        assert.equal(FilterDataLoader.isInitialized(), false);
        assert.ok(!BrandDomains.set.has("custom-brand.example"));
        assert.ok(BrandDomains.set.has("amazon.com"));
    });

    test("a second init() after clear() runs a fresh refresh", async () => {
        globalThis.fetch = async () => ({ ok: false });
        await FilterDataLoader.init();
        FilterDataLoader.clear();
        const p = FilterDataLoader.init();
        assert.ok(p instanceof Promise);
        await p;
        assert.equal(FilterDataLoader.isInitialized(), true);
    });
});

describe("FilterDataLoader — declared source coverage", () => {
    test("every extracted module is registered", () => {
        const expected = ["SuspiciousDomains", "SuspiciousTlds", "RiskyHostingSites", "HostList", "BrandDomains", "UrlShorteners", "PublicSuffixList", "TopSitesFilter"];
        assert.deepEqual([...FilterDataLoader._SOURCES].sort(), [...expected].sort());
    });
});
