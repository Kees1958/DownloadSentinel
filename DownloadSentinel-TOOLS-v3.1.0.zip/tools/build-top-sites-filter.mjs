#!/usr/bin/env node
"use strict";

// tools/build-top-sites-filter.mjs
//
// Regenerates EXTENSION/data/TopSitesFilter.json — a compact Bloom filter
// answering "is this registrable domain one of the web's most popular
// sites?" Built from the Chrome UX Report (CrUX) top-1,000,000-site list
// (real Chrome user-traffic data, mirrored as CSV on GitHub by
// zakird/crux-top-lists), reduced to registrable domains (name.tld) via the
// same real Public Suffix List this codebase now uses elsewhere
// (util/PublicSuffixList.js) — not the old naive "last two labels" rule,
// which would have silently merged every multi-label-TLD site (co.uk,
// com.br, co.jp, ...) into the wrong bucket.
//
// This is the data half of the lookalike-domain check: a download URL whose
// host is a character-substitution away from a real top-1M name (see
// EXTENSION/protection/FilenameUrlHeuristics.js's checkLookalikeTopSite) is
// a much stronger signal than an arbitrary hostname being "close" to
// nothing in particular.
//
// Why a Bloom filter and not a plain list: ~850K-950K unique registrable
// domains as raw strings would cost ~15-20MB; a Bloom filter at a 1%
// false-positive rate costs roughly 1-1.5MB (see CONFIG.FALSE_POSITIVE_RATE
// below) and NEVER false-negatives — if it says "not a top site", that is
// certain, which is exactly the property this check's design needs (it
// only ever treats a match as a signal to STRENGTHEN, never to clear, a
// suspicious URL — see the scoring note in FilenameUrlHeuristics.js).
//
// TOOLS/EXTENSION split (project convention — see update-lists.mjs,
// update-psl.mjs): this build-time script directly imports the EXTENSION
// runtime's own util/BloomFilter.js and util/PublicSuffixList.js modules
// (plain ES modules, no bundler needed under Node), so the exact same
// hashing code and suffix rules that built the filter are the ones that
// later query it — no risk of a hand-kept-in-sync second implementation
// drifting out of step.
//
// Usage:
//   node tools/build-top-sites-filter.mjs            — build from the cached raw CSV
//   node tools/build-top-sites-filter.mjs --fetch    — re-download the raw CSV.gz first

import { writeFileSync, readFileSync, mkdirSync, existsSync } from "node:fs";
import { execFileSync } from "node:child_process";
import { gunzipSync } from "node:zlib";
import path from "node:path";

import { repoPaths } from "./repoPaths.mjs";
import { BloomFilter } from "../../EXTENSION/util/BloomFilter.js";
import { PublicSuffixList } from "../../EXTENSION/util/PublicSuffixList.js";

const { TOOLS_ROOT, EXT_ROOT } = repoPaths(import.meta.url);

// ─────────────────────────────────────────────────────────────────────────────
// CONFIG — every magic number/path for this script gathered here, same
// project convention as tools/update-psl.mjs / tools/update-lists.mjs.
// ─────────────────────────────────────────────────────────────────────────────
const CONFIG = Object.freeze({
    SOURCE_URL: "https://raw.githubusercontent.com/zakird/crux-top-lists/main/data/global/current.csv.gz",
    RAW_FILE_GZ: path.join(TOOLS_ROOT, "tools", "lists-raw", "crux-top-sites.csv.gz"),
    OUT_FILE: path.join(EXT_ROOT, "data", "TopSitesFilter.json"),
    GEN_DEFAULTS_SCRIPT: path.join(TOOLS_ROOT, "tools", "gen-data-defaults.mjs"),

    // The real CrUX export is ~1,000,000 rows / ~8-9MB gzipped; a response
    // far smaller than this means a CDN error page or truncated transfer,
    // not the real list — refuse to build from it (mirrors
    // update-psl.mjs's MIN_PLAUSIBLE_BYTES guard).
    MIN_PLAUSIBLE_GZ_BYTES: 1_000_000,
    MIN_PLAUSIBLE_DOMAINS: 100_000,

    // Target false-positive rate for the built filter. 1% (not the
    // BloomFilter module's own stricter 0.1% default) is a deliberate
    // trade-off for THIS filter specifically: at ~900K entries, 0.1% would
    // cost roughly 1.6MB of filter bits vs. ~1.1MB at 1% — and a 1% false
    // positive here only ever means "treat this as if it coincidentally
    // resembled a popular site", which this check already scores as a weak,
    // non-blocking signal (see FilenameUrlHeuristics.js) — so the smaller,
    // cheaper-to-ship filter is the better trade for this use case.
    FALSE_POSITIVE_RATE: 0.01,
});

const SHOULD_FETCH = process.argv.includes("--fetch");

// ── Guard — ensure the raw-list cache directory exists before any write ────
function ensureRawDir() {
    const dir = path.dirname(CONFIG.RAW_FILE_GZ);
    if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
}

async function fetchRaw() {
    ensureRawDir();
    console.log("  fetching CrUX top-1M site list …");
    const response = await fetch(CONFIG.SOURCE_URL);
    if (!response.ok) {
        throw new Error(`fetch failed (HTTP ${response.status}) from ${CONFIG.SOURCE_URL}`);
    }
    const buf = Buffer.from(await response.arrayBuffer());
    if (buf.length < CONFIG.MIN_PLAUSIBLE_GZ_BYTES) {
        throw new Error(`response implausibly small (${buf.length} bytes) — refusing to use it`);
    }
    writeFileSync(CONFIG.RAW_FILE_GZ, buf);
}

function readRawCsv() {
    if (!existsSync(CONFIG.RAW_FILE_GZ)) {
        throw new Error(`no cached raw file at ${CONFIG.RAW_FILE_GZ} — run with --fetch first`);
    }
    const gz = readFileSync(CONFIG.RAW_FILE_GZ);
    if (gz.length < CONFIG.MIN_PLAUSIBLE_GZ_BYTES) {
        throw new Error(`cached raw file implausibly small (${gz.length} bytes)`);
    }
    return gunzipSync(gz).toString("utf8");
}

// ── Parse "origin,rank" CSV rows into a deduped Set of registrable domains ──
// e.g. "https://www.amazon.co.jp,1000" -> "amazon.co.jp". Uses the real
// Public Suffix List (not a fixed label count) so multi-label-TLD sites
// collapse to their correct registrable name rather than a shared,
// incorrect "co.jp"/"co.uk" bucket.
function extractRegisteredDomains(csvText) {
    const domains = new Set();
    const lines = csvText.split("\n");

    for (let i = 1; i < lines.length; i++) { // i=1: skip "origin,rank" header
        const line = lines[i].trim();
        if (!line) continue;

        const commaIndex = line.lastIndexOf(",");
        if (commaIndex < 0) continue; // malformed row — skip rather than throw
        const originStr = line.slice(0, commaIndex);

        let hostname;
        try {
            hostname = new URL(originStr).hostname.toLowerCase();
        } catch {
            continue; // unparseable origin — skip
        }

        const registered = PublicSuffixList.getRegisteredDomain(hostname);
        if (registered) domains.add(registered);
    }

    return domains;
}

// ── Main ─────────────────────────────────────────────────────────────────
async function main() {
    if (SHOULD_FETCH) await fetchRaw();
    const csvText = readRawCsv();
    const domains = extractRegisteredDomains(csvText);

    // Guard (same spirit as update-psl.mjs/update-lists.mjs) — refuse to
    // compile an implausibly small result into the extension rather than
    // silently shipping a near-empty filter.
    if (domains.size < CONFIG.MIN_PLAUSIBLE_DOMAINS) {
        throw new Error(`parsed implausibly few unique domains (${domains.size}) — refusing to write output`);
    }

    const { size, numHashes } = BloomFilter.sizeFor(domains.size, CONFIG.FALSE_POSITIVE_RATE);
    const filter = BloomFilter.create(size, numHashes);
    for (const domain of domains) filter.add(domain);

    const data = {
        size,
        numHashes,
        entryCount: domains.size,
        falsePositiveRate: CONFIG.FALSE_POSITIVE_RATE,
        bitsBase64: filter.toBase64(),
    };

    writeFileSync(CONFIG.OUT_FILE, JSON.stringify(data) + "\n", "utf8");
    console.log(`  TopSitesFilter.json written: ${domains.size} unique domains, ` +
                `${size} bits, ${numHashes} hashes, ${Math.round(data.bitsBase64.length / 1024)}KB base64`);

    execFileSync(process.execPath, [CONFIG.GEN_DEFAULTS_SCRIPT], { stdio: "inherit" });
}

main().catch((err) => {
    console.error(`build-top-sites-filter.mjs failed: ${err.message}`);
    process.exit(1);
});
