"use strict";

/**
 * TopSitesFilter.js
 *
 * "Is this registrable domain one of the web's most popular sites?" —
 * backed by a Bloom filter built from the Chrome UX Report (CrUX) top-1M
 * site list (real Chrome user-traffic data; see tools/build-top-sites-filter.mjs
 * for how EXTENSION/data/TopSitesFilter.json is built).
 *
 * This exists for one job: checkLookalikeTopSite() in
 * protection/FilenameUrlHeuristics.js generates a handful of
 * character-substitution variants of a download URL's host name-part (e.g.
 * "arnazon" -> "amazon" via the rn->m lookalike) and asks "does THIS
 * variant match a real top-1M name?" — a much stronger signal than the
 * hostname merely being unfamiliar.
 *
 * A Bloom filter never false-negatives (mightBeTopSite() returning false is
 * certain) but can false-positive at the ~1% rate it was built at (see
 * build-top-sites-filter.mjs's CONFIG.FALSE_POSITIVE_RATE) — so a true
 * result here is a "maybe", not a certainty, and callers must weight it
 * accordingly (this module intentionally has no scoring opinion of its
 * own; see FilenameUrlHeuristics.js's SCORING_CONFIG for that).
 *
 * Same init/setData/resetToDefault guard convention as PublicSuffixList.js
 * and the rest of the extracted-data modules: the active filter is rebuilt
 * wholesale, never mutated incrementally, so a refresh can never leave two
 * datasets' bits live at once.
 */
import { TopSitesFilterDefault } from "./TopSitesFilter.default.js";
import { BloomFilter } from "./BloomFilter.js";

export const TopSitesFilter = (function () {

    // ── In-memory state — rebuilt wholesale by setData()/resetToDefault() ──
    let filter = null;

    function loadFrom(data) {
        filter = BloomFilter.fromBase64(data.size, data.numHashes, data.bitsBase64);
    }
    loadFrom(TopSitesFilterDefault); // initial load — never queried with "no data yet"

    /**
     * @param {string} registeredDomain — a registrable domain (name.tld),
     *   e.g. from PublicSuffixList.getRegisteredDomain() — NOT a full
     *   hostname with subdomains, which this filter was never built on.
     * @returns {boolean} true = possibly a top-1M site (or a ~1% false
     *   positive); false = definitely not.
     */
    function mightBeTopSite(registeredDomain) {
        if (!registeredDomain || !filter) return false;
        return filter.has(registeredDomain.toLowerCase());
    }

    function setData(newData) {
        loadFrom(newData);
    }

    function resetToDefault() {
        loadFrom(TopSitesFilterDefault);
    }

    return { mightBeTopSite, setData, resetToDefault };
})();
