"use strict";

/**
 * PublicSuffixList.js
 *
 * The real registrable-domain (eTLD+1) extraction, backed by the actual
 * Public Suffix List (publicsuffix.org) — the same reference list every
 * major browser ships internally. Replaces the naive "always take the last
 * two labels" rule this codebase used before, which was silently wrong for
 * every multi-label suffix: "sub.example.co.uk" doesn't become
 * "example.co.uk", it becomes "co.uk" — and worse, a top-1M popularity
 * check found this affected ~19% of real-world multi-label-TLD hostnames
 * before this fix (see DOCS/CHANGELOG.md for the investigation).
 *
 * Algorithm (the standard PSL matching rule — see
 * https://publicsuffix.org/list/ "Format" / "Algorithm" sections):
 *   1. Split the hostname into labels and consider every trailing
 *      sub-sequence of labels as a candidate suffix, longest first.
 *   2. The first (= longest) candidate that exactly matches a plain rule,
 *      or whose one-label-shorter form matches a wildcard rule, wins —
 *      that candidate IS the public suffix.
 *   3. An exception rule (e.g. "!city.kawasaki.jp") carves an exact name
 *      back OUT of a wildcard match: the public suffix is one label
 *      shorter than the exception string itself.
 *   4. If nothing matches at all, the default rule applies: the public
 *      suffix is just the last label (this is what the old naive rule
 *      always assumed, and is still correct for the common case of an
 *      ordinary single-label TLD like .com/.net/.org/.de/.nl/...).
 * The registrable domain (eTLD+1) is the public suffix plus exactly one
 * more label to its left — or null if the hostname has no label to spare
 * (the hostname IS the suffix, e.g. "co.uk" or "com" on their own).
 *
 * DOCS/ARCHITECTURE.md, "Filter-data remote-update mechanism" — this list
 * lives in EXTENSION/data/PublicSuffixList.json (single source of truth;
 * see tools/update-psl.mjs to regenerate it from the upstream list) and
 * participates in the same bundled-default / remote-fetch / cache fallback
 * pattern as the other extracted data modules (see
 * util/FilterDataLoader.js). RULES/WILDCARD_RULES/EXCEPTIONS are rebuilt
 * fresh by setData()/resetToDefault() — no leftover state from a previous
 * dataset ever survives a refresh (the project's init/clear/release
 * convention applied to an in-memory Set rather than a chrome.* resource).
 */
import { PublicSuffixListDefault } from "./PublicSuffixList.default.js";

export const PublicSuffixList = (function () {

    // ── In-memory state — rebuilt wholesale by setData()/resetToDefault(),
    // never mutated incrementally, so there is never a stale mix of two
    // datasets' rules live at once.
    let RULES, WILDCARD_RULES, EXCEPTIONS;

    function loadFrom(data) {
        RULES          = new Set(data.rules);
        WILDCARD_RULES = new Set(data.wildcardRules);
        EXCEPTIONS     = new Set(data.exceptions);
    }
    loadFrom(PublicSuffixListDefault); // initial load — the guard that ensures a lookup is never done with "no data yet"

    /**
     * Extract the eTLD+1-style registered domain from a hostname, using the
     * real Public Suffix List rather than a fixed label count.
     * @param {string} hostname — lowercase, no scheme/port/path
     * @returns {string|null}
     */
    function getRegisteredDomain(hostname) {
        if (!hostname) return null;
        const labels = hostname.split(".");
        const n = labels.length;
        if (n < 2) return null;

        for (let i = 0; i < n; i++) {
            const candidate = labels.slice(i).join(".");

            if (EXCEPTIONS.has(candidate)) {
                return i + 1 < n ? labels.slice(i + 1).join(".") : null;
            }
            if (RULES.has(candidate) || WILDCARD_RULES.has(candidate)) {
                return i === 0 ? null : labels.slice(i - 1).join(".");
            }
        }

        // No rule matched at all — default rule: suffix is just the last
        // label (ordinary single-label TLD, the common case).
        return labels.slice(-2).join(".");
    }

    function setData(newData) {
        loadFrom(newData);
    }

    function resetToDefault() {
        loadFrom(PublicSuffixListDefault);
    }

    return { getRegisteredDomain, setData, resetToDefault };
})();
