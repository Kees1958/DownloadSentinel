"use strict";

import { test, describe, beforeEach, afterEach } from "node:test";
import assert from "node:assert/strict";
import { Quad9Protection } from "../../EXTENSION/protection/Quad9Protection.js";

// ── DNS wire-format test fixtures ───────────────────────────────────────────
// Hand-built binary DNS messages — the same wire format Quad9Protection.js
// now speaks (RFC 1035/8484) instead of the retired-in-practice JSON
// convenience format. Helpers here build just enough of a real response to
// exercise the parser; they intentionally don't reuse the module's own
// encoder, so a bug in one doesn't mask a matching bug in the other.

function u16(n) { return [(n >> 8) & 0xFF, n & 0xFF]; }

function encodeLabels(hostname) {
    const bytes = [];
    for (const label of hostname.split(".")) {
        const b = Buffer.from(label, "utf8");
        bytes.push(b.length, ...b);
    }
    bytes.push(0);
    return bytes;
}

// Builds a full DNS response message. `answers` is an array of
// { type, ttl?, rdata: number[] } — NAME in each answer record is always a
// compression pointer back to the question's QNAME at offset 12 (the
// overwhelmingly common real-world shape, and the one this module's reader
// must handle correctly since Quad9's own responses do this).
function buildResponse({ hostname, rcode = 0, authorityCount = 0, answers = [] }) {
    const qname = encodeLabels(hostname);
    const header = [
        0x00, 0x00,                 // ID
        0x81, 0x80 | (rcode & 0x0F), // flags: QR+RD+RA set, RCODE in low nibble
        ...u16(1),                  // QDCOUNT
        ...u16(answers.length),     // ANCOUNT
        ...u16(authorityCount),     // NSCOUNT
        ...u16(0),                  // ARCOUNT
    ];
    const question = [...qname, ...u16(1), ...u16(1)]; // QTYPE=A, QCLASS=IN
    const answerBytes = [];
    for (const a of answers) {
        answerBytes.push(0xC0, 0x0C); // NAME: compression pointer to offset 12 (start of QNAME)
        answerBytes.push(...u16(a.type));
        answerBytes.push(...u16(1));          // CLASS IN
        answerBytes.push(0, 0, 0, a.ttl ?? 60); // TTL (4 bytes, low byte only needed for test values)
        answerBytes.push(...u16(a.rdata.length));
        answerBytes.push(...a.rdata);
    }
    return new Uint8Array([...header, ...question, ...answerBytes]).buffer;
}

function cnameRdata(targetHostname) {
    return encodeLabels(targetHostname);
}

function fetchReturning(arrayBuffer, { ok = true, status = 200 } = {}) {
    return async () => ({ ok, status, arrayBuffer: async () => arrayBuffer });
}

let originalFetch;
beforeEach(() => { originalFetch = globalThis.fetch; });
afterEach(() => {
    if (originalFetch === undefined) delete globalThis.fetch;
    else globalThis.fetch = originalFetch;
});

describe("Quad9Protection.check — wire-format DoH (RFC 8484)", () => {
    test("ALLOWED: a NOERROR response with an A record resolves normally", async () => {
        globalThis.fetch = fetchReturning(buildResponse({
            hostname: "example.com",
            answers: [{ type: 1, rdata: [93, 184, 216, 34] }],
        }));
        const r = await Quad9Protection.check("example.com");
        assert.equal(r.status, "ALLOWED");
        assert.equal(r.score, 0);
        assert.deepEqual(r.answers, ["93.184.216.34"]);
    });

    test("ALLOWED: an AAAA record is decoded to colon-separated hex groups", async () => {
        const v6 = [0x26, 0x06, 0x28, 0x00, 0x02, 0x20, 0x00, 0x01, 0, 0, 0, 0, 0, 0, 0x6c, 0x46];
        globalThis.fetch = fetchReturning(buildResponse({
            hostname: "example.com",
            answers: [{ type: 28, rdata: v6 }],
        }));
        const r = await Quad9Protection.check("example.com");
        assert.equal(r.status, "ALLOWED");
        assert.equal(r.answers[0], "2606:2800:220:1:0:0:0:6c46");
    });

    test("ALLOWED: a CNAME record's target name is decoded", async () => {
        globalThis.fetch = fetchReturning(buildResponse({
            hostname: "www.example.com",
            answers: [{ type: 5, rdata: cnameRdata("example.com") }],
        }));
        const r = await Quad9Protection.check("www.example.com");
        assert.equal(r.status, "ALLOWED");
        assert.deepEqual(r.answers, ["example.com"]);
    });

    test("BLOCKED: NXDOMAIN with zero Authority records is Quad9's block signal", async () => {
        globalThis.fetch = fetchReturning(buildResponse({
            hostname: "malware.example",
            rcode: 3, authorityCount: 0, answers: [],
        }));
        const r = await Quad9Protection.check("malware.example");
        assert.equal(r.status, "BLOCKED");
        assert.equal(r.score, -100);
    });

    test("UNKNOWN/NXDOMAIN: NXDOMAIN with Authority records present is a genuine non-existent name", async () => {
        globalThis.fetch = fetchReturning(buildResponse({
            hostname: "totally-made-up-xyz.example",
            rcode: 3, authorityCount: 1, answers: [],
        }));
        const r = await Quad9Protection.check("totally-made-up-xyz.example");
        assert.equal(r.status, "UNKNOWN");
        assert.equal(r.reasonCode, "NXDOMAIN");
        assert.equal(r.score, 0);
    });

    test("UNKNOWN/NO_ANSWER: NOERROR with zero answer records", async () => {
        globalThis.fetch = fetchReturning(buildResponse({ hostname: "example.com", answers: [] }));
        const r = await Quad9Protection.check("example.com");
        assert.equal(r.status, "UNKNOWN");
        assert.equal(r.reasonCode, "NO_ANSWER");
    });

    test("UNKNOWN/NO_ANSWER: an answer record of a type we don't handle (e.g. TXT) yields no usable answers", async () => {
        globalThis.fetch = fetchReturning(buildResponse({
            hostname: "example.com",
            answers: [{ type: 16, rdata: [5, 104, 101, 108, 108, 111] }], // TXT "hello"
        }));
        const r = await Quad9Protection.check("example.com");
        assert.equal(r.status, "UNKNOWN");
        assert.equal(r.reasonCode, "NO_ANSWER");
    });

    test("UNKNOWN/REQUEST_FAILED: a non-OK HTTP status", async () => {
        globalThis.fetch = fetchReturning(new ArrayBuffer(0), { ok: false, status: 500 });
        const r = await Quad9Protection.check("example.com");
        assert.equal(r.status, "UNKNOWN");
        assert.equal(r.reasonCode, "REQUEST_FAILED");
    });

    test("UNKNOWN/REQUEST_FAILED: a 200 OK response whose body isn't a valid DNS message", async () => {
        globalThis.fetch = fetchReturning(new Uint8Array([1, 2, 3]).buffer); // shorter than a DNS header
        const r = await Quad9Protection.check("example.com");
        assert.equal(r.status, "UNKNOWN");
        assert.equal(r.reasonCode, "REQUEST_FAILED");
    });

    test("UNKNOWN/TIMEOUT: an aborted request maps to the timeout reason, not a generic error", async () => {
        globalThis.fetch = async (url, { signal } = {}) => {
            const err = new DOMException("The operation was aborted", "AbortError");
            if (signal?.aborted) throw err;
            throw err; // this module's own AbortController always aborts the real request in this path
        };
        const r = await Quad9Protection.check("example.com");
        assert.equal(r.status, "UNKNOWN");
        assert.equal(r.reasonCode, "TIMEOUT");
    });

    test("UNKNOWN/ERROR: a generic network failure (TypeError: Failed to fetch) is reported, not swallowed", async () => {
        globalThis.fetch = async () => { throw new TypeError("Failed to fetch"); };
        const r = await Quad9Protection.check("example.com");
        assert.equal(r.status, "UNKNOWN");
        assert.equal(r.reasonCode, "ERROR");
        assert.match(r.label, /Failed to fetch/);
    });

    test("the request URL carries a base64url-encoded wire-format query, not the old name=/type= JSON params", async () => {
        let capturedUrl;
        globalThis.fetch = async (url) => {
            capturedUrl = url;
            return { ok: true, status: 200, arrayBuffer: async () => buildResponse({ hostname: "example.com", answers: [] }) };
        };
        await Quad9Protection.check("example.com");
        assert.ok(capturedUrl.startsWith("https://dns.quad9.net/dns-query?dns="));
        assert.ok(!capturedUrl.includes("name="));
        assert.ok(!capturedUrl.includes("type="));

        // Decode the dns= param back to bytes and confirm it's a well-formed
        // wire-format query for "example.com" (QDCOUNT=1, QNAME present).
        const b64url = capturedUrl.split("dns=")[1];
        const b64 = b64url.replace(/-/g, "+").replace(/_/g, "/");
        const bytes = Buffer.from(b64, "base64");
        assert.equal(bytes.readUInt16BE(4), 1); // QDCOUNT === 1
        // QNAME starts at byte 12: length-prefixed labels "example", "com", then 0x00
        assert.equal(bytes[12], 7);  // "example".length
        assert.equal(bytes.slice(13, 20).toString("ascii"), "example");
        assert.equal(bytes[20], 3);  // "com".length
        assert.equal(bytes.slice(21, 24).toString("ascii"), "com");
        assert.equal(bytes[24], 0);  // root label terminator
    });

    test("an invalid hostname (empty) does not throw and resolves to UNKNOWN", async () => {
        globalThis.fetch = async () => { throw new Error("should not be called"); };
        const r = await Quad9Protection.check("");
        assert.equal(r.status, "UNKNOWN");
    });
});
