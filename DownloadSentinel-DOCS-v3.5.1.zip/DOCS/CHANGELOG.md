# Changelog — DownloadSentinel

Short, per-release summary of what changed. The full technical account is CHANGELOG_HISTORY.md.

## 3.5.1
- Hosting-platform list refreshed (Public Suffix List of 2026-10-25), and 13 platforms with non-English names
  (e.g. `günstigbestellen.de`) are now actually recognised — they were stored in a form that never matched.
- Tools: the Manifest V3 check comment now refers to 3P Matrix 4.4.0 (file identical in both projects).

## 3.5.0
- **Downloads are now judged as a whole journey, not as a pile of separate points.**
  - **Ordinary vendor deliveries are recognised.** When a file comes from a vendor's own download servers
    (Microsoft, Mozilla, Google, Gen Digital/CCleaner/Avast, Steam, Discord's app installer, Brave, Adobe,
    JetBrains, Opera, NVIDIA, Spotify), the usual quirks of such a download no longer count against it: a
    different referring page, no extension in the link, a short link, or a link shared in a chat. They are
    still listed on the warning page, in grey, with "normal for … downloads". A CCleaner download: from
    −50 to 0 ("probably safe"). Only real vendor servers count, never a name containing "cdn" or "download".
  - **Several small oddities together now add up.** On their own they are everyday noise; three of them
    together (e.g. a link from webmail + a two-month-old domain + an unrelated referrer) now count in full.
    On file-sharing sites (Discord, Dropbox, GitHub raw, …) two are enough.
  - **New small signal: "link opened from a chat or webmail page"** (Gmail, Outlook, Discord chat, WhatsApp
    Web, Telegram Web, Teams, Slack).
  - **Established, well-known sites get a small bonus** when nothing about the sender or the file is wrong.
  - **The false-positive setting now changes how the extension reasons**, not just how hard it scores:
    High and Medium recognise vendor deliveries and need 4 / 3 small oddities; Low and None count everything
    and need 2.
  - Mirror networks (VideoLAN, LibreOffice, SourceForge) that switch to plain HTTP, and SourceForge's own
    "latest download" links, are recognised as such.
- Examples at the default setting: a Discord-attachment program from a chat link −12 → −32, a PowerShell
  script from raw GitHub via a chat −25 → −44, a webmail link to a two-month-old domain −12 → −32 (all now
  "suspicious"); VLC from an HTTP mirror and 7-Zip via SourceForge's download link are no longer "suspicious".
- Warning page: the reputation box now always gives the verdict with the count ("2 heuristic risk signals
  detected — probably suspicious"); a single weak signal no longer says "probably suspicious" when it is only
  inconclusive.
- Warning page: dashes and quotes in messages are no longer dropped ("was hidden — no extension").
- **False-positive setting "High" no longer halves every warning signal** when VirusTotal does not know the
  download. High now gets its fewer alarms from the smarter rules above (recognised vendor deliveries, more small
  oddities needed); halving on top made real deception slip through. A PowerShell script from raw GitHub via a
  chat now scores −44 and a fake `invoice.pdf` that is really a program −45 at High (were −22, "inconclusive").
  Legitimate downloads stay quiet.
- Tools: the Manifest V3 check is now one identical file in DownloadSentinel and 3P Matrix.
- Country-code list for domain age refreshed from IANA (2026-10-22): `.sc` added (73 codes).
- **A page and a download host of the same company are no longer called "unrelated"** (e.g. discord.com →
  cdn.discordapp.com, github.com → objects.githubusercontent.com, ccleaner.com → avcdn.net).
- **New combination: "file on a file-sharing platform + link opened from a chat or webmail"** — the classic lure
  (e.g. a `Nitro_Generator.exe` on Discord's file host clicked in a Discord chat: now −35, "suspicious").
- Includes everything from 3.4.0 (not released separately).

## 3.4.0 (not released separately — included in 3.5.0)
- **Files that hide what they are now get checked.** A download with no extension anywhere (link and file name)
  that the server only calls "binary data" (`application/octet-stream` and similar) used to pass unchecked. It
  now always opens the warning page (−15), even with "Silent when probably safe" on. Trigger: a URLhaus malware
  sample on Discord's CDN (`…/6962f1be0c`, 80 MB, octet-stream) on 2026-10-24.
  If the finished download turns out to have an ordinary name (e.g. `clip.mp4`), nothing is shown.
- **Risky hosting now counts for those files too**: such a file from Discord's CDN scores −15 + −20 together
  instead of slipping through.
- **Name and type must agree**: `invoice.pdf` served as a program or as an archive is now flagged (−45).
  Formats that really are zip files (Word, OpenDocument, e-books, Python wheels, …) are not.
- **Fewer false alarms — signal weights reviewed now that signals add up:**
  - "Extension hidden at download start" −50 → −20. Vendor download links (Microsoft, Mozilla, Google, Adobe,
    CCleaner) work this way; a CCleaner installer went from −50 "Suspicious" to −20 "Inconclusive".
  - Plain HTTP −40 → −25, name/type mismatch −60 → −45, look-alike of a popular site −45 → −35.
- **Nine correctly served file types no longer count as a "type mismatch"**, e.g. `.deb`, `.rpm`, `.apk`,
  `.xpi`, `.sh`, `.iso`, `.AppImage` sent with their official type.
- An `.exe` sent as `application/force-download` is no longer a false "type mismatch".
- Tools: new Manifest V3 compliance check (`npm run mv3`) and the false-positive sweep, both now part of
  `npm run check`; the sweep also tests hidden-extension and plain-HTTP versions of every known-good download.

## 3.3.1
- **Two new DNS checks: DNS4EU Protective and CleanBrowsing Security** (both free, malware and phishing only).
  The DNS checks now offer **two of five**: Quad9, Cloudflare Security, Control D, DNS4EU, CleanBrowsing.
- **In France the default is now Control D + Cloudflare Security (1.1.1.2)** instead of Quad9 + Control D.
  A DNS choice you saved is never changed.
- Options: shorter DNS text.
- DNS4EU and CleanBrowsing **ask for permission only when you pick them** — updating needs no new approval.
  The permission is dropped again when neither DNS check uses them. If it is missing, the warning page says
  "not checked — permission not granted", never "safe".
- Note: DNS4EU also applies court-ordered blocks (e.g. piracy sites); such a site can show as blocked too.
