"use strict";

// ── WarningPage.js ────────────────────────────────────────────────────────────
// Warning page controller — renders the combined VT + heuristics risk report
// for a single download.
//
// Architecture: single-render pass (V2.0+). background.js waits for all checks
// before opening the page; we fetch the record once and render everything.
// A VT_RESULT_UPDATE push message is also handled for the SUBMIT_URL_TO_VT
// flow (user requests fresh VT scan from the warning page).
//
// Public interface: none (self-contained IIFE, runs on load)
//
// Dependencies:
//   util/AppConstants.js          — APP
//   util/MessageTypes.js          — MSG
//   util/Settings.js              — Settings.get
//   util/UrlUtils.js              — UrlUtils.toVtUrlId
//   protection/ScoringEngineV2.js — SCORING_CONFIG (thresholds for colour coding)
//
// State owned by this module:
//   currentVtScore   {number|null}  — most recent VT score received
//   currentHostScore {number|null}  — host-reputation score
//   lastHostData     {object|null}  — last full host-reputation result
//   lastVtData       {object|null}  — last full VT data received
// ─────────────────────────────────────────────────────────────────────────────

import { APP } from "../../util/AppConstants.js";
import { MSG } from "../../util/MessageTypes.js";
import { Settings } from "../../util/Settings.js";
import { UrlUtils } from "../../util/UrlUtils.js";
import { SCORING_CONFIG } from "../../protection/ScoringEngineV2.js";

// ── Quad9 UNKNOWN display text ──────────────────────────────────────────────
// Single source of truth mapping each Quad9Protection UNKNOWN_REASON code
// (protection/Quad9Protection.js) to the line shown in the Heuristics box.
// Keep this table in sync with that module's UNKNOWN_REASON enum — add a new
// entry here whenever a new code is added there. Any code not present in this
// table (including a missing/undefined reasonCode) falls back to
// QUAD9_UNKNOWN_FALLBACK, so a future/unrecognised code never renders blank.
const QUAD9_UNKNOWN_TEXT = Object.freeze({
    NO_THREAT_DATA: "No threat-intel data at DNS Quad9 for this host",
    REQUEST_FAILED: "Quad9 lookup failed (service error)",
    NXDOMAIN:       "Domain name does not exist (NXDOMAIN)",
    NO_ANSWER:      "Quad9 returned no DNS records for this host",
    TIMEOUT:        "Quad9 lookup timed out",
    ERROR:          "Quad9 lookup failed (network error)"
});
const QUAD9_UNKNOWN_FALLBACK = "Could not verify at DNS Quad9";

(function () {

    // ── Setup ──────────────────────────────────────────────────────────────────

    const params     = new URLSearchParams(location.search);
    const downloadId = Number(params.get("downloadId"));

    if (!downloadId) {
        document.body.innerHTML = "<p style='color:white;padding:2rem'>Invalid warning page — no download ID found.</p>";
        throw new Error("[DownloadSentinel] WarningPage opened without a valid downloadId");
    }

    // ── DOM refs ───────────────────────────────────────────────────────────────

    const reasonText            = document.getElementById("reasonText");
    const srcUrl                = document.getElementById("srcUrl");

    const hostBox               = document.getElementById("hostBox");
    const hostResult            = document.getElementById("hostResult");
    const hostLabel             = document.getElementById("hostLabel");

    const combinedDetailsBox    = document.getElementById("combinedDetailsBox");
    const vtSectionHeader       = document.getElementById("vtSectionHeader");
    const vtUnknownLine         = document.getElementById("vtUnknownLine");
    const vtDetailsList         = document.getElementById("vtDetailsList");
    const vtClassificationLine  = document.getElementById("vtClassificationLine");
    const heuristicsBox         = document.getElementById("heuristicsBox");
    const hostDetailsList       = document.getElementById("hostDetailsList");

    const worstScoreBox         = document.getElementById("worstScoreBox");
    const worstScoreValue       = document.getElementById("worstScoreValue");
    const worstScoreBarFill     = document.getElementById("worstScoreBarFill");
    const scoreExplanation      = document.getElementById("scoreExplanation");

    const btnOk                 = document.getElementById("btn-ok");
    const btnVt                 = document.getElementById("btn-vt");
    const disclaimer            = document.getElementById("disclaimerText");

    // ── Module-level state ─────────────────────────────────────────────────────
    // All declared with let so strict mode does not create implicit globals.

    let currentVtScore   = null;  // most recent VT axis score
    let currentHostScore = null;  // host-reputation axis score
    let lastHostData     = null;  // last full host-reputation result object
    let lastVtData       = null;  // last full VT data received

    // ── Settings ───────────────────────────────────────────────────────────────

    function applySettings(settings) {
        const r = settings.warningColorR ?? 179;
        const g = settings.warningColorG ?? 38;
        const b = settings.warningColorB ?? 30;
        document.body.style.backgroundColor = `rgb(${r}, ${g}, ${b})`;

        const titleEl = document.getElementById("warningTitle");
        if (titleEl) {
            // Use APP constant as fallback so the default lives in one place.
            // User-supplied titles are plain text (textContent); the default
            // constant is a known-safe string so innerHTML is used to allow
            // a <br> line break if the default title warrants one.
            const custom = (settings.warningTitle || "").trim();
            if (custom) {
                titleEl.textContent = custom;
            } else {
                titleEl.innerHTML = APP.WARNING_TITLE_DEFAULT;
            }
        }
    }

    Settings.get(applySettings);

    // ── VT URL ID helper ───────────────────────────────────────────────────────
    // Now imported from UrlUtils.js (util/UrlUtils.js is in web_accessible_resources
    // alongside the other util/ modules this page already imports — see manifest.json).
    // Previously duplicated here because that wasn't the case yet (jscpd-flagged
    // duplicate, audit pass) — no behavior change, same encoding.

    // ── Disclaimer ─────────────────────────────────────────────────────────────
    // Set after the record arrives so we can tailor the text to what actually ran.
    //   vtApiKeySet + vtScore known  → VT ran and returned data
    //   vtApiKeySet + vtScore null   → VT ran but URL was unknown to VT
    //   !vtApiKeySet                 → VT was not configured; heuristics only
    //
    // PRIVACY NOTE: every VT check this extension performs — both the automatic
    // one at download time and the SUBMIT_URL_TO_VT recheck (see background.js's
    // submitAndPollVt()) — submits only the download URL, never the downloaded
    // file itself. Uploading the actual file to a third party is a meaningfully
    // bigger privacy/exposure decision than checking a URL, so that step is left
    // entirely to the user: "Check download at VT" (btnVt) just opens
    // virustotal.com/hybrid-analysis.com in a new tab for the user to upload the
    // file manually if they choose to — this extension never does it for them.
    function renderDisclaimer(data) {
        if (!disclaimer) return;
        const vtRan     = data.vtApiKeySet;
        const vtUnknown = vtRan && data.vtScore === null;

        if (!vtRan) {
            // No API key — heuristics only
            disclaimer.textContent =
                "No VirusTotal API key is configured — results are based on heuristics only. " +
                "Add a free VT API key in Options for full URL reputation checks.";
            if (btnVt) btnVt.textContent = "Check download at VT";

        } else if (vtUnknown) {
            // VT has no record of this URL — direct user to Hybrid Analysis
            disclaimer.textContent =
                "Accept conditions, ignore e-mail requirement and select QUICK SCAN " +
                "for free hybrid analysis at METADEFENDER and CROWDSTRIKE, " +
                "before opening the downloaded file!";
            if (btnVt) btnVt.textContent = "Check download at Hybrid Analysis";

        } else {
            // VT returned results
            disclaimer.textContent =
                "This is what VirusTotal knows about the download URL. " +
                "When in doubt, upload the download itself at VirusTotal using the button.";
            if (btnVt) btnVt.textContent = "Check download at VT";
        }
    }

    // ── Score bar ──────────────────────────────────────────────────────────────

    function renderScoreBar(valueEl, fillEl, score) {
        const isPositive = score >= 0;
        const magnitude  = Math.min(100, Math.abs(score));
        valueEl.textContent = `${isPositive ? "+" : ""}${score}%`;
        valueEl.className   = "score-bar-value " + (isPositive ? "positive" : "negative");
        fillEl.className    = "score-bar-fill "  + (isPositive ? "positive" : "negative");
        fillEl.style.width  = `${magnitude}%`;
    }

    function confidenceLabel(score) {
        return `${score >= 0 ? "+" : ""}${score}%`;
    }

    function confidenceColor(score) {
        // Colour thresholds mirror SCORING_CONFIG so UI matches scoring logic
        if (score >= SCORING_CONFIG.THRESHOLD_SAFE)         return "#34d399"; // green
        if (score >= SCORING_CONFIG.THRESHOLD_QUESTIONABLE) return "#60a5fa"; // blue
        if (score >= SCORING_CONFIG.THRESHOLD_SUSPICIOUS)   return "#fbbf24"; // yellow
        return "#ef4444"; // red
    }

    function updateCombinedScore() {
        const hasVt   = currentVtScore   !== null;
        const hasHost = currentHostScore !== null;

        if (!hasVt && !hasHost) {
            worstScoreBox.style.display = "none";
            return;
        }

        const combined = Math.max(-100, Math.min(100,
            (hasVt   ? currentVtScore   : 0) +
            (hasHost ? currentHostScore : 0)
        ));

        worstScoreBox.style.display = "";
        renderScoreBar(worstScoreValue, worstScoreBarFill, combined);
        scoreExplanation.style.display = "none";

        // Colour the warning title to match the combined score category
        const titleEl = document.getElementById("warningTitle");
        if (titleEl) titleEl.style.color = confidenceColor(combined);

        // Colour the "Download URL Reputation" label
        if (hostLabel) hostLabel.className = "label label-" + vtScoreToStyle(combined);

        // VT confidence score row
        const vtScoreRow = document.getElementById("vtScoreRow");
        const vtScoreVal = document.getElementById("vtScoreValue");
        if (vtScoreRow && hasVt) {
            vtScoreRow.style.display = "";
            vtScoreVal.textContent   = confidenceLabel(currentVtScore);
            vtScoreVal.style.color   = confidenceColor(currentVtScore);
        }

        // Heuristics confidence score row
        const hostScoreRow      = document.getElementById("hostScoreRow");
        const hostConfidenceVal = document.getElementById("hostConfidenceValue");
        if (hostScoreRow && hasHost) {
            hostScoreRow.style.display    = "";
            hostConfidenceVal.textContent = confidenceLabel(currentHostScore);
            hostConfidenceVal.style.color = confidenceColor(currentHostScore);
        }
    }

    // ── Classification helpers ─────────────────────────────────────────────────

    function classifyToStyle(classification) {
        if (!classification)                          return "vt-unknown";
        if (classification.includes("Malicious"))     return "vt-malicious";
        if (classification.includes("Suspicious"))    return "vt-suspicious";
        if (classification.includes("Inconclusive") ||
            classification.includes("Questionable"))  return "vt-questionable";
        if (classification.includes("Safe"))          return "vt-safe";
        return "vt-unknown";
    }

    function vtScoreToStyle(score) {
        if (score === null || score === undefined)          return "vt-unknown";
        if (score >= SCORING_CONFIG.THRESHOLD_SAFE)         return "vt-safe";
        if (score >= SCORING_CONFIG.THRESHOLD_QUESTIONABLE) return "vt-questionable";
        if (score >= SCORING_CONFIG.THRESHOLD_SUSPICIOUS)   return "vt-suspicious";
        return "vt-malicious";
    }

    function vtClassificationText(score) {
        if (score === null || score === undefined)          return "";
        if (score >= SCORING_CONFIG.THRESHOLD_SAFE)         return "VirusTotal rates it currently as probably safe";
        if (score >= SCORING_CONFIG.THRESHOLD_QUESTIONABLE) return "VirusTotal rates it currently as probably inconclusive";
        if (score >= SCORING_CONFIG.THRESHOLD_SUSPICIOUS)   return "VirusTotal rates it currently as probably suspicious";
        return "VirusTotal rates it currently as probably malicious";
    }

    // ── Input sanitisation ─────────────────────────────────────────────────────
    // Labels come from background messages. Strip non-printable chars as a
    // guard against any future message spoofing.

    function sanitizeLabel(str) {
        if (typeof str !== "string") return "";
        return str.replace(/[^ -~À-ɏ]/g, "").slice(0, 200);
    }

    // ── Engine count row builder ───────────────────────────────────────────────

    function buildEngineCountsRow(stats, suffixHtml) {
        const harmless   = (stats.harmless   || 0) + (stats.undetected || 0);
        const unknown    =  stats.unknown    || 0;
        const suspicious =  stats.suspicious || 0;
        const malicious  =  stats.malicious  || 0;

        const frag = document.createDocumentFragment();
        function addCell(label, value, cls) {
            const lbl = document.createElement("span");
            lbl.className   = "ec-label";
            lbl.textContent = label;
            const num = document.createElement("span");
            num.className   = "ec-num " + cls;
            num.textContent = String(value);
            frag.appendChild(lbl);
            frag.appendChild(num);
        }
        addCell("Not harmful:", harmless,   "ec-harmless");
        addCell("Unknown:",     unknown,    "ec-unknown");
        addCell("Suspicious:",  suspicious, "ec-suspicious");
        addCell("Malicious:",   malicious,  "ec-malicious");

        // suffixHtml is always a hardcoded string or our own link — safe innerHTML
        const suffixSpan = document.createElement("span");
        suffixSpan.className = "ec-suffix";
        suffixSpan.innerHTML = suffixHtml;
        frag.appendChild(suffixSpan);
        return frag;
    }

    // ── VT rendering ──────────────────────────────────────────────────────────

    function renderVtDetails(data) {
        const vtUnknown      = !data.vtScore && data.vtDone;
        const vtEngineCounts = document.getElementById("vtEngineCounts");

        vtSectionHeader.style.display = "none";
        if (vtEngineCounts) vtEngineCounts.style.display = "none";

        vtDetailsList.innerHTML        = "";
        vtClassificationLine.style.display = "none";
        vtUnknownLine.style.display        = "none";

        if (vtUnknown) {
            vtUnknownLine.style.display      = "";
            vtUnknownLine.style.marginBottom = "12px";
            combinedDetailsBox.style.display = "";
            return;
        }

        if (!data.vtRawStats && !data.vtBreakdown) {
            combinedDetailsBox.style.display = "";
            return;
        }

        // ── Engine count bullets ──────────────────────────────────────────────
        const raw      = data.vtRawStats     || {};
        const filtered = data.vtFilteredStats || {};
        const fpLevel  = data.vtFpLevel || "NONE";

        if (raw.malicious !== undefined) {
            const li1 = document.createElement("li");
            li1.appendChild(buildEngineCountsRow(raw, "(all results)"));
            vtDetailsList.appendChild(li1);

            if (fpLevel !== "NONE" && data.vtFilteredStats) {
                const li2 = document.createElement("li");
                li2.appendChild(buildEngineCountsRow(filtered,
                    '<a class="fp-reduction-link" href="#" id="fpFilterLink">(with FP reduction)</a>'));
                vtDetailsList.appendChild(li2);

                setTimeout(() => {
                    const link = document.getElementById("fpFilterLink");
                    if (link) {
                        link.addEventListener("click", e => {
                            e.preventDefault();
                            chrome.runtime.openOptionsPage();
                        });
                    }
                }, 0);
            }
        }

        // ── Age bullet ────────────────────────────────────────────────────────
        if (data.vtBreakdown?.age?.ageDays !== null &&
            data.vtBreakdown?.age?.ageDays !== undefined) {
            const days = Math.round(data.vtBreakdown.age.ageDays);
            const li   = document.createElement("li");
            li.textContent = `First submitted to VT: ${days} day${days === 1 ? "" : "s"} ago`;
            vtDetailsList.appendChild(li);
        }

        // ── VT classification line ────────────────────────────────────────────
        if (data.vtBreakdown?.detection) {
            const classText      = vtClassificationText(data.vtScore);
            const topBoxIsVtText = lastHostData &&
                !(typeof lastHostData.score === "number" && lastHostData.score < 0);
            if (!topBoxIsVtText) {
                vtClassificationLine.textContent   = classText;
                vtClassificationLine.className     = "value details-classification " +
                    vtScoreToStyle(data.vtScore);
                vtClassificationLine.style.display = "";
            } else {
                vtClassificationLine.style.display = "none";
            }
        }

        combinedDetailsBox.style.display = "";
    }

    function renderVtScore(data) {
        if (typeof data.vtScore !== "number") {
            if (data.vtDone) {
                currentVtScore = null;
                if (lastHostData) renderHostReputation(lastHostData);
            }
            return;
        }
        currentVtScore = data.vtScore;
        updateCombinedScore();
        if (lastHostData) renderHostReputation(lastHostData);
    }

    function applyVtResult(data) {
        lastVtData = data;
        if (srcUrl)     srcUrl.textContent     = (data.url || "Unknown URL").split("?")[0].split("#")[0];
        if (reasonText) reasonText.textContent = data.ext ? "." + data.ext : "Unknown";
        renderVtScore(data);
        renderVtDetails(data);
    }

    // ── Host reputation rendering ──────────────────────────────────────────────

    function renderHostReputation(hostData) {
        if (!hostData) return;
        lastHostData = hostData;

        const vtUnknown = currentVtScore === null;

        if (hostData.score === null && !vtUnknown) {
            hostBox.style.display = "none";
            return;
        }

        hostBox.style.display = "";
        const hostIsNegative = typeof hostData.score === "number" && hostData.score < 0;
        const vtKnown        = currentVtScore !== null;

        const combined = Math.max(-100, Math.min(100,
            (vtKnown ? currentVtScore : 0) +
            (typeof hostData.score === "number" ? hostData.score : 0)
        ));

        if (vtKnown) {
            hostResult.textContent = vtClassificationText(combined);
            hostResult.className   = "value value-prominent " + vtScoreToStyle(combined);
        } else if (hostIsNegative) {
            hostResult.textContent = sanitizeLabel(hostData.label || hostData.classification || "See heuristics below");
            hostResult.className   = "value value-prominent " + classifyToStyle(hostData.classification);
        } else {
            hostResult.textContent = sanitizeLabel(hostData.label || hostData.classification || "See heuristics below");
            hostResult.className   = "value value-prominent " + classifyToStyle(hostData.classification);
        }

        if (typeof hostData.score === "number") {
            currentHostScore = hostData.score;
            updateCombinedScore();
        }

        combinedDetailsBox.style.display = "";
        hostDetailsList.innerHTML = "";

        // Quad9 — always shown here, regardless of VT's own status. UNKNOWN
        // gets its own reason-specific line (see QUAD9_UNKNOWN_TEXT above)
        // rather than one generic message or being silently skipped — a
        // timeout and "no threat-intel data for this host" are different
        // situations and neither is worded as a malware flag, since Quad9
        // gave no real verdict either way.
        if (hostData.quad9?.status) {
            const li = document.createElement("li");
            if (hostData.quad9.status === "BLOCKED") {
                li.textContent = "Domain is on Quad9 blacklist (confirmed malicious)";
            } else if (hostData.quad9.status === "ALLOWED") {
                li.textContent = "Not flagged as malware at DNS Quad9";
            } else {
                li.textContent = QUAD9_UNKNOWN_TEXT[hostData.quad9.reasonCode] || QUAD9_UNKNOWN_FALLBACK;
            }
            hostDetailsList.appendChild(li);
        }

        // Negative scoring rows only
        const rows = hostData.breakdown || [];
        for (const row of rows) {
            if (row.source === "Quad9") continue;
            if (row.score >= 0) continue;
            const li = document.createElement("li");
            li.textContent = sanitizeLabel(row.label);
            hostDetailsList.appendChild(li);
        }

        // RDAP domain-registration age — always shown here in the Heuristics
        // box (never in the VT box, regardless of whether VT has its own
        // first-seen data). Skipped only when RDAP's own hit was negative
        // enough to already appear above via the normal breakdown loop
        // ("New domain registration: ..."), so the age is never shown twice.
        if (hostData.rdap?.label && !rows.some(r => r.source === "RDAP")) {
            const li = document.createElement("li");
            li.textContent = `Domain registration age: ${sanitizeLabel(hostData.rdap.label)}`;
            hostDetailsList.appendChild(li);
        }

        if (heuristicsBox) heuristicsBox.style.display = "";

        if (hostDetailsList.children.length === 0) {
            const li = document.createElement("li");
            li.textContent = "Heuristics found no alarming signals";
            // Use CSS class instead of inline style (audit item A6)
            li.className = "host-signals-empty";
            hostDetailsList.appendChild(li);
        }
    }

    // ── Button handlers ───────────────────────────────────────────────────────

    btnOk?.addEventListener("click", () => {
        chrome.runtime.sendMessage(
            { type: MSG.DISMISS_CHECK, downloadId },
            () => window.close()
        );
    });

    btnVt?.addEventListener("click", () => {
        // VT unknown → send user to Hybrid Analysis for free sandbox analysis.
        // VT has results → open the direct VT detection page for this URL.
        // Fallback → VT homepage if the record has not arrived yet.
        const vtUnknown = lastVtData?.vtApiKeySet && lastVtData?.vtScore === null;
        let targetUrl;
        if (vtUnknown) {
            targetUrl = "https://hybrid-analysis.com/";
        } else if (lastVtData?.url) {
            targetUrl = `https://www.virustotal.com/gui/url/${UrlUtils.toVtUrlId(lastVtData.url)}/detection`;
        } else {
            targetUrl = "https://www.virustotal.com/gui/home/url";
        }
        chrome.runtime.sendMessage(
            { type: MSG.DISMISS_CHECK, downloadId },
            () => {
                chrome.tabs.create({ url: targetUrl });
                window.close();
            }
        );
    });

    // ── VT_RESULT_UPDATE push listener ────────────────────────────────────────
    // Handles fresh VT results pushed by background.js after SUBMIT_URL_TO_VT.
    // The submit+poll round trip in submitAndPollVt() (background.js) is short
    // — typically ~2-3 seconds — so nothing here needs its own progress/timer
    // UI; the update just arrives and this listener re-renders in place.

    chrome.runtime.onMessage.addListener((msg) => {
        if (msg.type !== MSG.VT_RESULT_UPDATE) return;
        if (msg.downloadId !== downloadId)     return;

        // Merge the pushed fields into a synthetic data object and re-render
        const merged = Object.assign({}, lastVtData || {}, {
            vtScore:         msg.vtScore         ?? null,
            vtConfidence:    msg.vtConfidence     ?? null,
            vtBreakdown:     msg.vtBreakdown      ?? null,
            vtHardRule:      msg.vtHardRule        ?? null,
            vtRawStats:      msg.vtRawStats        ?? null,
            vtFilteredStats: msg.vtFilteredStats   ?? null,
            vtFpLevel:       msg.vtFpLevel         ?? null,
            vtDone:          true,
        });
        applyVtResult(merged);
        renderDisclaimer(merged);
        if (lastHostData) renderHostReputation(lastHostData);
    });

    // ── Initial render ────────────────────────────────────────────────────────
    // In V2.0+ architecture background.js waits for all checks before opening
    // the warning page — fetch the record once and render in a single pass.

    chrome.runtime.sendMessage(
        { type: MSG.GET_PENDING_CHECK, downloadId },
        data => {
            if (!data) {
                if (document.body) document.body.style.opacity = "0.5";
                if (srcUrl) srcUrl.textContent = "Download no longer active — you can close this window.";
                return;
            }
            applyVtResult(data);
            renderDisclaimer(data);
            if (data.hostResult) renderHostReputation(data.hostResult);
        }
    );

})(); // end IIFE
