"use strict";

/**
 * Quad9Protection.js
 * Checks a hostname against Quad9's malware-blocking DNS-over-HTTPS resolver.
 *
 * If Quad9 returns NXDOMAIN (Status 3) with no Authority records, the domain
 * is actively blocked by Quad9's threat-intel feed → score −100.
 *
 * A result that is neither BLOCKED nor ALLOWED carries a `reasonCode` (see
 * UNKNOWN_REASON below) so callers can tell "no threat-intel data for this
 * host" apart from a timeout, an HTTP error, or NXDOMAIN — these are not
 * interchangeable and the UI shows each one differently.
 *
 * Adapted from CallQuad9.js for use as an ES module.
 */
import { APP } from "../util/AppConstants.js";

export const Quad9Protection = (function () {

    const QUAD9_DOH  = "https://dns.quad9.net/dns-query";
    const TIMEOUT_MS = APP.QUAD9_TIMEOUT_MS; // defined in AppConstants.js

    // ── UNKNOWN reason codes ────────────────────────────────────────────────
    // Single source of truth for *why* a check landed on UNKNOWN instead of
    // BLOCKED/ALLOWED. The UI (WarningPage.js) maps each code to its own
    // display text — never infer the reason from the free-text `reason`/
    // `label` string, which exists for logs/debugging only and may change
    // wording without notice.
    const UNKNOWN_REASON = Object.freeze({
        NO_THREAT_DATA: "NO_THREAT_DATA", // Quad9 has no block/allow signal for this host (HTTP 400)
        REQUEST_FAILED: "REQUEST_FAILED", // Quad9 API returned a non-OK, non-400 HTTP status
        NXDOMAIN:       "NXDOMAIN",       // Name genuinely doesn't exist (NXDOMAIN + Authority present)
        NO_ANSWER:      "NO_ANSWER",      // OK response but no usable A/AAAA/CNAME records
        TIMEOUT:        "TIMEOUT",        // Request aborted after TIMEOUT_MS with no response
        ERROR:          "ERROR"           // Network failure or other unexpected exception
    });

    /**
     * Query Quad9 DoH for a hostname.
     * @param {string} hostname
     * @param {AbortSignal} [signal]
     * @returns {Promise<{ status: "BLOCKED"|"ALLOWED"|"UNKNOWN", reasonCode?: string, reason?: string, answers?: string[] }>}
     */
    async function checkHostname(hostname, signal) {
        const url = `${QUAD9_DOH}?name=${encodeURIComponent(hostname)}&type=A`;

        const response = await fetch(url, {
            headers: { Accept: "application/dns-json" },
            signal
        });

        if (!response.ok) {
            // 400 typically means Quad9 has no threat-intel data for this TLD/domain
            // — treat as neutral (not blocked) rather than an error worth surfacing.
            if (response.status === 400) {
                return {
                    status:     "UNKNOWN",
                    reasonCode: UNKNOWN_REASON.NO_THREAT_DATA,
                    reason:     "Domain not flagged by Quad9"
                };
            }
            return {
                status:     "UNKNOWN",
                reasonCode: UNKNOWN_REASON.REQUEST_FAILED,
                reason:     `Quad9 request failed (${response.status})`
            };
        }

        const result = await response.json();

        // NXDOMAIN — domain either blocked or genuinely non-existent
        if (result.Status === 3) {
            // Quad9 heuristic: Authority count 0 → actively blocked by threat-intel
            //                  Authority count >0 → domain simply doesn't exist
            const isBlocked = !result.Authority || result.Authority.length === 0;
            if (isBlocked) {
                return {
                    status: "BLOCKED",
                    reason: "Domain blocked by Quad9 threat-intelligence feed"
                };
            }
            return {
                status:     "UNKNOWN",
                reasonCode: UNKNOWN_REASON.NXDOMAIN,
                reason:     "Domain does not exist (NXDOMAIN)"
            };
        }

        // No answer records at all
        if (!result.Answer || result.Answer.length === 0) {
            return {
                status:     "UNKNOWN",
                reasonCode: UNKNOWN_REASON.NO_ANSWER,
                reason:     "No DNS answer records returned"
            };
        }

        // Collect A / AAAA / CNAME records
        const answers = result.Answer
            .filter(a => a.type === 1 || a.type === 5 || a.type === 28)
            .map(a => a.data);

        if (answers.length === 0) {
            return {
                status:     "UNKNOWN",
                reasonCode: UNKNOWN_REASON.NO_ANSWER,
                reason:     "No A/AAAA/CNAME records found"
            };
        }

        return { status: "ALLOWED", answers };
    }

    /**
     * Public API: check a hostname with a hard timeout.
     *
     * Returns:
     *   { status, score, label, reason?, reasonCode?, answers? }
     *
     *   status "BLOCKED"  → score −100, label "Confirmed malicious"
     *   status "ALLOWED"  → score 0 (neutral; RDAP age will add its own signal)
     *   status "UNKNOWN"  → score 0 (no data, don't penalise); reasonCode is
     *                       always set to one of UNKNOWN_REASON's values so
     *                       the UI can distinguish timeout / HTTP error /
     *                       NXDOMAIN / no-data without parsing free text
     */
    async function check(hostname) {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort("timeout"), TIMEOUT_MS);

        try {
            const result = await checkHostname(hostname, controller.signal);
            clearTimeout(timer);

            if (result.status === "BLOCKED") {
                return {
                    status:  "BLOCKED",
                    score:   -100,
                    label:   "Confirmed malicious (blocked by Quad9)",
                    reason:  result.reason
                };
            }

            if (result.status === "ALLOWED") {
                return {
                    status:   "ALLOWED",
                    score:    0,
                    label:    "Resolved (not on Quad9 block list)",
                    answers:  result.answers
                };
            }

            // UNKNOWN — no usable verdict either way (see UNKNOWN_REASON for why)
            return {
                status:     "UNKNOWN",
                score:      0,
                label:      result.reason || "No Quad9 data",
                reasonCode: result.reasonCode || UNKNOWN_REASON.ERROR
            };

        } catch (err) {
            clearTimeout(timer);
            if (err.name === "AbortError") {
                return {
                    status:     "UNKNOWN",
                    score:      0,
                    label:      "Quad9 check timed out",
                    reasonCode: UNKNOWN_REASON.TIMEOUT
                };
            }
            return {
                status:     "UNKNOWN",
                score:      0,
                label:      `Quad9 error: ${err.message}`,
                reasonCode: UNKNOWN_REASON.ERROR
            };
        }
    }

    return { check };
})();
