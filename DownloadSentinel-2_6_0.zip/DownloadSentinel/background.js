// ── ES module imports ─────────────────────────────────────────────────────────
// Each imported module pulls in its own transitive dependencies (e.g.
// BrowserProtection.js imports ProtectionResult, MimeCheck, Quad9Protection,
// etc. itself) — background.js only imports what it references directly.
import { APP } from "./util/AppConstants.js";       // all magic numbers and timing values
import { MSG } from "./util/MessageTypes.js";        // all message-type string constants
import { Settings } from "./util/Settings.js";        // user preferences (read/write)
import { ScriptExts } from "./util/ScriptExts.js";      // ScriptExts.set / ScriptExts.list
import { DangerousExts } from "./util/DangerousExts.js";   // DANGEROUS/ARCHIVE/DECOY extension sets
import { DangerousMimes } from "./util/DangerousMimes.js"; // EXECUTABLE_MIMES + normalize()
import { UrlUtils } from "./util/UrlUtils.js";        // cleanUrl, getHostname, getTld, toVtUrlId
import { FpReductionEngines } from "./util/FpReductionEngines.js"; // filterResults, getRawStats
import { SCORING_CONFIG, ScoringEngineV2 } from "./protection/ScoringEngineV2.js"; // evaluate, evaluateHostReputation
import { BrowserProtection } from "./protection/BrowserProtection.js"; // checkIfUrlIsMalicious, checkHostReputation

// ─────────────────────────────────────────────────────────────────────────────
// background.js — Download Sentinel service worker
// ─────────────────────────────────────────────────────────────────────────────
//
// Public interface (message router — see onMessage switch below):
//   MSG.GET_PENDING_CHECK   — return pendingChecks record for downloadId
//   MSG.DISMISS_CHECK       — clean up a completed check
//   MSG.EXTENSION_TOGGLE    — update extension icon
//   MSG.SETTINGS_UPDATED    — reload custom domains
//   MSG.SUBMIT_URL_TO_VT    — submit URL for fresh VT analysis and poll
//
// STATE OVERVIEW — for troubleshooting service worker restarts and races
// ─────────────────────────────────────────────────────────────────────────────
//
// STATELESS (recomputed fresh every call, safe across SW restarts):
//   - DANGEROUS_EXTS, ARCHIVE_EXTS  → Sets from util/DangerousExts.js (DS-H009)
//   - EXECUTABLE_MIMES              → Set from util/DangerousMimes.js (DS-H008)
//   - BUILTIN_DO_NOT_CHECK_DOMAINS  → from util/AppConstants.js
//     → static constants, never mutated
//   - getBlockedExtension(), isTrustedDomain(), buildVtBlockReason()
//     → pure functions, no shared state
//
// STATEFUL — IN-MEMORY ONLY (lost on every SW restart, ~30s idle timeout):
//   - pendingChecks (Map)         → NOT persisted. If SW restarts while a
//                                    download is in-flight, the check is simply
//                                    lost — onChanged will still fire when the
//                                    download completes, but with no pending
//                                    record it will be treated as a new check.
//                                    Safe: worst case user sees warning a few
//                                    seconds later than optimal.
//   - runtimeCustomDomains (let)  → reloaded from chrome.storage.local on every
//                                    SW startup via loadCustomDomains().
//
// STATEFUL — PERSISTED (chrome.storage):
//   - chrome.storage.local["Settings"]
//       User preferences (API key, FP level, custom domains, etc). Survives
//       browser restarts and extension updates. Read via Settings.get().
//
// ARCHITECTURE — V2.0+:
//   Two-listener model. No pause/resume/cancel. Download always completes.
//   Download Sentinel is an information/warning tool, not a blocker.
//
//   onCreated  → start VT + Quad9 + RDAP calls, record startedAt timestamp
//   onChanged  → download complete: wait remaining budget (APP.VT_WAIT_BUDGET_MS
//                - elapsed), run heuristics, calculate score, show warning or
//                auto-proceed
//
// ─────────────────────────────────────────────────────────────────────────────

// ─────────────────────────────────────────────────────────────────────────────
// TIMER & WAIT-STATE REFERENCE
// ─────────────────────────────────────────────────────────────────────────────
//
// background.js
//   APP.VT_WAIT_BUDGET_MS          Total budget from startedAt to when we
//                                   give up waiting for VT in onChanged.
//                                   See AppConstants.js for breakdown.
//
//   APP.SWEEP_ALARM_NAME / _PERIOD  chrome.alarms recurring. Removes pendingChecks
//                                   entries older than APP.ENTRY_MAX_AGE_MS.
//
// BrowserProtection.js
//   APP.VT_FETCH_TIMEOUT_MS        AbortController timeout on the VT API GET.
//   APP.VT_FETCH_STARTUP_DELAY_MS  Small pause before VT fetch.
//
// ─────────────────────────────────────────────────────────────────────────────

// ─────────────────────────────────────────────────────────────────────────────
// GUARDS REFERENCE
// ─────────────────────────────────────────────────────────────────────────────
//
// ── State guards ─────────────────────────────────────────────────────────────
//   checkedIds (Set)          onChanged dedup — onChanged can fire multiple
//                              times for the same download. This Set prevents
//                              double-processing. Cleaned up in onErased.
//                              Bounded: entries removed in onErased and DISMISS_CHECK;
//                              sweep removes orphaned entries via sweepStaleEntries().
//
// ── No loop guards needed ────────────────────────────────────────────────────
//   The architecture never calls pause()/resume(), so there is no
//   resume → onCreated loop to guard against.
//
// ─────────────────────────────────────────────────────────────────────────────

"use strict";

// ── Static extension lists ────────────────────────────────────────────────────

// DS-H009: normalized (lowercase, no leading dot) Sets — single source of
// truth is now util/DangerousExts.js. Kept under these same names to avoid
// touching every call site; every call site below was converted from
// Array.includes() to Set.has() to match (see individual edits).
const DANGEROUS_EXTS = DangerousExts.DANGEROUS.set;
const ARCHIVE_EXTS   = DangerousExts.ARCHIVE.set;
const DECOY_EXTS     = DangerousExts.DECOY.set; // DS-H003 — believable decoy extensions

// Script extensions — single source of truth in util/ScriptExts.js
const SCRIPT_EXTS = ScriptExts.set;

// DS-H008: derived from the shared MIME↔extension map — see
// util/DangerousMimes.js for why this is derived rather than hand-listed.
const EXECUTABLE_MIMES = DangerousMimes.EXECUTABLE_MIMES;

// Built-in trusted domains — single source of truth is APP.BUILTIN_DO_NOT_CHECK_DOMAINS
// in AppConstants.js, shared with OptionsPage.js so the UI always reflects reality.
const BUILTIN_DO_NOT_CHECK_DOMAINS = APP.BUILTIN_DO_NOT_CHECK_DOMAINS;

let runtimeCustomDomains = [];
// NOTE: runtimeCustomDomains is reloaded on onStartup, onInstalled, AND at
// module load. The module-load call handles the case where the SW wakes via
// an alarm without firing either startup event.

// ── pendingChecks ─────────────────────────────────────────────────────────────
// Keyed by downloadId. Holds the async check results while the download runs.
// In-memory only — see STATE OVERVIEW above for why this is acceptable.
// Bounded: swept every APP.SWEEP_ALARM_PERIOD_MINUTES, max age APP.ENTRY_MAX_AGE_MS.
// Max concurrent entries is naturally limited by browser download concurrency.
const pendingChecks = new Map();
const checkedIds    = new Set(); // dedup guard for onChanged — see GUARDS REFERENCE

// ── Helper functions ──────────────────────────────────────────────────────────

function getExtFromFilename(file) {
    const parts   = file.split(".");
    if (parts.length < 2) return null;
    const lastTwo = parts.slice(-2).join(".");
    const lastOne = parts[parts.length - 1];
    if (ARCHIVE_EXTS.has(lastTwo))   return lastTwo;
    if (DANGEROUS_EXTS.has(lastOne)) return lastOne;
    if (ARCHIVE_EXTS.has(lastOne))   return lastOne;
    return null;
}

// Lightweight, unfiltered "what's the last extension segment" helper — unlike
// getExtFromFilename (which only returns dangerous/archive extensions, by
// design, since it gates what gets monitored), this returns ANY extension so
// it can be used purely for category comparison (see getExtCategory /
// getObfuscationSignal — DS-H007). Never used to decide whether to monitor a
// download, only to describe what category a filename's extension implies.
function getRawExt(filename) {
    if (!filename) return null;
    const base  = filename.toLowerCase().split("/").pop().split("\\").pop();
    const parts = base.split(".");
    return parts.length > 1 ? parts[parts.length - 1] : null;
}

function extractFilenameFromUrl(url) {
    try {
        const path  = new URL(url).pathname;
        const parts = path.split("/");
        const last  = parts[parts.length - 1];
        return last.includes(".") ? decodeURIComponent(last) : null;
    } catch { return null; }
}

// ── Deceptive extension chain detector (DS-H003) ────────────────────────────────
// Detects filenames where a dangerous extension is hidden behind one or more
// decoy extensions anywhere earlier in the chain — not just the immediately
// preceding label. Examples: "invoice.pdf.exe", "invoice.pdf.zip.exe",
// "document.pdf...desktop".
//
// Returns { decoy, dangerous, repeatedDots } or null if no deceptive chain
// is found. Only triggers when the FINAL extension is dangerous; standard
// compound formats (tar.gz, package-1.2.3.deb, library.min.js) must not
// trigger — see the curated DECOY_EXTS set in util/DangerousExts.js, which
// replaces the old "decoy = anything not dangerous/archive" heuristic that
// false-positived on things like "library.min.js" ("min" was never a real
// decoy extension).
function getDoubleExtension(filename) {
    if (!filename) return null;
    const base  = filename.toLowerCase().split("/").pop().split("\\").pop();
    const parts = base.split(".");
    // Need at least three parts: name + at least one decoy + dangerous
    if (parts.length < 3) return null;

    const dangerous = parts[parts.length - 1];
    if (!DANGEROUS_EXTS.has(dangerous)) return null;

    // Preceding segments — everything between the basename and the final
    // (dangerous) extension. May contain empty entries from repeated dots
    // (e.g. "document.pdf...desktop" → ["document","pdf","","","desktop"]).
    const precedingSegments = parts.slice(1, -1);
    const repeatedDots      = precedingSegments.some(seg => seg.length === 0);

    // Find the first believable decoy among the preceding segments, scanning
    // from the one closest to the dangerous extension outward — that's the
    // one doing the actual visual deception (e.g. in "invoice.pdf.zip.exe"
    // either "pdf" or "zip" is a valid decoy; either is a correct answer).
    let decoy = null;
    for (let i = precedingSegments.length - 1; i >= 0; i--) {
        const seg = precedingSegments[i];
        if (seg && DECOY_EXTS.has(seg)) { decoy = seg; break; }
    }
    if (!decoy) return null; // no recognizable decoy — likely a legitimate compound extension

    return { decoy: "." + decoy, dangerous, repeatedDots };
}

function getBlockedExtension(url, filename) {
    if (filename) {
        const ext = getExtFromFilename(filename.toLowerCase());
        if (ext) return ext;
    }
    if (url) {
        const fromUrl = extractFilenameFromUrl(url);
        if (fromUrl) {
            const ext = getExtFromFilename(fromUrl.toLowerCase());
            if (ext) return ext;
        }
    }
    return null;
}

// ── Extension category classifier ─────────────────────────────────────────────
// Maps a file extension to its risk category string.
// Used to detect category changes between onCreated and onChanged (DS-H007).
//   "launcher"    — .desktop
//   "script"      — ScriptExts (checked before "executable" so interpreted
//                   scripts get their own category rather than the generic
//                   executable bucket)
//   "executable"  — remaining DANGEROUS_EXTS (exe, dll, msi, scr, ...)
//   "archive"     — ARCHIVE_EXTS
//   "document"/"image"/"audio-video" — DangerousExts.DECOY sub-categories;
//                   these are informational categories only, never monitored
//                   at download-creation time on their own
//   "none"        — not a recognized extension in any of the above
//
// IMPORTANT: getObfuscationSignal() below only fires when toCategory is NOT
// "none" — i.e. only when the CONFIRMED (final) extension lands in one of
// the categories above. Adding document/image/audio-video categories here
// does not loosen that gate: those categories only matter as a *source*
// category (fromCategory) for a more accurate transition label — e.g.
// "document → script" instead of the old generic "hidden extension"
// wording — they were never a trigger condition on their own.
function getExtCategory(ext) {
    if (!ext) return "none";
    if (ext === "desktop")        return "launcher";
    if (ScriptExts.set.has(ext))  return "script";
    if (DANGEROUS_EXTS.has(ext))  return "executable";
    if (ARCHIVE_EXTS.has(ext))    return "archive";
    if (DangerousExts.DECOY.documents.has(ext)) return "document";
    if (DangerousExts.DECOY.images.has(ext))    return "image";
    if (DangerousExts.DECOY.media.has(ext))     return "audio-video";
    return "none";
}

// ── Obfuscation signal builder ────────────────────────────────────────────────
// Compares the extension known at onCreated time with the confirmed extension
// from onChanged and returns an obfuscation descriptor, or null if clean.
//
//   UNKNOWN_REVEALED  : no extension at creation → dangerous ext confirmed
//   CATEGORY_CHANGED  : extension known but switched risk category
//   null              : no obfuscation (same category, or no change)
function getObfuscationSignal(originalExt, confirmedExt) {
    if (!confirmedExt) return null; // still no ext — nothing to report

    const fromCategory = getExtCategory(originalExt);
    const toCategory   = getExtCategory(confirmedExt);

    if (toCategory === "none") return null; // confirmed ext is not dangerous

    if (!originalExt || fromCategory === "none") {
        // Extension was completely hidden at creation time
        return {
            type:         "UNKNOWN_REVEALED",
            confirmedExt,
            fromCategory: "none",
            toCategory
        };
    }

    if (fromCategory !== toCategory) {
        // Extension was known but changed risk category
        return {
            type:         "CATEGORY_CHANGED",
            originalExt,
            confirmedExt,
            fromCategory,
            toCategory
        };
    }

    return null; // same category — no obfuscation penalty
}

function getAllDoNotCheckDomains() {
    return [...BUILTIN_DO_NOT_CHECK_DOMAINS, ...runtimeCustomDomains];
}

function isTrustedDomain(url) {
    try {
        const hostname = new URL(url).hostname.toLowerCase();
        return getAllDoNotCheckDomains().some(d =>
            hostname === d || hostname.endsWith("." + d)
        );
    } catch { return false; }
}

function setExtensionIcon(enabled) {
    const suffix = enabled ? "" : "_OFF";
    chrome.action.setIcon({
        path: {
            "16":  chrome.runtime.getURL(`assets/icons/icon16${suffix}.png`),
            "24":  chrome.runtime.getURL(`assets/icons/icon24${suffix}.png`),
            "32":  chrome.runtime.getURL(`assets/icons/icon32${suffix}.png`),
            "48":  chrome.runtime.getURL(`assets/icons/icon48${suffix}.png`),
            "128": chrome.runtime.getURL(`assets/icons/icon128${suffix}.png`)
        }
    }).catch(err => console.warn("[DS] setIcon failed:", err?.message));
}

function loadCustomDomains() {
    Settings.get(settings => {
        runtimeCustomDomains = Array.isArray(settings.customDomains)
            ? settings.customDomains : [];
        setExtensionIcon(settings.extensionEnabled !== false);
    });
}

function openWarningPage(downloadId) {
    chrome.windows.create({
        url:   chrome.runtime.getURL(`pages/warning/WarningPage.html?downloadId=${downloadId}`),
        type:  "popup",
        state: "maximized"
    }).catch(err => {
        // If the popup fails to open, log and clean up — user cannot act on it
        console.error("[DS] openWarningPage failed:", err?.message);
        pendingChecks.delete(downloadId);
        checkedIds.delete(downloadId);
        BrowserProtection.abandonPendingRequests(downloadId, "warning page open failed");
    });
}

// ── Startup ───────────────────────────────────────────────────────────────────

chrome.runtime.onStartup.addListener(loadCustomDomains);
chrome.runtime.onInstalled.addListener(loadCustomDomains);
loadCustomDomains();

// ── Sweep stale entries ───────────────────────────────────────────────────────

function sweepStaleEntries() {
    const cutoff = Date.now() - APP.ENTRY_MAX_AGE_MS;
    for (const [id, item] of pendingChecks) {
        if ((item.startedAt || 0) < cutoff) {
            pendingChecks.delete(id);
            checkedIds.delete(id);
            BrowserProtection.abandonPendingRequests(id, "stale entry swept");
        }
    }
    // Also sweep any checkedIds orphaned by a SW restart (no matching pendingCheck)
    for (const id of checkedIds) {
        if (!pendingChecks.has(id)) {
            checkedIds.delete(id);
        }
    }
}

chrome.alarms.create(APP.SWEEP_ALARM_NAME, { periodInMinutes: APP.SWEEP_ALARM_PERIOD_MINUTES });
chrome.alarms.onAlarm.addListener(alarm => {
    if (alarm.name === APP.SWEEP_ALARM_NAME) sweepStaleEntries();
});

// ─────────────────────────────────────────────────────────────────────────────
// onCreated — start API checks immediately, record timestamp
// ─────────────────────────────────────────────────────────────────────────────

chrome.downloads.onCreated.addListener(async downloadItem => {

    const settings = await new Promise(resolve => Settings.get(resolve));
    if (!settings.extensionEnabled) return;

    const url = downloadItem.finalUrl || downloadItem.url || "";
    if (!url) return;
    if (isTrustedDomain(url)) return;

    const ext        = getBlockedExtension(url, downloadItem.filename || "")
                    || getBlockedExtension(downloadItem.url || "", "");
    const isArchive  = ext && ARCHIVE_EXTS.has(ext);
    const isDangerous = ext && DANGEROUS_EXTS.has(ext);
    const mime       = DangerousMimes.normalize(downloadItem.mime);
    const isMimeExec = !isDangerous && !isArchive && EXECUTABLE_MIMES.has(mime);

    if (!isDangerous && !isArchive && !isMimeExec) return;

    const fileType = (isDangerous || isMimeExec) ? "executable" : "archive";
    const isScript = SCRIPT_EXTS.has(ext);
    const isLinuxLauncher = ext === "desktop"; // DS-H001

    // Record startedAt BEFORE API calls so the budget covers all setup time
    const record = {
        id:         downloadItem.id,
        startedAt:  Date.now(),
        url,
        originalUrl: (downloadItem.url && downloadItem.url !== url) ? downloadItem.url : url,
        ext,
        fileType,
        isScript,
        filename:   downloadItem.filename   || "",
        mime:       downloadItem.mime        || "",
        totalBytes: downloadItem.totalBytes  || 0,

        // VT result — filled when check completes
        vtDone:          false,
        vtScore:         null,
        vtConfidence:    null,
        vtBreakdown:     null,
        vtHardRule:      null,
        vtRawStats:      null,
        vtFilteredStats: null,
        vtFpLevel:       null,

        // Host result — filled when check completes
        hostDone:   false,
        hostResult: null,

        // Download metadata for new heuristics
        // (danger field removed — Chrome Safe Browsing already blocks/warns on
        //  serious cases before our warning page opens; redundant to re-score it)

        // Settings snapshot for use in onChanged
        fpLevel:            settings.fpReductionLevel ?? "MEDIUM",
        autoAllow:          !!settings.autoAllow,
        autoAllowThreshold: settings.autoAllowThreshold ?? APP.AUTO_ALLOW_THRESHOLD_DEFAULT,
        vtApiKeySet:        !!(settings.isVtApiKeySet && settings.vtApiKey),
    };

    pendingChecks.set(downloadItem.id, record);

    // ── A. Host reputation (fast, no API key needed) ──────────────────────
    BrowserProtection.checkHostReputation(
        url, fileType, ext, record.mime, record.totalBytes, record.originalUrl, isScript,
        null,                                   // obfuscation — not yet known at creation time
        getDoubleExtension(downloadItem.filename || ""), // double-extension check
        isLinuxLauncher
    ).then(hostResult => {
        const r = pendingChecks.get(downloadItem.id);
        if (!r) return;
        r.hostDone   = true;
        r.hostResult = hostResult;
    });

    // ── B. VT check ───────────────────────────────────────────────────────
    if (!settings.isVtApiKeySet || !settings.vtApiKey) {
        record.vtDone = true; // no key — treat as done immediately
        return;
    }

    BrowserProtection.checkIfUrlIsMalicious(downloadItem.id, url, result => {
        const r = pendingChecks.get(downloadItem.id);
        if (!r) return;
        r.vtDone         = true;
        r.vtScore         = result?.score           ?? null;
        r.vtConfidence    = result?.confidence      ?? null;
        r.vtBreakdown     = result?.breakdown       ?? null;
        r.vtHardRule      = result?.hardRuleApplied ?? null;
        r.vtRawStats      = result?.rawStats        ?? null;
        r.vtFilteredStats = result?.filteredStats   ?? null;
        r.vtFpLevel       = result?.fpLevel         ?? null;
    }, record.originalUrl);
});

// ─────────────────────────────────────────────────────────────────────────────
// onChanged — download complete: wait remaining budget, then act
// ─────────────────────────────────────────────────────────────────────────────

chrome.downloads.onChanged.addListener(async delta => {
    if (!delta.state || delta.state.current !== "complete") return;
    if (checkedIds.has(delta.id)) return; // dedup guard
    checkedIds.add(delta.id);

    let record = pendingChecks.get(delta.id);

    // ── Late-entry: filename was unknown at onCreated time ────────────────
    // Some downloads (e.g. Google Drive) go through a redirect chain so
    // Chrome does not know the filename when onCreated fires. The extension
    // gate in onCreated returns early (ext = null), so no pendingChecks entry
    // is created. Here we pick up those downloads once Chrome has the confirmed
    // filename, build a minimal record, and run host reputation synchronously.
    // VT is skipped (no time budget), but the host check still catches
    // dangerous file types from suspicious or user-controlled sources.
    if (!record) {
        const settings = await new Promise(resolve => Settings.get(resolve));
        if (!settings.extensionEnabled) return;

        let downloadItem;
        try {
            const results = await chrome.downloads.search({ id: delta.id });
            downloadItem = results?.[0];
        } catch { return; }
        if (!downloadItem) return;

        const url = downloadItem.finalUrl || downloadItem.url || "";
        if (!url || isTrustedDomain(url)) return;

        const confirmedFilename = downloadItem.filename || "";
        const ext = getBlockedExtension(url, confirmedFilename)
                 || getBlockedExtension(downloadItem.url || "", "");
        const isArchive   = ext && ARCHIVE_EXTS.has(ext);
        const isDangerous = ext && DANGEROUS_EXTS.has(ext);
        const mime        = DangerousMimes.normalize(downloadItem.mime);
        const isMimeExec  = !isDangerous && !isArchive && EXECUTABLE_MIMES.has(mime);

        if (!isDangerous && !isArchive && !isMimeExec) return;

        const fileType = (isDangerous || isMimeExec) ? "executable" : "archive";
        const isScript = SCRIPT_EXTS.has(ext);
        const isLinuxLauncher = ext === "desktop"; // DS-H001
        const originalUrl = (downloadItem.url && downloadItem.url !== url)
            ? downloadItem.url : url;

        // Build a minimal record — VT fields left null (no time to fetch)
        // lateEntry: true means onCreated had no monitored (dangerous/archive)
        // ext. Usually still UNKNOWN_REVEALED (the common case — the original
        // URL was opaque, e.g. Google Drive), but see DS-H007 below.
        // Best-effort "what did the ORIGINAL url suggest" — getRawExt() is
        // unfiltered (unlike getBlockedExtension), so it can surface a
        // harmless-looking suggested extension (e.g. "pdf") that
        // getObfuscationSignal can compare against the confirmed one.
        const suggestedExt    = getRawExt(extractFilenameFromUrl(downloadItem.url || ""));
        const lateObfuscation = getObfuscationSignal(suggestedExt, ext);
        record = {
            id:               delta.id,
            startedAt:        Date.now(),
            url,
            originalUrl,
            ext,
            confirmedExt:     ext,
            confirmedFilename,
            fileType,
            isScript,
            filename:         confirmedFilename,
            mime:             downloadItem.mime || "",
            totalBytes:       downloadItem.fileSize || 0,
            vtDone:           true,   // skip VT — no budget
            vtScore:          null,
            vtConfidence:     null,
            vtBreakdown:      null,
            vtHardRule:       null,
            vtRawStats:       null,
            vtFilteredStats:  null,
            vtFpLevel:        null,
            vtUnknown:        true,
            hostDone:         false,
            hostResult:       null,
            fpLevel:          settings.fpReductionLevel ?? "MEDIUM",
            autoAllow:        !!settings.autoAllow,
            autoAllowThreshold: settings.autoAllowThreshold ?? APP.AUTO_ALLOW_THRESHOLD_DEFAULT,
            vtApiKeySet:      !!(settings.isVtApiKeySet && settings.vtApiKey),
            state:            "complete",
            lateEntry:        true,       // diagnostic flag
            obfuscation:      lateObfuscation,  // UNKNOWN_REVEALED, or CATEGORY_CHANGED when
                                                 // the original URL hinted at a harmless ext (DS-H007)
        };

        // Run host reputation now, including the obfuscation signal
        record.hostResult = await BrowserProtection.checkHostReputation(
            url, fileType, ext, record.mime, record.totalBytes, originalUrl, isScript, lateObfuscation,
            getDoubleExtension(confirmedFilename),            // double extension
            isLinuxLauncher
        );
        record.hostDone = true;
        pendingChecks.set(delta.id, record);
    }

    // ── Conditional wait: only wait what's left of the budget ─────────────
    const elapsed  = Date.now() - record.startedAt;
    const waitLeft = Math.max(0, APP.VT_WAIT_BUDGET_MS - elapsed);
    if (waitLeft > 0) await new Promise(r => setTimeout(r, waitLeft));

    // ── Get confirmed filename from Chrome (now that download is complete) ─
    let confirmedFilename = record.filename;
    try {
        const results = await chrome.downloads.search({ id: delta.id });
        confirmedFilename = results?.[0]?.filename || record.filename;
    } catch { /* use original */ }

    // ── Re-check extension with confirmed filename ─────────────────────────
    const confirmedExt = getBlockedExtension(record.url, confirmedFilename) || record.ext;

    // ── Obfuscation signal ────────────────────────────────────────────────
    // Compare what was known at onCreated (record.ext) with the confirmed ext.
    // If the extension was hidden or changed category, re-run host reputation
    // with the obfuscation signal so it is included in the breakdown and score.
    const obfuscation = record.lateEntry
        ? null  // late-entry already passed obfuscation at host-check time
        : getObfuscationSignal(record.ext, confirmedExt);

    if (obfuscation && record.hostDone) {
        // Re-run host reputation synchronously with the obfuscation signal added.
        // The prior result (without obfuscation) is discarded.
        const isLinuxLauncher = confirmedExt === "desktop"; // DS-H001
        record.hostResult = await BrowserProtection.checkHostReputation(
            record.url,
            record.fileType,
            confirmedExt,
            record.mime,
            record.totalBytes,
            record.originalUrl,
            record.isScript,
            obfuscation,
            getDoubleExtension(confirmedFilename),   // double extension
            isLinuxLauncher
        );
    }

    // ── Apply VT-unknown multiplier to heuristic signals ──────────────────
    // When VT has no data, we scale negative heuristic signals based on the
    // FP reduction level. High FP reduction = conservative (less alarming),
    // None = aggressive (more alarming). This compensates for the missing
    // VT signal without over-penalising legitimate software.
    const vtUnknown = record.vtDone && record.vtScore === null;
    // See SCORING_CONFIG.FP_UNKNOWN_MULTIPLIERS in ScoringEngineV2.js for rationale.
    const fpMultiplier = vtUnknown
        ? (SCORING_CONFIG.FP_UNKNOWN_MULTIPLIERS[record.fpLevel] ?? 1.0)
        : 1.0;

    // ── Calculate combined score ───────────────────────────────────────────
    const hostScore = record.hostResult?.score ?? 0;
    const scaledHostScore = fpMultiplier !== 1.0
        ? Math.round(Math.min(0, hostScore) * fpMultiplier) + Math.max(0, hostScore)
        : hostScore;
    const vtScore   = record.vtScore ?? 0;
    const combined  = Math.max(-100, Math.min(100, vtScore + scaledHostScore));

    // ── Auto-proceed check — silent, no notification ────────────────────────
    if (record.autoAllow && combined >= record.autoAllowThreshold) {
        pendingChecks.delete(delta.id);
        return;
    }

    // ── Open warning page ─────────────────────────────────────────────────
    // Store final record for the warning page to read via GET_PENDING_CHECK
    record.confirmedExt      = confirmedExt;
    record.confirmedFilename = confirmedFilename;
    record.scaledHostScore   = scaledHostScore;
    record.combinedScore     = combined;
    record.fpMultiplier      = fpMultiplier;
    record.vtUnknown         = vtUnknown;
    record.state             = "complete";

    openWarningPage(delta.id);
});

// ── Cleanup on erase ─────────────────────────────────────────────────────────

chrome.downloads.onErased.addListener(downloadId => {
    pendingChecks.delete(downloadId);
    checkedIds.delete(downloadId);
    BrowserProtection.abandonPendingRequests(downloadId, "download erased");
});

// ─────────────────────────────────────────────────────────────────────────────
// VT submit-and-poll helper  (extracted from inline IIFE — audit item C1/C11)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Submit a URL to VirusTotal for fresh analysis and poll until results arrive.
 * Updates the pendingChecks record when results are available and broadcasts
 * a VT_RESULT_UPDATE message to any open warning pages.
 *
 * SCOPE: submits the download URL only — never the downloaded file itself.
 * Uploading the actual file to a third party is a meaningfully bigger
 * privacy/exposure decision than checking a URL, so that step is
 * intentionally left to the user's own choice, not automated here (see
 * pages/warning/WarningPage.js's "Check download at VT" button, which just
 * opens virustotal.com/hybrid-analysis.com for the user to upload manually).
 *
 * TIMING: the submit + poll round trip is short — typically ~2-3 seconds —
 * so no timer/progress state is needed by callers; VT_RESULT_UPDATE arrives
 * quickly enough that a simple "request sent, wait for the broadcast" is
 * sufficient (see the SUBMIT_URL_TO_VT catch path below for the failure case).
 *
 * STATUS: intended, working, currently unwired to any UI trigger — see
 * CHANGELOG (V2.5.3) and util/MessageTypes.js's SUBMIT_URL_TO_VT comment.
 *
 * @param {number} downloadId  — key into pendingChecks
 * @param {string} cleanUrl    — query-stripped URL to submit
 * @param {string} urlId       — base64url VT URL identifier
 * @param {object} settings    — current settings snapshot
 */
async function submitAndPollVt(downloadId, cleanUrl, urlId, settings) {
    const fpLevel = settings.fpReductionLevel ?? "MEDIUM";

    // Helper: send a result update (or null result on failure) to the warning page
    function broadcastVtUpdate(fields) {
        chrome.runtime.sendMessage({
            type:       MSG.VT_RESULT_UPDATE,
            downloadId,
            ...fields
        }).catch(() => {}); // ignore — warning page may have closed
    }

    try {
        // ── Submit URL for (re-)analysis ──────────────────────────────────
        const formData = new URLSearchParams();
        formData.append("url", cleanUrl);

        const submitResponse = await fetch("https://www.virustotal.com/api/v3/urls", {
            method:  "POST",
            headers: {
                "x-apikey":     settings.vtApiKey,
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: formData.toString()
        });

        if (!submitResponse.ok) {
            // Submission failed — notify warning page so it does not wait forever
            const r = pendingChecks.get(downloadId);
            if (r) r.vtDone = true;
            broadcastVtUpdate({ vtScore: null, vtRawStats: null });
            return;
        }

        // ── Poll for analysis results ──────────────────────────────────────
        const deadline = Date.now() + APP.VT_SUBMIT_POLL_DEADLINE_MS;
        while (Date.now() < deadline) {
            await new Promise(r => setTimeout(r, APP.VT_SUBMIT_POLL_INTERVAL_MS));

            const getResponse = await fetch(
                `https://www.virustotal.com/api/v3/urls/${urlId}`,
                { method: "GET", headers: { "x-apikey": settings.vtApiKey } }
            );
            if (!getResponse.ok) continue;

            const data    = await getResponse.json();
            const attrs   = data?.data?.attributes ?? {};
            const results = attrs.last_analysis_results ?? {};
            if (Object.keys(results).length === 0) continue; // not yet analysed

            const raw      = FpReductionEngines.getRawStats(results);
            const filtered = FpReductionEngines.filterResults(results, fpLevel);
            const eval_    = ScoringEngineV2.evaluate({
                stats: filtered, rawStats: raw,
                firstSubmissionDate: attrs.first_submission_date ?? null,
                fpLevel
            });

            const r = pendingChecks.get(downloadId);
            if (r) {
                r.vtDone         = true;
                r.vtScore         = eval_.score;
                r.vtConfidence    = eval_.confidence;
                r.vtBreakdown     = eval_.breakdown;
                r.vtHardRule      = eval_.hardRuleApplied;
                r.vtRawStats      = raw;
                r.vtFilteredStats = filtered;
                r.vtFpLevel       = fpLevel;
            }

            broadcastVtUpdate({
                vtScore:         eval_.score,
                vtConfidence:    eval_.confidence,
                vtBreakdown:     eval_.breakdown,
                vtHardRule:      eval_.hardRuleApplied,
                vtRawStats:      raw,
                vtFilteredStats: filtered,
                vtFpLevel:       fpLevel
            });
            return; // done
        }

        // Deadline exceeded — analysis never completed within the time budget
        const r = pendingChecks.get(downloadId);
        if (r) r.vtDone = true;
        broadcastVtUpdate({ vtScore: null, vtRawStats: null });

    } catch (err) {
        console.error("[DS:submitAndPollVt] error:", err?.message);
        const r = pendingChecks.get(downloadId);
        if (r) r.vtDone = true;
        // Notify warning page even on error so it does not wait indefinitely
        broadcastVtUpdate({ vtScore: null, vtRawStats: null });
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Message router — single switch (audit item C3)
// ─────────────────────────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

    // Security: only accept messages from this extension's own pages
    if (sender.extensionId && sender.extensionId !== chrome.runtime.id) return;

    switch (msg.type) {

        case MSG.GET_PENDING_CHECK:
            sendResponse(pendingChecks.get(msg.downloadId) || null);
            return true;

        case MSG.DISMISS_CHECK:
            // User clicked OK or Check at VT — clean up all resources for this download
            BrowserProtection.abandonPendingRequests(msg.downloadId, "user dismissed");
            pendingChecks.delete(msg.downloadId);
            checkedIds.delete(msg.downloadId);
            sendResponse({ success: true });
            return true;

        case MSG.EXTENSION_TOGGLE:
            setExtensionIcon(msg.enabled);
            return true;

        case MSG.SETTINGS_UPDATED:
            loadCustomDomains();
            return true;

        case MSG.SUBMIT_URL_TO_VT: {
            const record = pendingChecks.get(msg.downloadId);
            if (!record) {
                sendResponse({ success: false, error: "Download not found" });
                return true;
            }

            Settings.get(settings => {
                if (!settings.isVtApiKeySet || !settings.vtApiKey) {
                    sendResponse({ success: false, error: "No VT API key" });
                    return;
                }

                const cleanUrl = UrlUtils.cleanUrl(record.url);
                const urlId    = UrlUtils.toVtUrlId(cleanUrl);

                record.vtDone = false;
                sendResponse({ success: true });

                // Delegate to the named helper (audit item C1 — no more inline IIFE)
                submitAndPollVt(msg.downloadId, cleanUrl, urlId, settings);
            });
            return true;
        }

        default:
            // Unknown message type — ignore silently
            break;
    }
});
