"use strict";

// ── BrowserProtection.js ──────────────────────────────────────────────────────
// Orchestrates two independent reputation axes, run simultaneously:
//
//   A. VirusTotal URL check  — community score removed
//   B. Host reputation       — Quad9 + RDAP + domain/TLD lists + URL patterns
//
// Public interface:
//   BrowserProtection.checkIfUrlIsMalicious(key, url, callback, originalUrl)
//       — starts VT fetch on url; also checks originalUrl against VT when it
//         resolves to a different registered domain (redirect-chain check),
//         taking the worse verdict. Fires callback(ProtectionResult, elapsedMs)
//   BrowserProtection.checkHostReputation(url, fileType, ext, mime, totalBytes,
//                                         originalUrl, isScript, obfuscation,
//                                         doubleExt, isLinuxLauncher)
//       — returns Promise<hostResult>
//   BrowserProtection.abandonPendingRequests(key, reason)
//       — aborts in-flight fetch for the given download key
//   BrowserProtection.cleanup()
//       — abort ALL in-flight requests and clear the session URL cache
//
// State owned by this module:
//   abortControllers  {Map<downloadId, AbortController>}
//       — in-flight VT fetch controllers; deleted on completion, abort, or error.
//         Bounded naturally: one entry per concurrent in-flight VT check.
//         Released via abandonPendingRequests() or on fetch completion.
//   BrowserProtection.allowedUrls  {BoundedUrlSet}
//       — session cache of VT-confirmed-safe URLs; capped at APP.ALLOWED_URLS_MAX
//         with FIFO eviction. Lost on SW restart (safe: re-checked on next download).
// ─────────────────────────────────────────────────────────────────────────────

/**
 * BrowserProtection.js (legacy JSDoc retained for IDE tooling)
 *
 * Orchestrates two independent reputation axes, run simultaneously:
 *
 *   A. VirusTotal URL check  (existing logic, community score removed)
 *   B. Host reputation       (Quad9 + RDAP + domain list + TLD list + URL pattern)
 *
 * Both complete independently. The caller (background.js) stores and
 * forwards both result objects to the warning page. The warning page
 * reports the worst overall score but shows both info boxes.
 *
 * URL cleaning is delegated to UrlUtils (shared module).
 */
import { APP } from "../util/AppConstants.js";
import { Settings } from "../util/Settings.js";
import { UrlUtils } from "../util/UrlUtils.js";
import { SuspiciousDomains } from "../util/SuspiciousDomains.js";
import { SuspiciousTlds } from "../util/SuspiciousTlds.js";
import { RiskyHostingSites } from "../util/RiskyHostingSites.js";
import { FpReductionEngines } from "../util/FpReductionEngines.js";
import { ProtectionResult } from "./ProtectionResult.js";
import { ScoringEngineV2 } from "./ScoringEngineV2.js";
import { SketchyUrlCheck } from "./SketchyUrlCheck.js";
import { MimeCheck } from "./MimeCheck.js";
import { Quad9Protection } from "./Quad9Protection.js";
import { RdapProtection } from "./RdapProtection.js";

export const BrowserProtection = (function () {

    const abortControllers = new Map();

    function closeOpenConnections(key, reason) {
        // Called when a download's lifecycle is fully over (cancelled, allowed,
        // erased, or swept as stale) — abort any in-flight request and DELETE
        // the entry rather than replacing it with a fresh controller. Replacing
        // it left a permanent Map entry per downloadId for the SW's lifetime,
        // an unbounded memory leak (one entry per blocked download, never freed).
        if (abortControllers.has(key)) {
            abortControllers.get(key).abort(reason);
            abortControllers.delete(key);
        }
    }

    // ── VT helpers ─────────────────────────────────────────────────────────

    function unknownVtResult(url, startTime, callback) {
        callback(
            new ProtectionResult(
                url,
                ProtectionResult.ResultType.UNKNOWN,
                ProtectionResult.ResultOrigin.VIRUSTOTAL
            ),
            Date.now() - startTime
        );
    }

    /**
     * True when originalUrl exists, differs from url, and resolves to a
     * different registered domain — the condition under which it is worth
     * spending a second (rate-limited) VirusTotal lookup on the original URL
     * as well as the final one.
     *
     * Mirrors the redirect-chain rationale already used for Quad9/RDAP in
     * checkHostReputation(): a malicious actor can mask the true source
     * behind a clean-looking redirector domain, or vice versa, so the worse
     * of the two verdicts is the one that matters.
     */
    function originalDomainDiffers(url, originalUrl) {
        if (!originalUrl || originalUrl === url) return false;
        const finalDomain    = UrlUtils.getRegisteredDomain(UrlUtils.getHostname(url));
        const originalDomain = UrlUtils.getRegisteredDomain(UrlUtils.getHostname(originalUrl));
        return !!(originalDomain && originalDomain !== finalDomain);
    }

    /**
     * Fetch and evaluate a single URL against the VirusTotal API.
     * Returns { eval, raw, filtered } on a definite VT verdict, or null when
     * VT has no analysis data for the URL (unrated / not found — "unknown").
     * Throws on network error or abort; the caller decides how to handle that.
     */
    async function fetchVtEvaluation(targetUrl, apiKey, fpLevel, signal) {
        const urlId    = UrlUtils.toVtUrlId(targetUrl);
        const response = await fetch(
            `https://www.virustotal.com/api/v3/urls/${urlId}`,
            { method: "GET", headers: { "x-apikey": apiKey }, signal }
        );
        if (!response.ok) return null;

        const data    = await response.json();
        const attrs   = data?.data?.attributes ?? {};
        const results = attrs.last_analysis_results ?? {};
        if (Object.keys(results).length === 0) return null; // no engines rated it — unknown

        const raw      = FpReductionEngines.getRawStats(results);
        const filtered = FpReductionEngines.filterResults(results, fpLevel);
        const eval_    = ScoringEngineV2.evaluate({
            stats:               filtered,
            rawStats:            raw,
            firstSubmissionDate: attrs.first_submission_date ?? null,
            fpLevel
        });
        return { eval: eval_, raw, filtered };
    }

    /**
     * Pick the worse (lower-scoring) of two VT evaluations. Either may be
     * null (VT had no data for that URL); a definite result always beats
     * "unknown", and lower score = worse between two definite results.
     */
    function worseVtEvaluation(a, b) {
        if (!a) return b;
        if (!b) return a;
        return a.eval.score <= b.eval.score ? a : b;
    }

    // ── Host-reputation check ───────────────────────────────────────────────

    /**
     * Run all four host-reputation checks simultaneously and return a combined
     * host-reputation result object.
     *
     * @param {string} url       - Original download URL
     * @param {string} fileType  - "executable" | "archive"
     * @returns {Promise<object>} hostResult
     */
    /**
     * Run heuristics on a single URL and return all synchronous signals.
     * Used internally to support dual-URL heuristics comparison.
     */
    function getUrlHeuristics(url) {
        const hostname = UrlUtils.getHostname(url);
        const tld      = UrlUtils.getTld(hostname);
        return {
            hostname,
            tld,
            domainHit:  SuspiciousDomains.lookup(hostname),
            tldHit:     SuspiciousTlds.lookup(tld),
            sketchyUrl: SketchyUrlCheck.check(url),
        };
    }

    /**
     * Pick the worse of two heuristic signals (lower score = worse).
     * Returns whichever signal has the lower score, or the non-null one.
     */
    function worseHit(a, b) {
        if (!a && !b) return null;
        if (!a)       return b;
        if (!b)       return a;
        return (a.score || 0) <= (b.score || 0) ? a : b;
    }

    async function checkHostReputation(url, fileType, ext, mime, totalBytes, originalUrl, isScript = false, obfuscation = null, doubleExt = null, isLinuxLauncher = false) {

        // ── Signals that use the finalUrl (actual download) ───────────────────
        const finalHostname = UrlUtils.getHostname(url);
        const finalTld      = UrlUtils.getTld(finalHostname);
        const mimeResult    = MimeCheck.checkMime(ext || "", mime || "");
        const sizeResult    = MimeCheck.checkSize(totalBytes || 0);
        const riskyHosting  = RiskyHostingSites.lookup(finalHostname);

        // ── Signals that use worst of finalUrl vs originalUrl ─────────────────
        const finalHeuristics    = getUrlHeuristics(url);
        const originalHeuristics = (originalUrl && originalUrl !== url)
            ? getUrlHeuristics(originalUrl)
            : null;

        // Take the worse (lower scoring) signal from each category
        const domainHit  = originalHeuristics
            ? worseHit(finalHeuristics.domainHit,  originalHeuristics.domainHit)
            : finalHeuristics.domainHit;
        const tldHit     = originalHeuristics
            ? worseHit(finalHeuristics.tldHit,     originalHeuristics.tldHit)
            : finalHeuristics.tldHit;
        // For sketchyUrl compare by score
        const sketchyFinal    = finalHeuristics.sketchyUrl;
        const sketchyOriginal = originalHeuristics?.sketchyUrl;
        const sketchyUrl = (sketchyOriginal && (sketchyOriginal.score || 0) > (sketchyFinal?.score || 0))
            ? sketchyOriginal
            : sketchyFinal;

        // ── Quad9 + RDAP: run on finalUrl; if originalUrl has different domain,
        //    also run on originalUrl and take the worse result ─────────────────
        const registeredDomain         = UrlUtils.getRegisteredDomain(finalHostname);
        const originalHostname         = originalHeuristics ? originalHeuristics.hostname : null;
        const originalRegisteredDomain = originalHostname
            ? UrlUtils.getRegisteredDomain(originalHostname) : null;

        // Run Quad9 + RDAP on both domains in parallel when needed
        const needsOriginalAsync = originalRegisteredDomain &&
            originalRegisteredDomain !== registeredDomain;

        const asyncChecks = [
            Quad9Protection.check(finalHostname),
            RdapProtection.check(registeredDomain),
            ...(needsOriginalAsync ? [
                Quad9Protection.check(originalHostname),
                RdapProtection.check(originalRegisteredDomain)
            ] : [])
        ];

        const asyncResults = await Promise.all(asyncChecks);
        let quad9Result = asyncResults[0];
        let rdapResult  = asyncResults[1];

        if (needsOriginalAsync) {
            const origQuad9 = asyncResults[2];
            const origRdap  = asyncResults[3];
            // Take worse Quad9: BLOCKED > UNKNOWN > ALLOWED
            const quad9Rank = { BLOCKED: 2, UNKNOWN: 1, ALLOWED: 0 };
            if ((quad9Rank[origQuad9.status] || 0) > (quad9Rank[quad9Result.status] || 0)) {
                quad9Result = origQuad9;
            }
            // Take worse RDAP: lower score = worse
            if ((origRdap.score || 0) < (rdapResult.score || 0)) {
                rdapResult = origRdap;
            }
        }

        const evaluation = ScoringEngineV2.evaluateHostReputation({
            quad9:     quad9Result,
            rdap:      rdapResult,
            domainHit,
            tldHit,
            sketchyUrl,
            mimeResult,
            sizeResult,
            riskyHosting,
            url,
            originalUrl,
            fileType,
            isScript,
            obfuscation,
            doubleExt,
            isLinuxLauncher
        });

        return {
            hostname:        finalHostname,
            originalHostname,
            tld:             finalTld,
            registeredDomain,
            quad9:           quad9Result,
            rdap:            rdapResult,
            domainHit,
            tldHit,
            sketchyUrl,
            mimeResult,
            sizeResult,
            riskyHosting,
            score:           evaluation.score,
            classification:  evaluation.classification,
            label:           evaluation.label,
            hardRuleApplied: evaluation.hardRuleApplied,
            breakdown:       evaluation.breakdown
        };
    }

    // ─────────────────────────────────────────────────────────────────────────

    return {

        abandonPendingRequests(key, reason) {
            closeOpenConnections(key, reason);
        },

        /**
         * Run VT URL check on the final download URL, and — when originalUrl
         * resolves to a different registered domain — on the original
         * (pre-redirect) URL too, reporting the worse of the two verdicts.
         * Called from background.js after download is intercepted.
         * Host reputation is run separately via checkHostReputation().
         */
        checkIfUrlIsMalicious(key, url, callback, originalUrl) {

            if (!key || !url || typeof callback !== "function") return;

            // Validate that url parses; the URL object itself isn't needed here —
            // UrlUtils re-parses as needed downstream — only the validity check is.
            try { new URL(url); }
            catch {
                console.warn("[DS:BrowserProtection] Invalid URL, skipping VT check:", url);
                return;
            }

            const startTime = Date.now();

            if (!abortControllers.has(key)) {
                abortControllers.set(key, new AbortController());
            }

            const doVtCheck = async (settings) => {

                if (!settings.extensionEnabled)               return;
                if (!settings.virusTotalEnabled)              return;
                if (!settings.isVtApiKeySet || !settings.vtApiKey) return;

                // Session cache: skip re-checking URLs already classified as safe
                if (BrowserProtection.allowedUrls.has(UrlUtils.cleanUrl(url))) {
                    callback(
                        new ProtectionResult(
                            url,
                            ProtectionResult.ResultType.PROBABLY_SAFE,
                            ProtectionResult.ResultOrigin.VIRUSTOTAL,
                            { score: 100, confidence: "Cached", hardRuleApplied: null }
                        ),
                        Date.now() - startTime
                    );
                    return;
                }

                const controller = abortControllers.get(key);
                const signal     = controller?.signal;

                let callbackFired = false;

                const timeoutId = setTimeout(() => {
                    if (callbackFired) return;
                    callbackFired = true;
                    controller?.abort("timeout");
                    abortControllers.delete(key); // release on timeout
                    unknownVtResult(url, startTime, callback);
                }, APP.VT_FETCH_TIMEOUT_MS); // see AppConstants.js

                try {
                    // Small delay so warning page is mounted before result arrives
                    await new Promise(r => setTimeout(r, APP.VT_FETCH_STARTUP_DELAY_MS));

                    const fpLevel = settings.fpReductionLevel ?? "MEDIUM";

                    // Redirect-chain check: only spend a second VT lookup on
                    // originalUrl when it actually resolves to a different
                    // registered domain than the final download URL (bug fix —
                    // originalUrl used to be accepted as a parameter and silently
                    // ignored). Both requests share one AbortController/signal so
                    // abandoning the download cancels both together.
                    const needsOriginalCheck = originalDomainDiffers(url, originalUrl);

                    const [finalProbe, originalProbe] = await Promise.all([
                        fetchVtEvaluation(url, settings.vtApiKey, fpLevel, signal),
                        needsOriginalCheck
                            ? fetchVtEvaluation(originalUrl, settings.vtApiKey, fpLevel, signal)
                            : Promise.resolve(null)
                    ]);

                    clearTimeout(timeoutId);
                    if (callbackFired) return;
                    callbackFired = true;

                    const parsed = worseVtEvaluation(finalProbe, originalProbe);

                    if (!parsed) {
                        unknownVtResult(url, startTime, callback);
                        return;
                    }

                    const { eval: evaluation, raw: rawStats, filtered: filteredStats } = parsed;

                    // Cache only against the exact final URL requested — never mark
                    // it "safe" solely because a *different* (originalUrl) lookup
                    // came back clean.
                    if (parsed === finalProbe &&
                        evaluation.classification === ProtectionResult.ResultType.PROBABLY_SAFE) {
                        BrowserProtection.allowedUrls.add(UrlUtils.cleanUrl(url));
                    }

                    // Release the AbortController — no longer needed after callback fires
                    abortControllers.delete(key);
                    callback(
                        new ProtectionResult(
                            url,
                            evaluation.classification,
                            ProtectionResult.ResultOrigin.VIRUSTOTAL,
                            {
                                score:           evaluation.score,
                                confidence:      evaluation.confidence,
                                breakdown:       evaluation.breakdown,
                                hardRuleApplied: evaluation.hardRuleApplied,
                                rawStats,
                                filteredStats,
                                fpLevel
                            }
                        ),
                        Date.now() - startTime
                    );

                } catch (error) {
                    clearTimeout(timeoutId);
                    abortControllers.delete(key); // release on error too
                    if (error.name === "AbortError") return;
                    if (callbackFired) return;
                    callbackFired = true;
                    console.warn("[DS:BrowserProtection] VT fetch error:", error?.message);
                    unknownVtResult(url, startTime, callback);
                }
            };

            Settings.get(settings => doVtCheck(settings));
        },

        /**
         * Run host-reputation checks for a download.
         * Returns a Promise that resolves with the host-reputation result.
         */
        checkHostReputation,

        /**
         * Abort ALL in-flight VT requests and clear the session URL cache.
         * Called when the extension is disabled or for testing/reset purposes.
         * Safe to call at any time; is a no-op if nothing is in-flight.
         */
        cleanup() {
            for (const [key, controller] of abortControllers) {
                controller.abort("cleanup");
                abortControllers.delete(key);
            }
            if (BrowserProtection.allowedUrls) {
                BrowserProtection.allowedUrls.clear();
            }
        }

    };

})();

// allowedUrls: session cache of URLs already confirmed PROBABLY_SAFE by VT,
// so repeat downloads of the same file don't burn VT's 4-req/min free-tier
// quota. Previously an unbounded Set — every unique safe URL checked over the
// SW's lifetime accumulated permanently. Now capped at MAX_ALLOWED_URLS with
// FIFO eviction (oldest entries drop first) to bound memory growth.
// BoundedUrlSet — FIFO-evicting Set capped at APP.ALLOWED_URLS_MAX entries.
// Prevents the allowedUrls cache from growing unboundedly over the SW's lifetime.
class BoundedUrlSet {
    constructor(max) { this.max = max; this.map = new Map(); }
    has(key)  { return this.map.has(key); }
    add(key)  {
        if (this.map.has(key)) { this.map.delete(key); } // refresh recency
        this.map.set(key, true);
        if (this.map.size > this.max) {
            // Evict oldest (first inserted) entry
            this.map.delete(this.map.keys().next().value);
        }
    }
    clear()   { this.map.clear(); }
    get size() { return this.map.size; }
}
BrowserProtection.allowedUrls = new BoundedUrlSet(APP.ALLOWED_URLS_MAX);
