"use strict";

/**
 * DangerousMimes.js — Single source of truth for dangerous MIME definitions.
 *
 * DS-H008 — Previously there were two independently-maintained MIME
 * collections that had silently drifted apart:
 *   - background.js: EXECUTABLE_MIMES (gates whether a MIME-only signal is
 *     treated as executable at all)
 *   - MimeCheck.js:   MIME_TO_EXTS   (used for extension/MIME mismatch scoring)
 *
 * WARNING FOR IMPLEMENTATION IMPACT: the two lists did not actually agree —
 * MIME_TO_EXTS already recognised things like "text/x-sh", "text/x-python",
 * "text/vbscript" and "application/x-ms-shortcut" that EXECUTABLE_MIMES did
 * not. A file served with one of those MIME types and no recognised
 * extension previously passed through onCreated/onChanged entirely
 * unevaluated. Consolidating onto one map means those cases are now caught —
 * this widens (not narrows) what gets flagged; nothing that was previously
 * flagged stops being flagged.
 *
 * EXECUTABLE_MIMES is derived automatically from MIME_TO_EXTS (any MIME
 * whose mapped extensions include a DangerousExts.DANGEROUS entry) rather
 * than hand-maintained, so the two collections can never drift apart again.
 *
 * Public interface:
 *   DangerousMimes.MIME_TO_EXTS   {Object<string,string[]>} mime -> exts (no dot)
 *   DangerousMimes.EXECUTABLE_MIMES {Set<string>}  derived — see above
 *   DangerousMimes.normalize(mimeType) -> string    lowercase, params stripped, trimmed
 */
import { DangerousExts } from "./DangerousExts.js";

export const DangerousMimes = (function () {

    // Map of MIME type -> accepted extensions (lowercase, no dot).
    // Covers the file types DownloadSentinel intercepts (executables + archives
    // + the document/image/media types MimeCheck.checkMime() also evaluates).
    const MIME_TO_EXTS = {
        // Executables
        "application/x-msdownload":          ["exe", "dll", "com"],
        "application/x-msdos-program":       ["exe", "com"],
        "application/x-ms-dos-executable":   ["exe", "com"],   // alias seen in the wild
        "application/vnd.microsoft.portable-executable": ["exe", "dll"],
        "application/x-executable":          ["exe", "out", "bin"],
        "application/x-dosexec":             ["exe", "com"],
        "application/x-bat":                 ["bat"],
        "application/x-msi":                 ["msi"],
        "application/x-ms-installer":        ["msi", "msp"],
        "application/x-powershell":          ["ps1", "ps1xml", "ps2", "ps2xml", "psc1", "psc2"],
        "text/x-powershell":                 ["ps1"],
        "application/x-sh":                  ["sh", "bash", "ksh", "csh"],
        "text/x-sh":                         ["sh", "bash"],
        "application/x-python":              ["py", "pyc"],
        "text/x-python":                     ["py"],
        "application/x-perl":                ["pl", "pm"],
        "text/x-perl":                       ["pl"],
        "application/x-php":                 ["php"],
        "text/x-php":                        ["php"],
        "application/x-vbs":                 ["vbs", "vbe", "vb"],
        "text/vbscript":                     ["vbs", "vbe"],
        "application/x-javascript":          ["js"],
        "text/javascript":                   ["js"],
        "application/java-archive":          ["jar"],
        "application/x-java-archive":        ["jar"],
        "application/x-debian-package":      ["deb"],
        "application/x-rpm":                 ["rpm"],
        "application/x-appimage":            ["appimage"],
        "application/x-hta":                 ["hta"],
        "application/x-ms-shortcut":         ["lnk"],
        "application/x-mscf":                ["chm"],
        "application/x-java-vm":             ["class"],

        // DS-H001 — Linux desktop launcher files
        "application/x-desktop":             ["desktop"],
        "application/x-gnome-app-info":      ["desktop"],

        // Archives
        "application/zip":                   ["zip"],
        "application/x-zip-compressed":      ["zip"],
        "application/x-zip":                 ["zip"],
        "application/x-rar-compressed":      ["rar"],
        "application/vnd.rar":               ["rar"],
        "application/x-7z-compressed":       ["7z"],
        "application/x-tar":                 ["tar"],
        "application/gzip":                  ["gz", "tar"],
        "application/x-gzip":                ["gz", "tar"],
        "application/x-bzip2":               ["bz2", "tar"],
        "application/x-xz":                  ["xz", "tar"],
        "application/x-lzma":                ["lzma"],
        "application/x-lzip":                ["lz"],
        "application/x-compress":            ["z"],
        "application/x-iso9660-image":       ["iso"],
        "application/x-apple-diskimage":     ["dmg"],
        "application/x-cab-compressed":      ["cab"],
        "application/vnd.ms-cab-compressed": ["cab"],

        // Documents sometimes abused as malware carriers
        "application/pdf":                   ["pdf"],
        "application/msword":                ["doc"],
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ["docx"],
        "application/vnd.ms-excel":          ["xls"],
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": ["xlsx"],
        "application/vnd.ms-powerpoint":     ["ppt"],
        "application/vnd.openxmlformats-officedocument.presentationml.presentation": ["pptx"],

        // Text / script types (often misused)
        "text/plain":                        ["txt", "log", "csv", "ini", "cfg", "conf"],
        "text/html":                         ["html", "htm"],
        "text/xml":                          ["xml"],
        "application/xml":                   ["xml"],
        "application/json":                  ["json"],

        // Images (should never be executables)
        "image/jpeg":                        ["jpg", "jpeg"],
        "image/png":                         ["png"],
        "image/gif":                         ["gif"],
        "image/bmp":                         ["bmp"],
        "image/webp":                        ["webp"],
        "image/svg+xml":                     ["svg"],

        // Audio / Video (should never be executables)
        "audio/mpeg":                        ["mp3"],
        "audio/wav":                         ["wav"],
        "video/mp4":                         ["mp4"],
        "video/x-msvideo":                   ["avi"],
    };

    // Derived, not hand-maintained: any MIME whose mapped extensions include
    // at least one DangerousExts.DANGEROUS entry counts as an executable MIME.
    // This is what background.js uses to gate isMimeExec — see module header.
    const EXECUTABLE_MIMES = new Set(
        Object.entries(MIME_TO_EXTS)
            .filter(([, exts]) => exts.some(ext => DangerousExts.DANGEROUS.set.has(ext)))
            .map(([mime]) => mime)
    );

    /**
     * Normalize a raw Content-Type / downloadItem.mime value:
     *   - strip parameters after ";" (e.g. "; charset=utf-8")
     *   - trim whitespace
     *   - lowercase
     * Previously this exact three-step sequence was duplicated inline at
     * three separate call sites in background.js and once in MimeCheck.js.
     */
    function normalize(mimeType) {
        return (mimeType || "").split(";")[0].trim().toLowerCase();
    }

    return { MIME_TO_EXTS, EXECUTABLE_MIMES, normalize };
})();
