"use strict";

// ── AppConstants.js ───────────────────────────────────────────────────────────
// Single source of truth for all application-wide magic numbers, limits, and
// timing values that are not specific to the VT scoring algorithm.
//
// Scoring thresholds and VT-analysis weights live in SCORING_CONFIG inside
// ScoringEngineV2.js because they are tightly coupled to the algorithm.
// Everything else — timeouts, collection caps, UI limits — lives here.
//
// Public interface:
//   APP  {Object}  — frozen map of named constants
//
// Dependencies: none
//
// Usage:
//   Service worker:   importScripts("util/AppConstants.js")
//   Page contexts:    <script src="../../util/AppConstants.js">
// ─────────────────────────────────────────────────────────────────────────────

const APP = Object.freeze({

    // ── Timing — service worker ───────────────────────────────────────────────

    // Total budget (ms) from download-created timestamp to when we give up
    // waiting for VT in the onChanged handler.
    // Breakdown: 3000 ms VT timeout + 100 ms BP startup delay +
    //            50 ms Settings.get overhead + 50 ms event-loop jitter +
    //            50 ms network RTT buffer.
    // The timestamp is set BEFORE API calls start so the budget covers all
    // setup overhead.
    VT_WAIT_BUDGET_MS: 3250,

    // How long a pendingChecks entry may live before the sweep removes it.
    ENTRY_MAX_AGE_MS: 30 * 60 * 1000,      // 30 minutes

    // How often the stale-entry alarm fires (minutes, as required by chrome.alarms).
    SWEEP_ALARM_PERIOD_MINUTES: 5,

    // Name of the chrome.alarms alarm used for stale-entry sweeping.
    SWEEP_ALARM_NAME: "sweepStaleEntries",

    // ── Timing — VT fetch (BrowserProtection.js) ─────────────────────────────

    // Hard timeout on the VT GET request; users get impatient beyond this.
    // Cached VT lookups typically resolve in 200–800 ms.
    VT_FETCH_TIMEOUT_MS: 3000,

    // Small pause before VT fetch so the warning page is mounted before the
    // result arrives (avoids a race where the result fires before listeners
    // are registered).
    VT_FETCH_STARTUP_DELAY_MS: 100,

    // ── Timing — VT submission polling (background.js SUBMIT_URL_TO_VT) ──────

    // Maximum time to wait for a freshly submitted URL to be analysed by VT.
    VT_SUBMIT_POLL_DEADLINE_MS: 15000,

    // Interval between poll attempts while waiting for VT analysis results.
    VT_SUBMIT_POLL_INTERVAL_MS: 1000,

    // ── Timing — Quad9 / RDAP ─────────────────────────────────────────────────

    // Hard timeout on Quad9 DNS-over-HTTPS requests.
    QUAD9_TIMEOUT_MS: 8000,

    // Hard timeout on RDAP domain-registration-age requests.
    RDAP_TIMEOUT_MS: 8000,

    // ── Collection caps ───────────────────────────────────────────────────────

    // Maximum number of safe URLs held in BrowserProtection.allowedUrls
    // (FIFO eviction when exceeded).
    ALLOWED_URLS_MAX: 200,

    // ── UI limits — Options page ──────────────────────────────────────────────

    // Maximum number of custom trusted-domain entries the user can add.
    DOMAIN_WHITELIST_MAX: 12,

    // Minimum and maximum values for the auto-allow threshold input.
    AUTO_ALLOW_THRESHOLD_MIN: 30,
    AUTO_ALLOW_THRESHOLD_MAX: 100,

    // Default auto-allow threshold when not set.
    AUTO_ALLOW_THRESHOLD_DEFAULT: 80,

    // ── Default UI strings — shared between Settings, OptionsPage, WarningPage ─
    // Changing a default here updates all three consumers automatically.
    WARNING_TITLE_DEFAULT:
        "Download requires your attention: review before proceeding",

});
