# Download Sentinel — Changelog

## V2.1.0
Audit pass — structural, defensive-programming, and documentation improvements.
No logic or behaviour changes; scoring and UI remain identical.

### Bug fixes
- **`vtDone` undeclared variable** (`WarningPage.js`): was assigned without `let`/`const`,
  creating an implicit global. Declared as `let vtDone = false` with module state docs.
- **`-50` vs `-40` scoring discrepancy** (`ScoringEngineV2.js`): the 5–9 suspicious
  detection branch hardcoded `-50` but `SCORING_CONFIG.VT_SUSPICIOUS_5_9` was `-40`.
  The config value is now corrected to `-50` (matches the algorithm intent) and the
  hardcode is removed; the branch references the config constant.
- **SUBMIT_URL_TO_VT catch path** (`background.js`): network errors during VT submission
  polling now broadcast a `VT_RESULT_UPDATE` with null scores so the warning page
  does not wait indefinitely.
- **`openWarningPage` silent failure** (`background.js`): `chrome.windows.create()`
  failures are now caught and logged; the orphaned `pendingChecks` entry is cleaned up.

### Architecture
- **`util/AppConstants.js`** (new): single source of truth for all magic numbers —
  timeouts (`VT_WAIT_BUDGET_MS`, `VT_FETCH_TIMEOUT_MS`, `QUAD9_TIMEOUT_MS`, etc.),
  collection caps (`ALLOWED_URLS_MAX`), UI limits (`DOMAIN_WHITELIST_MAX`,
  `AUTO_ALLOW_THRESHOLD_MIN/MAX/DEFAULT`), and the default warning title string.
- **`util/MessageTypes.js`** (new): `MSG` frozen object — single source of truth for
  all `chrome.runtime` message type strings. Every send and receive site now references
  `MSG.GET_PENDING_CHECK` etc. instead of bare string literals.
- **Message router** (`background.js`): replaced `if/else if` chain with a single
  `switch (msg.type)` statement (audit C3).
- **`submitAndPollVt()`** (`background.js`): extracted the 60-line inline IIFE inside
  the `SUBMIT_URL_TO_VT` handler into a named top-level function (audit C1/C11).
- **`SCORING_CONFIG`** (`ScoringEngineV2.js`): `HOST_DOMAIN_BASE_SCORE`,
  `HOST_TLD_BASE_SCORE`, and `HOST_SKETCHY_URL_BASE` moved in from local `const`s
  (audit B1). All host-reputation base scores now live alongside VT scoring config.
- **`BrowserProtection.cleanup()`** (new): explicit lifecycle cleanup function — aborts
  all in-flight VT requests and clears the session URL cache (audit C8).
- **`WarningPage.js`**: wrapped in an IIFE so all variables are module-scoped rather
  than window-globals (audit C1). Added `chrome.runtime.onMessage` listener for
  `VT_RESULT_UPDATE` push messages.

### Defensive programming
- **`checkedIds` orphan sweep** (`background.js`): `sweepStaleEntries()` now also
  removes `checkedIds` entries that have no corresponding `pendingChecks` record
  (could arise after a SW restart mid-download).
- **`Settings.set` error handling** (`OptionsPage.js`, `PopupPage.js`): callbacks now
  check `chrome.runtime.lastError` and show an error message on storage failure
  instead of silently reporting success.
- **`BoundedUrlSet.clear()`** (new): allows `BrowserProtection.cleanup()` to reset
  the allowed-URLs cache.

### Code quality
- **Dead settings keys removed** (`Settings.js`): `warningTitlePost`,
  `isInstanceIDInitialized`, and `instanceID` removed from defaults — they were
  never written or read by any current code path. Users with stale `warningTitlePost`
  values will see it ignored on next settings merge (backward-compatible).
- **`browserAPI` shim removed**: all three page contexts and `Storage.js` used a
  `typeof browser === 'undefined' ? chrome : browser` shim. MV3 in Chrome has no
  `browser` global; replaced with direct `chrome` references throughout.
- **Default warning title deduplication**: `APP.WARNING_TITLE_DEFAULT` is now the
  single source of truth used by `Settings.js`, `OptionsPage.js`, and `WarningPage.js`.
- **`host-signals-empty` CSS class** (`WarningPage.css`): the inline
  `li.style.color = "#6b7280"` for the "no alarming signals" row is now a proper
  CSS class (audit A6).
- **Script load order**: `AppConstants.js` and `MessageTypes.js` are now listed first
  in all `importScripts()` and `<script src>` lists, reflecting their Tier 5/4
  position in the dependency tree. `<script>` tags moved from `<head>` to bottom of
  `<body>` in OptionsPage and PopupPage.
- **Module header comments**: all files now have a standard header documenting purpose,
  public interface, dependencies, and owned state (audit C10).

### Manifest (V2.1.0)
- Version bumped to `2.1.0`.
- `web_accessible_resources` updated to include `AppConstants.js`, `MessageTypes.js`,
  `Storage.js`, `Settings.js`, `ScriptExts.js`, and `ScoringEngineV2.js` — all loaded
  by the warning page at runtime and must be declared accessible.
- Permissions unchanged (`downloads`, `storage`, `alarms`).
- `host_permissions` unchanged (VirusTotal, Quad9, RDAP).

---

## V2.0.1
- Minor fixes following V2.0 release.

## V2.0
- **ScoringEngineV2**: two-axis scoring (VT + host reputation); full scoring
  configuration block (`SCORING_CONFIG`).
- **ScriptExts.js**: script/LOLBin extensions extracted to single shared file.
- **BoundedUrlSet**: `allowedUrls` capped at 200 entries with FIFO eviction.
- **State/timer/guards reference comments** added to `background.js`.
- **`abortControllers` leak fixed**: delete-not-replace on completion.

## V1.8
- **Auto-proceed feature**: option to automatically allow downloads above a configurable risk score threshold.
- **Two-score UI**: host reputation and VT each show their own confidence score.
- **Scoring overhaul**: simple additive scoring (VT score + age score + heuristics).
- **ABC consensus bonus**: percentage-based clean-engine bonus.
- **Loop guard**: `interceptPaused` boolean prevents `resume()` → `onCreated` loop.

## V1.7
- **Scoring refactor**: VT + age additive scoring; risky hosting scores rebalanced.
- **TLD list**: removed `.app`, `.dev`, `.cloud`, `.tech`, `.pro`.
- **MIME check**: `text/plain` neutral for binaries, mild penalty for scripts.
- **Script detection**: `SCRIPT_EXTS` list; `−25` heuristic for script-format downloads.

## V1.4.2
- Two-box layout: VT and heuristics in separate info boxes.

## V1.4.1
- Fixed duplicate "VirusTotal rates it currently as…" line.

## V1.4
- Post-download safety net: `onChanged` listener.
- Performance/memory: `chrome.alarms` sweep, `BoundedUrlSet`, dead file removed.
- Security: `web_accessible_resources` restricted; DOM node construction; sender validation.

## V1.3 (Chrome Web Store initial submission)
- Warning page with VT URL reputation check, host heuristics, overall risk score.
- FP reduction slider (HIGH / MEDIUM / LOW / NONE).
- Options page: API key, FP reduction, background colour, trusted domains.
