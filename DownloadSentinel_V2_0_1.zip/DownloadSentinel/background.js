importScripts(
    "util/Storage.js",
    "util/Settings.js",
    "util/UrlUtils.js",
    "util/SuspiciousDomains.js",
    "util/SuspiciousTlds.js",
    "util/RiskyHostingSites.js",
    "util/FpReductionEngines.js",
    "util/ScriptExts.js",
    "protection/ProtectionResult.js",
    "protection/ScoringEngineV2.js",
    "protection/SketchyUrlCheck.js",
    "protection/MimeCheck.js",
    "protection/Quad9Protection.js",
    "protection/RdapProtection.js",
    "protection/BrowserProtection.js"
);

// ─────────────────────────────────────────────────────────────────────────────
// STATE OVERVIEW — for troubleshooting service worker restarts and races
// ─────────────────────────────────────────────────────────────────────────────
//
// STATELESS (recomputed fresh every call, safe across SW restarts):
//   - DANGEROUS_EXTS, ARCHIVE_EXTS, EXECUTABLE_MIMES, BUILTIN_DO_NOT_CHECK_DOMAINS
//     → static constants, never mutated
//   - getBlockedExtension(), isTrustedDomain(), buildVtBlockReason()
//     → pure functions, no shared state
//
// STATEFUL — IN-MEMORY ONLY (lost on every SW restart, ~30s idle timeout):
//   - pendingChecks (Map)         → NOT persisted. If SW restarts while a
//                                    download is in-flight, the check is simply
//                                    lost — onChanged will still fire when the
//                                    download completes, but with no pending
//                                    record it will be treated as a new check.
//                                    Safe: worst case user sees warning a few
//                                    seconds later than optimal.
//   - runtimeCustomDomains (let)  → reloaded from chrome.storage.local on every
//                                    SW startup via loadCustomDomains().
//
// STATEFUL — PERSISTED (chrome.storage):
//   - chrome.storage.local["Settings"]
//       User preferences (API key, FP level, custom domains, etc). Survives
//       browser restarts and extension updates. Read via Settings.get().
//
// ARCHITECTURE — NEW (V1.8+):
//   Two-listener model. No pause/resume/cancel. Download always completes.
//   Download Sentinel is an information/warning tool, not a blocker.
//
//   onCreated  → start VT + Quad9 + RDAP calls, record startedAt timestamp
//   onChanged  → download complete: wait remaining budget (3250ms - elapsed),
//                run heuristics, calculate score, show warning or auto-proceed
//
// ─────────────────────────────────────────────────────────────────────────────

// ─────────────────────────────────────────────────────────────────────────────
// TIMER & WAIT-STATE REFERENCE
// ─────────────────────────────────────────────────────────────────────────────
//
// background.js
//   VT_WAIT_BUDGET_MS      3250ms  Total budget from startedAt to when we
//                                   give up waiting for VT in onChanged.
//                                   = 3000ms VT timeout
//                                   + 100ms BrowserProtection startup delay
//                                   + 50ms Settings.get overhead
//                                   + 50ms event loop jitter
//                                   + 50ms network RTT buffer
//                                   Timestamp set BEFORE API calls start so
//                                   the budget covers all setup overhead.
//
//   sweepStaleEntries       5 min  chrome.alarms recurring. Removes pendingChecks
//                                   entries older than ENTRY_MAX_AGE_MS (30 min).
//
//   ENTRY_MAX_AGE_MS        30 min Max lifetime of a pendingChecks record.
//
// BrowserProtection.js
//   timeoutId (VT fetch)    3000ms AbortController timeout on the VT API GET.
//   Startup delay            100ms Small pause before VT fetch.
//
// ─────────────────────────────────────────────────────────────────────────────

// ─────────────────────────────────────────────────────────────────────────────
// GUARDS REFERENCE
// ─────────────────────────────────────────────────────────────────────────────
//
// ── State guards ─────────────────────────────────────────────────────────────
//   checkedIds (Set)          onChanged dedup — onChanged can fire multiple
//                              times for the same download. This Set prevents
//                              double-processing. Cleaned up in onErased.
//
// ── No loop guards needed ────────────────────────────────────────────────────
//   The new architecture never calls pause()/resume(), so there is no
//   resume → onCreated loop to guard against. This entire category of
//   bugs is eliminated by design.
//
// ─────────────────────────────────────────────────────────────────────────────

"use strict";

// ── Timing constant ───────────────────────────────────────────────────────────
const VT_WAIT_BUDGET_MS = 3250; // see TIMER REFERENCE above

// ── Static extension lists ────────────────────────────────────────────────────

const DANGEROUS_EXTS = [
    "bat","chm","cmd","com","cpl","dll","exe","hta",
    "jse","js","lnk","msc","msi","msp","mst",
    "pif","ps1","ps1xml","ps2","ps2xml","psc1",
    "psc2","scr","vb","vbe","vbs","wsf","wsh",
    "appimage","awk","bash","bin","csh","deb",
    "ksh","out","php","pl","pm","py","pyc",
    "pyo","rb","rpm","run","sed","sh","tcl",
    "tcsh","zsh","elf","jnlp",
    "action","app","applescript","command",
    "mpkg","pkg","scpt","tool","workflow"
];

// Script extensions — single source of truth in util/ScriptExts.js
const SCRIPT_EXTS = ScriptExts.list;

const ARCHIVE_EXTS = [
    "zip","rar","7z","tar","iso","cab",
    "tar.gz","tar.bz2","tar.xz","tar.zst","tar.lz",
    "tar.lzma","tar.lzo","tar.Z","tar.sz",
    "gz","tgz",
    "bz2","tbz","tbz2",
    "xz","txz",
    "zst","tzst",
    "lz","lzma","lzo","lz4","lz5",
    "Z",
    "msix","msixbundle","appx","appxbundle","wim","swm",
    "img","dmg","vhd","vhdx","vmdk",
    "jar","war","ear","apk","ipa","xpi","crx",
    "ace","arc","arj","lha","lzh","sit","sitx","sea",
    "paq","pak","pk3","pk4","wad",
];

const EXECUTABLE_MIMES = new Set([
    "application/x-msdownload",
    "application/x-ms-dos-executable",
    "application/x-executable",
    "application/x-dosexec",
    "application/x-bat",
    "application/x-msi",
    "application/x-ms-installer",
    "application/x-powershell",
    "application/x-sh",
    "application/x-python",
    "application/x-perl",
    "application/x-php",
    "application/x-vbs",
    "application/x-javascript",
    "application/java-archive",
    "application/x-java-archive",
    "application/x-debian-package",
    "application/x-rpm",
    "application/x-appimage",
    "application/x-hta",
]);

// Built-in trusted domains — never checked
const BUILTIN_DO_NOT_CHECK_DOMAINS = [
    "chromewebstore.google.com",
    "drive.google.com",
    "apps.microsoft.com",
    "onedrive.live.com",
    "sharepoint.com",
    "apps.apple.com",
    "icloud.com"
];

let runtimeCustomDomains = [];

// ── pendingChecks ─────────────────────────────────────────────────────────────
// Keyed by downloadId. Holds the async check results while the download runs.
// In-memory only — see STATE OVERVIEW above for why this is acceptable.
// Bounded: swept every 5 min, max age 30 min. Max concurrent downloads is
// naturally limited by the browser.
const pendingChecks = new Map();
const checkedIds    = new Set(); // dedup guard for onChanged

const ENTRY_MAX_AGE_MS = 30 * 60 * 1000; // 30 min

// ── Helper functions ──────────────────────────────────────────────────────────

function getExtFromFilename(file) {
    const parts   = file.split(".");
    if (parts.length < 2) return null;
    const lastTwo = parts.slice(-2).join(".");
    const lastOne = parts[parts.length - 1];
    if (ARCHIVE_EXTS.includes(lastTwo))   return lastTwo;
    if (DANGEROUS_EXTS.includes(lastOne)) return lastOne;
    if (ARCHIVE_EXTS.includes(lastOne))   return lastOne;
    return null;
}

function extractFilenameFromUrl(url) {
    try {
        const path  = new URL(url).pathname;
        const parts = path.split("/");
        const last  = parts[parts.length - 1];
        return last.includes(".") ? decodeURIComponent(last) : null;
    } catch { return null; }
}

function getBlockedExtension(url, filename) {
    if (filename) {
        const ext = getExtFromFilename(filename.toLowerCase());
        if (ext) return ext;
    }
    if (url) {
        const fromUrl = extractFilenameFromUrl(url);
        if (fromUrl) {
            const ext = getExtFromFilename(fromUrl.toLowerCase());
            if (ext) return ext;
        }
    }
    return null;
}

function getAllDoNotCheckDomains() {
    return [...BUILTIN_DO_NOT_CHECK_DOMAINS, ...runtimeCustomDomains];
}

function isTrustedDomain(url) {
    try {
        const hostname = new URL(url).hostname.toLowerCase();
        return getAllDoNotCheckDomains().some(d =>
            hostname === d || hostname.endsWith("." + d)
        );
    } catch { return false; }
}

function setExtensionIcon(enabled) {
    const suffix = enabled ? "" : "_OFF";
    chrome.action.setIcon({
        path: {
            "16":  chrome.runtime.getURL(`assets/icons/icon16${suffix}.png`),
            "24":  chrome.runtime.getURL(`assets/icons/icon24${suffix}.png`),
            "32":  chrome.runtime.getURL(`assets/icons/icon32${suffix}.png`),
            "48":  chrome.runtime.getURL(`assets/icons/icon48${suffix}.png`),
            "128": chrome.runtime.getURL(`assets/icons/icon128${suffix}.png`)
        }
    }).catch(err => console.warn("[DS] setIcon failed:", err?.message));
}

function loadCustomDomains() {
    Settings.get(settings => {
        runtimeCustomDomains = Array.isArray(settings.customDomains)
            ? settings.customDomains : [];
        setExtensionIcon(settings.extensionEnabled !== false);
    });
}

function openWarningPage(downloadId) {
    chrome.windows.create({
        url:   chrome.runtime.getURL(`pages/warning/WarningPage.html?downloadId=${downloadId}`),
        type:  "popup",
        state: "maximized"
    });
}

// ── Startup ───────────────────────────────────────────────────────────────────

chrome.runtime.onStartup.addListener(loadCustomDomains);
chrome.runtime.onInstalled.addListener(loadCustomDomains);
loadCustomDomains();

// ── Sweep stale entries ───────────────────────────────────────────────────────

function sweepStaleEntries() {
    const cutoff = Date.now() - ENTRY_MAX_AGE_MS;
    for (const [id, item] of pendingChecks) {
        if ((item.startedAt || 0) < cutoff) {
            pendingChecks.delete(id);
            checkedIds.delete(id);
            BrowserProtection.abandonPendingRequests(id, "stale entry swept");
        }
    }
}

chrome.alarms.create("sweepStaleEntries", { periodInMinutes: 5 });
chrome.alarms.onAlarm.addListener(alarm => {
    if (alarm.name === "sweepStaleEntries") sweepStaleEntries();
});

// ─────────────────────────────────────────────────────────────────────────────
// onCreated — start API checks immediately, record timestamp
// ─────────────────────────────────────────────────────────────────────────────

chrome.downloads.onCreated.addListener(async downloadItem => {

    const settings = await new Promise(resolve => Settings.get(resolve));
    if (!settings.extensionEnabled) return;

    const url = downloadItem.finalUrl || downloadItem.url || "";
    if (!url) return;
    if (isTrustedDomain(url)) return;

    const ext        = getBlockedExtension(url, downloadItem.filename || "")
                    || getBlockedExtension(downloadItem.url || "", "");
    const isArchive  = ext && ARCHIVE_EXTS.includes(ext);
    const isDangerous = ext && DANGEROUS_EXTS.includes(ext);
    const mime       = (downloadItem.mime || "").split(";")[0].trim().toLowerCase();
    const isMimeExec = !isDangerous && !isArchive && EXECUTABLE_MIMES.has(mime);

    if (!isDangerous && !isArchive && !isMimeExec) return;

    const fileType = (isDangerous || isMimeExec) ? "executable" : "archive";
    const isScript = SCRIPT_EXTS.includes(ext);

    // Record startedAt BEFORE API calls so the budget covers all setup time
    const record = {
        id:         downloadItem.id,
        startedAt:  Date.now(),
        url,
        originalUrl: (downloadItem.url && downloadItem.url !== url) ? downloadItem.url : url,
        ext,
        fileType,
        isScript,
        filename:   downloadItem.filename   || "",
        mime:       downloadItem.mime        || "",
        totalBytes: downloadItem.totalBytes  || 0,

        // VT result — filled when check completes
        vtDone:          false,
        vtScore:         null,
        vtConfidence:    null,
        vtBreakdown:     null,
        vtHardRule:      null,
        vtRawStats:      null,
        vtFilteredStats: null,
        vtFpLevel:       null,

        // Host result — filled when check completes
        hostDone:   false,
        hostResult: null,

        // Settings snapshot for use in onChanged
        fpLevel:           settings.fpReductionLevel ?? "MEDIUM",
        autoAllow:         !!settings.autoAllow,
        autoAllowThreshold: settings.autoAllowThreshold ?? 80,
        vtApiKeySet:       !!(settings.isVtApiKeySet && settings.vtApiKey),
    };

    pendingChecks.set(downloadItem.id, record);

    // ── A. Host reputation (fast, no API key needed) ──────────────────────
    BrowserProtection.checkHostReputation(
        url, fileType, ext, record.mime, record.totalBytes, record.originalUrl, isScript
    ).then(hostResult => {
        const r = pendingChecks.get(downloadItem.id);
        if (!r) return;
        r.hostDone   = true;
        r.hostResult = hostResult;
    });

    // ── B. VT check ───────────────────────────────────────────────────────
    if (!settings.isVtApiKeySet || !settings.vtApiKey) {
        record.vtDone = true; // no key — treat as done immediately
        return;
    }

    BrowserProtection.checkIfUrlIsMalicious(downloadItem.id, url, result => {
        const r = pendingChecks.get(downloadItem.id);
        if (!r) return;
        r.vtDone         = true;
        r.vtScore         = result?.score           ?? null;
        r.vtConfidence    = result?.confidence      ?? null;
        r.vtBreakdown     = result?.breakdown       ?? null;
        r.vtHardRule      = result?.hardRuleApplied ?? null;
        r.vtRawStats      = result?.rawStats        ?? null;
        r.vtFilteredStats = result?.filteredStats   ?? null;
        r.vtFpLevel       = result?.fpLevel         ?? null;
    }, record.originalUrl);
});

// ─────────────────────────────────────────────────────────────────────────────
// onChanged — download complete: wait remaining budget, then act
// ─────────────────────────────────────────────────────────────────────────────

chrome.downloads.onChanged.addListener(async delta => {
    if (!delta.state || delta.state.current !== "complete") return;
    if (checkedIds.has(delta.id)) return; // dedup guard
    checkedIds.add(delta.id);

    const record = pendingChecks.get(delta.id);
    if (!record) return; // not a download we're tracking

    // ── Conditional wait: only wait what's left of the 3250ms budget ──────
    const elapsed  = Date.now() - record.startedAt;
    const waitLeft = Math.max(0, VT_WAIT_BUDGET_MS - elapsed);
    if (waitLeft > 0) await new Promise(r => setTimeout(r, waitLeft));

    // ── Get confirmed filename from Chrome (now that download is complete) ─
    let confirmedFilename = record.filename;
    try {
        const results = await chrome.downloads.search({ id: delta.id });
        confirmedFilename = results?.[0]?.filename || record.filename;
    } catch { /* use original */ }

    // ── Re-check extension with confirmed filename ─────────────────────────
    const confirmedExt = getBlockedExtension(record.url, confirmedFilename) || record.ext;

    // ── Apply VT-unknown multiplier to heuristic signals ──────────────────
    // When VT has no data, we scale negative heuristic signals based on the
    // FP reduction level. High FP reduction = conservative (less alarming),
    // None = aggressive (more alarming). This compensates for the missing
    // VT signal without over-penalising legitimate software.
    const vtUnknown = record.vtDone && record.vtScore === null;
    const fpMultiplier = vtUnknown ? {
        "HIGH":   0.5,
        "MEDIUM": 1.0,
        "LOW":    1.5,
        "NONE":   2.0,
    }[record.fpLevel] ?? 1.0 : 1.0;

    // ── Calculate combined score ───────────────────────────────────────────
    const hostScore = record.hostResult?.score ?? 0;
    const scaledHostScore = fpMultiplier !== 1.0
        ? Math.round(Math.min(0, hostScore) * fpMultiplier) + Math.max(0, hostScore)
        : hostScore;
    const vtScore   = record.vtScore ?? 0;
    const combined  = Math.max(-100, Math.min(100, vtScore + scaledHostScore));

    // ── Auto-proceed check — silent, no notification ────────────────────────
    if (record.autoAllow && combined >= record.autoAllowThreshold) {
        pendingChecks.delete(delta.id);
        return;
    }

    // ── Open warning page ─────────────────────────────────────────────────
    // Store final record for the warning page to read via GET_PENDING_CHECK
    record.confirmedExt      = confirmedExt;
    record.confirmedFilename = confirmedFilename;
    record.scaledHostScore   = scaledHostScore;
    record.combinedScore     = combined;
    record.fpMultiplier      = fpMultiplier;
    record.vtUnknown         = vtUnknown;
    record.state             = "complete";

    openWarningPage(delta.id);
});

// ── Cleanup on erase ─────────────────────────────────────────────────────────

chrome.downloads.onErased.addListener(downloadId => {
    pendingChecks.delete(downloadId);
    checkedIds.delete(downloadId);
    BrowserProtection.abandonPendingRequests(downloadId, "download erased");
});

// ─────────────────────────────────────────────────────────────────────────────
// Message listener
// ─────────────────────────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

    // Security: only accept messages from this extension's own pages
    if (sender.extensionId && sender.extensionId !== chrome.runtime.id) return;

    if (msg.type === "GET_PENDING_CHECK") {
        sendResponse(pendingChecks.get(msg.downloadId) || null);
        return true;
    }

    if (msg.type === "DISMISS_CHECK") {
        // User clicked OK or Check at VT — clean up
        BrowserProtection.abandonPendingRequests(msg.downloadId, "user dismissed");
        pendingChecks.delete(msg.downloadId);
        checkedIds.delete(msg.downloadId); // release dedup guard
        sendResponse({ success: true });
        return true;
    }

    if (msg.type === "EXTENSION_TOGGLE") {
        setExtensionIcon(msg.enabled);
        return true;
    }

    if (msg.type === "SETTINGS_UPDATED") {
        loadCustomDomains();
        return true;
    }

    // ── Submit URL to VT for fresh analysis ───────────────────────────────
    if (msg.type === "SUBMIT_URL_TO_VT") {
        const record = pendingChecks.get(msg.downloadId);
        if (!record) { sendResponse({ success: false, error: "Download not found" }); return true; }

        Settings.get(settings => {
            if (!settings.isVtApiKeySet || !settings.vtApiKey) {
                sendResponse({ success: false, error: "No VT API key" });
                return;
            }

            const cleanUrl = UrlUtils.cleanUrl(record.url);
            const urlId    = UrlUtils.toVtUrlId(cleanUrl);

            record.vtDone = false;
            sendResponse({ success: true });

            (async () => {
                try {
                    const formData = new URLSearchParams();
                    formData.append("url", cleanUrl);

                    const submitResponse = await fetch("https://www.virustotal.com/api/v3/urls", {
                        method:  "POST",
                        headers: {
                            "x-apikey":     settings.vtApiKey,
                            "Content-Type": "application/x-www-form-urlencoded"
                        },
                        body: formData.toString()
                    });

                    if (!submitResponse.ok) {
                        record.vtDone = true;
                        chrome.runtime.sendMessage({
                            type: "VT_RESULT_UPDATE", downloadId: msg.downloadId,
                            vtScore: null, vtRawStats: null
                        }).catch(() => {});
                        return;
                    }

                    const deadline = Date.now() + 15000;
                    while (Date.now() < deadline) {
                        await new Promise(r => setTimeout(r, 1000));
                        const getResponse = await fetch(
                            `https://www.virustotal.com/api/v3/urls/${urlId}`,
                            { method: "GET", headers: { "x-apikey": settings.vtApiKey } }
                        );
                        if (!getResponse.ok) continue;
                        const data = await getResponse.json();
                        const attrs = data?.data?.attributes ?? {};
                        const results = attrs.last_analysis_results ?? {};
                        if (Object.keys(results).length === 0) continue;

                        const fpLevel  = settings.fpReductionLevel ?? "MEDIUM";
                        const raw      = FpReductionEngines.getRawStats(results);
                        const filtered = FpReductionEngines.filterResults(results, fpLevel);
                        const eval_    = ScoringEngineV2.evaluate({
                            stats: filtered, rawStats: raw,
                            firstSubmissionDate: attrs.first_submission_date ?? null,
                            fpLevel
                        });

                        record.vtDone         = true;
                        record.vtScore         = eval_.score;
                        record.vtConfidence    = eval_.confidence;
                        record.vtBreakdown     = eval_.breakdown;
                        record.vtHardRule      = eval_.hardRuleApplied;
                        record.vtRawStats      = raw;
                        record.vtFilteredStats = filtered;
                        record.vtFpLevel       = fpLevel;

                        chrome.runtime.sendMessage({
                            type:         "VT_RESULT_UPDATE",
                            downloadId:   msg.downloadId,
                            vtScore:      record.vtScore,
                            vtConfidence: record.vtConfidence,
                            vtBreakdown:  record.vtBreakdown,
                            vtHardRule:   record.vtHardRule,
                            vtRawStats:   record.vtRawStats,
                            vtFilteredStats: record.vtFilteredStats,
                            vtFpLevel:    record.vtFpLevel
                        }).catch(() => {});
                        break;
                    }

                } catch (err) {
                    console.error("[DS:submit] error:", err?.message);
                    record.vtDone = true;
                }
            })();
        });
        return true;
    }
});
