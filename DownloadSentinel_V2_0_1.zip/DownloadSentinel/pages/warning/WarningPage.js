// ── Setup ──────────────────────────────────────────────────────────────────────

const params     = new URLSearchParams(location.search);
const downloadId = Number(params.get("downloadId"));

// Script extensions — loaded from util/ScriptExts.js (single source of truth)
const SCRIPT_EXTS_CLIENT = ScriptExts.list;

if (!downloadId) {
    document.body.innerHTML = "<p style='color:white;padding:2rem'>Invalid warning page — no download ID found.</p>";
    throw new Error("[DownloadSentinel] WarningPage opened without a valid downloadId");
}

// ── DOM refs ───────────────────────────────────────────────────────────────────

const reasonText            = document.getElementById("reasonText");
const srcUrl                = document.getElementById("srcUrl");

// Host reputation summary
const hostBox               = document.getElementById("hostBox");
const hostResult            = document.getElementById("hostResult");
const hostLabel             = document.getElementById("hostLabel");

// Combined details box
const combinedDetailsBox    = document.getElementById("combinedDetailsBox");
const vtSectionHeader       = document.getElementById("vtSectionHeader");
const vtUnknownLine         = document.getElementById("vtUnknownLine");
const vtDetailsList         = document.getElementById("vtDetailsList");
const vtClassificationLine  = document.getElementById("vtClassificationLine");
const heuristicsBox         = document.getElementById("heuristicsBox");
const hostDetailsList       = document.getElementById("hostDetailsList");

// Score bar
const worstScoreBox         = document.getElementById("worstScoreBox");
const worstScoreValue       = document.getElementById("worstScoreValue");
const worstScoreBarFill     = document.getElementById("worstScoreBarFill");
const scoreExplanation      = document.getElementById("scoreExplanation");

const btnOk                 = document.getElementById("btn-ok");
const btnVt                 = document.getElementById("btn-vt");
const disclaimer            = document.getElementById("disclaimerText");

let currentVtScore   = null;
let currentHostScore = null;
let lastHostData     = null;
let lastVtData       = null;  // last full VT data received

// ── Settings ───────────────────────────────────────────────────────────────────


function applySettings(settings) {
    const r = settings.warningColorR ?? 179;
    const g = settings.warningColorG ?? 38;
    const b = settings.warningColorB ?? 30;
    document.body.style.backgroundColor = `rgb(${r}, ${g}, ${b})`;

    // Apply custom window title (falls back to default if empty)
    const titleEl = document.getElementById("warningTitle");
    if (titleEl) {
        const t = (settings.warningTitle || "").trim() ||
            "Download requires your attention:<br>review before proceeding";
        titleEl.innerHTML = t;
    }
    // Store title for applySlippedThroughUi (same title for both pre and post)
    window._warningTitlePost = (settings.warningTitle || "").trim() ||
        "Download requires your attention:<br>review before opening";

    disclaimer.textContent = "This is what VT knows about the download URL, check the download itself at VT to be sure.";
}


Settings.get(applySettings);



// ── Score bar ──────────────────────────────────────────────────────────────────

function renderScoreBar(valueEl, fillEl, score) {
    const isPositive = score >= 0;
    const magnitude  = Math.min(100, Math.abs(score));
    valueEl.textContent = `${isPositive ? "+" : ""}${score}%`;
    valueEl.className   = "score-bar-value " + (isPositive ? "positive" : "negative");
    fillEl.className    = "score-bar-fill "  + (isPositive ? "positive" : "negative");
    fillEl.style.width  = `${magnitude}%`;
}

function confidenceLabel(score) {
    const sign = score >= 0 ? "+" : "";
    return `${sign}${score}%`;
}

function confidenceColor(score) {
    if (score >= SCORING_CONFIG.THRESHOLD_SAFE)         return "#34d399"; // green — probably safe
    if (score >= SCORING_CONFIG.THRESHOLD_QUESTIONABLE) return "#60a5fa"; // blue — probably inconclusive
    if (score >= SCORING_CONFIG.THRESHOLD_SUSPICIOUS)   return "#fbbf24"; // yellow — probably suspicious
    return "#ef4444";                   // red — probably malicious
}

function updateCombinedScore() {
    // Overall score = VT score + host score (additive).
    // Shows progressively: host score first, updates when VT arrives.
    const hasVt   = currentVtScore   !== null;
    const hasHost = currentHostScore !== null;

    if (!hasVt && !hasHost) {
        worstScoreBox.style.display = "none";
        return;
    }

    const combined = Math.max(-100, Math.min(100,
        (hasVt   ? currentVtScore   : 0) +
        (hasHost ? currentHostScore : 0)
    ));

    worstScoreBox.style.display = "";
    renderScoreBar(worstScoreValue, worstScoreBarFill, combined);
    scoreExplanation.style.display = "none";

    // Colour the warning title to match the combined score category
    const titleEl = document.getElementById("warningTitle");
    if (titleEl) {
        titleEl.style.color = confidenceColor(combined);
    }

    // Colour the Download URL Reputation label to match combined score
    if (hostLabel) {
        hostLabel.className = "label label-" + vtScoreToStyle(combined);
    }

    // VT confidence label
    const vtScoreRow = document.getElementById("vtScoreRow");
    const vtScoreVal = document.getElementById("vtScoreValue");
    if (vtScoreRow && hasVt) {
        vtScoreRow.style.display  = "";
        vtScoreVal.textContent    = confidenceLabel(currentVtScore);
        vtScoreVal.style.color    = confidenceColor(currentVtScore);
    }

    // Heuristics box: show host-only confidence score
    const hostScoreRow      = document.getElementById("hostScoreRow");
    const hostConfidenceVal = document.getElementById("hostConfidenceValue");
    if (hostScoreRow && hasHost) {
        hostScoreRow.style.display    = "";
        hostConfidenceVal.textContent = confidenceLabel(currentHostScore);
        hostConfidenceVal.style.color = confidenceColor(currentHostScore);
    }

}


// ── Classification helpers ─────────────────────────────────────────────────────

function classifyToStyle(classification) {
    if (!classification) return "vt-unknown";
    if (classification.includes("Malicious"))    return "vt-malicious";
    if (classification.includes("Suspicious"))   return "vt-suspicious";
    if (classification.includes("Inconclusive") || classification.includes("Questionable")) return "vt-questionable";
    if (classification.includes("Safe"))         return "vt-safe";
    return "vt-unknown";
}

// ── VT rendering ──────────────────────────────────────────────────────────────

function renderVtDetails(data) {
    const vtUnknown = !data.vtScore && data.vtDone;
    const vtEngineCounts = document.getElementById("vtEngineCounts");

    // Section header is no longer needed — engine counts are bullets themselves
    vtSectionHeader.style.display = "none";
    if (vtEngineCounts) vtEngineCounts.style.display = "none";

    vtDetailsList.innerHTML = "";
    vtClassificationLine.style.display = "none";
    vtUnknownLine.style.display        = "none";

    if (vtUnknown) {
        vtUnknownLine.style.display      = "";
        vtUnknownLine.style.marginBottom = "12px";
        combinedDetailsBox.style.display = "";
        return;
    }

    if (!data.vtRawStats && !data.vtBreakdown) {
        combinedDetailsBox.style.display = "";
        return;
    }

    // ── Engine count rows as bullet items ────────────────────────────────
    const raw      = data.vtRawStats     || {};
    const filtered = data.vtFilteredStats || {};
    const fpLevel  = data.vtFpLevel || "NONE";

    if (raw.malicious !== undefined) {
        // Bullet 1: all engines (unfiltered)
        const li1 = document.createElement("li");
        li1.appendChild(buildEngineCountsRow(raw, "(all results)"));
        vtDetailsList.appendChild(li1);

        // Bullet 2: after FP filter (only when FP reduction is active)
        if (fpLevel !== "NONE" && data.vtFilteredStats) {
            const li2 = document.createElement("li");
            li2.appendChild(buildEngineCountsRow(filtered,
                '<a class="fp-reduction-link" href="#" id="fpFilterLink">(with FP reduction)</a>'));
            vtDetailsList.appendChild(li2);

            setTimeout(() => {
                const link = document.getElementById("fpFilterLink");
                if (link) {
                    link.addEventListener("click", e => {
                        e.preventDefault();
                        chrome.runtime.openOptionsPage();
                    });
                }
            }, 0);
        }
    }

    // Bullet 3: First submitted to VT
    if (data.vtBreakdown?.age?.ageDays !== null && data.vtBreakdown?.age?.ageDays !== undefined) {
        const days = Math.round(data.vtBreakdown.age.ageDays);
        const li   = document.createElement("li");
        li.textContent = `First submitted to VT: ${days} day${days === 1 ? "" : "s"} ago`;
        vtDetailsList.appendChild(li);
    }

    // Show the VT classification line in the details box only when it adds
    // information beyond what the top "DOWNLOAD URL REPUTATION" box already
    // shows. When heuristics are negative the top box shows the heuristics
    // verdict, not the VT verdict — so the VT conclusion here is genuinely
    // different and worth showing. When the top box already shows the VT
    // verdict (heuristics are clean), showing it again here is redundant.
    if (data.vtBreakdown?.detection) {
        const classText      = vtClassificationText(data.vtScore);
        const topBoxIsVtText = lastHostData && !(typeof lastHostData.score === "number" && lastHostData.score < 0);
        if (!topBoxIsVtText) {
            // Top box is showing heuristics verdict — show VT conclusion here too
            vtClassificationLine.textContent   = classText;
            vtClassificationLine.className     = "value details-classification " + vtScoreToStyle(data.vtScore);
            vtClassificationLine.style.display = "";
        } else {
            vtClassificationLine.style.display = "none";
        }
    }

    combinedDetailsBox.style.display = "";
}

// Sanitize strings from background messages — strip anything that isn't
// printable ASCII + common punctuation. Labels are internally generated
// but this guards against any future message spoofing.
function sanitizeLabel(str) {
    if (typeof str !== "string") return "";
    return str.replace(/[^ -~À-ɏ]/g, "").slice(0, 200);
}

function buildEngineCountsRow(stats, suffixHtml) {
    const harmless   = (stats.harmless   || 0) + (stats.undetected || 0);
    const unknown    =  stats.unknown    || 0;
    const suspicious =  stats.suspicious || 0;
    const malicious  =  stats.malicious  || 0;

    // Build using DOM nodes so numbers from VT API never touch innerHTML
    const frag = document.createDocumentFragment();
    function addCell(label, value, cls) {
        const lbl = document.createElement("span");
        lbl.className = "ec-label";
        lbl.textContent = label;
        const num = document.createElement("span");
        num.className = "ec-num " + cls;
        num.textContent = String(value);
        frag.appendChild(lbl);
        frag.appendChild(num);
    }
    addCell("Not harmful:", harmless,   "ec-harmless");
    addCell("Unknown:",     unknown,    "ec-unknown");
    addCell("Suspicious:",  suspicious, "ec-suspicious");
    addCell("Malicious:",   malicious,  "ec-malicious");

    // suffix is trusted static HTML (hardcoded strings or our own link)
    const suffixSpan = document.createElement("span");
    suffixSpan.className = "ec-suffix";
    suffixSpan.innerHTML = suffixHtml; // only ever hardcoded strings
    frag.appendChild(suffixSpan);
    return frag;
}

function vtScoreToStyle(score) {
    if (score === null || score === undefined) return "vt-unknown";
    if (score >= SCORING_CONFIG.THRESHOLD_SAFE)         return "vt-safe";
    if (score >= SCORING_CONFIG.THRESHOLD_QUESTIONABLE) return "vt-questionable";
    if (score >= SCORING_CONFIG.THRESHOLD_SUSPICIOUS)   return "vt-suspicious";
    return "vt-malicious";
}

function vtClassificationText(score) {
    if (score === null || score === undefined) return "";
    if (score >= SCORING_CONFIG.THRESHOLD_SAFE)         return "VirusTotal rates it currently as probably safe";
    if (score >= SCORING_CONFIG.THRESHOLD_QUESTIONABLE) return "VirusTotal rates it currently as probably inconclusive";
    if (score >= SCORING_CONFIG.THRESHOLD_SUSPICIOUS)   return "VirusTotal rates it currently as probably suspicious";
    return "VirusTotal rates it currently as probably malicious";
}

function renderVtScore(data) {
    if (typeof data.vtScore !== "number") {
        if (data.vtDone) {
            currentVtScore = null;
                if (lastHostData) renderHostReputation(lastHostData);
        }
        return;
    }
    currentVtScore = data.vtScore;
    updateCombinedScore();
    // Re-render host box so the verdict label reflects the now-known VT result
    if (lastHostData) renderHostReputation(lastHostData);
}

function applyVtResult(data) {
    lastVtData = data;
    srcUrl.textContent     = (data.url || "Unknown URL").split("?")[0].split("#")[0];
    reasonText.textContent = data.ext ? "." + data.ext : "Unknown";
    renderVtScore(data);
    renderVtDetails(data);
    if (data.vtDone) vtDone = true;

}



function renderHostReputation(hostData) {
    if (!hostData) return;
    lastHostData = hostData;

    const vtUnknown = currentVtScore === null;

    if (hostData.score === null && !vtUnknown) {
        hostBox.style.display = "none";
        return;
    }

    // ── Overall verdict label ────────────────────────────────────────────────
    // Priority: VT verdict (when known) > heuristics (when negative) > VT unknown fallback
    hostBox.style.display = "";
    const hostIsNegative = typeof hostData.score === "number" && hostData.score < 0;
    const vtKnown        = currentVtScore !== null;

    // Combined score drives the verdict text in the top box
    const combined = Math.max(-100, Math.min(100,
        (vtKnown ? currentVtScore : 0) +
        (typeof hostData.score === "number" ? hostData.score : 0)
    ));

    if (vtKnown) {
        // VT result available — show combined verdict
        hostResult.textContent = vtClassificationText(combined);
        hostResult.className   = "value value-prominent " + vtScoreToStyle(combined);
    } else if (hostIsNegative) {
        // VT not yet available, heuristics already negative — show heuristics signal
        hostResult.textContent = sanitizeLabel(hostData.label || hostData.classification || "Checked");
        hostResult.className   = "value value-prominent " + classifyToStyle(hostData.classification);
    } else {
        // VT not yet available, heuristics clean — show heuristics label
        hostResult.textContent = sanitizeLabel(hostData.label || hostData.classification || "Checked");
        hostResult.className   = "value value-prominent " + classifyToStyle(hostData.classification);
    }

    if (typeof hostData.score === "number") {
        currentHostScore = hostData.score;
        updateCombinedScore();
    }

    // ── Heuristics section in combined details box ────────────────────────────
    combinedDetailsBox.style.display = "";
    hostDetailsList.innerHTML = "";

    // Quad9 — only show when negative (BLOCKED) or when VT unknown
    if (hostData.quad9?.status) {
        if (hostData.quad9.status === "BLOCKED") {
            const li = document.createElement("li");
            li.textContent = "Domain is on Quad9 blacklist (confirmed malicious)";
            hostDetailsList.appendChild(li);
        } else if (vtUnknown) {
            const li = document.createElement("li");
            li.textContent = "Domain not flagged by Quad9 as harmful";
            hostDetailsList.appendChild(li);
        }
    }

    // Scoring rows — only negative, no prefix labels
    const rows = hostData.breakdown || [];
    for (const row of rows) {
        if (row.source === "Quad9") continue;
        if (row.score >= 0) continue;
        const li = document.createElement("li");
        li.textContent = sanitizeLabel(row.label);
        hostDetailsList.appendChild(li);
    }



    // Always show divider; when no signals, add a reassuring note
    if (heuristicsBox) heuristicsBox.style.display = "";
    if (hostDetailsList.children.length === 0) {
        const li = document.createElement("li");
        li.textContent = "Heuristics found no alarming signals";
        li.style.color = "#6b7280"; // muted — not a warning, just informational
        hostDetailsList.appendChild(li);
    }
}

// ── Cancel / Allow ────────────────────────────────────────────────────────────

// OK — acknowledge and close
btnOk?.addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "DISMISS_CHECK", downloadId }, () => window.close());
});

// Check download at VT — open VT and close
btnVt?.addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "DISMISS_CHECK", downloadId }, () => {
        chrome.tabs.create({ url: "https://www.virustotal.com/gui/home/url" });
        window.close();
    });
});

// ── Initial render — results are always complete when page opens ──────────────
// In the new architecture (V1.8+), background.js waits for all checks to
// finish before opening the warning page. No polling or push messages needed —
// we fetch the record once and render everything in a single pass.

chrome.runtime.sendMessage(
    { type: "GET_PENDING_CHECK", downloadId },
    data => {
        if (!data) {
            document.body.style.opacity = "0.5";
            srcUrl.textContent = "Download no longer active — you can close this window.";
            return;
        }
        // Single render pass — all fields are final
        applyVtResult(data);
        if (data.hostResult) renderHostReputation(data.hostResult);
    }
);
