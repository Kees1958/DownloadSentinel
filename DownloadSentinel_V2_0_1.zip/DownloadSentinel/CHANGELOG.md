# Download Sentinel — Changelog

## V1.8 (current)
- **Auto-proceed feature**: option to automatically allow downloads above a configurable risk score threshold. Silent browser notification confirms the check passed.
- **Post-download safety net**: `onChanged` listener catches files that slip through the `onCreated` pause race (small/fast files). Shows a brief warning page with VT results, auto-closes if score is above threshold.
- **Two-score UI**: host reputation and VT each show their own confidence score; overall bar shows the combined total (VT + heuristics).
- **Scoring overhaul**: simple additive scoring (VT score + age score + heuristics), replacing the 70/30 weighted split.
- **ABC consensus bonus**: percentage-based clean-engine bonus replaces hard engine count cut-offs. Hard block when URL < 7 days old at VT.
- **Warning page titles**: customisable pre- and post-download titles with better defaults.
- **Options page restructure**: single Save All Settings button; Personalise warning page as collapsible section; API key Save button colour reflects key state.
- **Loop guard**: `interceptPaused` boolean (10s) prevents `resume()` → `onCreated` → warning page endless loop.
- **Maintainability**: `SCORING_CONFIG` object centralises all scoring thresholds; `ScriptExts.js` shared across all files; guards/timers reference comments added.
- **Security**: sender validation on warning page message listener; `sanitizeLabel()` on background-sourced strings; `web_accessible_resources` restricted to extension pages only.
- **Performance**: `chrome.alarms` replaces unreliable `setInterval` for sweep; `abortControllers` leak fixed; `allowedUrls` capped at 200 entries with FIFO eviction; dead `FpEngines.js` removed.

## V1.7
- **Scoring refactor**: VT + age additive scoring; ABC consensus bonus; risky hosting scores rebalanced (GitHub CDN −10, Discord −20, etc.).
- **TLD list**: removed `.app`, `.dev`, `.cloud`, `.tech`, `.pro`; recalibrated remaining scores.
- **MIME check**: `text/plain` neutral for binaries, mild penalty (−20) for scripts.
- **Script detection**: new `SCRIPT_EXTS` list; `−25` heuristic signal for script-format downloads.
- **Duplicate domains removed**: `SuspiciousDomains.js` and `RiskyHostingSites.js` de-duplicated.
- **FP reduction engine moves**: AlphaMountain, Forcepoint ThreatSeeker, CTX AI moved to MEDIUM.

## V1.4.2
- **Two-box layout**: VT and heuristics in separate info boxes, each with own confidence score.
- **VT classification line**: only shown in VT box when it differs from top-level verdict.
- **Heuristics confidence**: shown in dedicated heuristics box.

## V1.4.1
- Fixed duplicate "VirusTotal rates it currently as..." line in VT details box.

## V1.4
- **Post-download safety net**: `onChanged` listener, slipped-through warning page, `slippedThrough` state.
- **Performance/memory**: `chrome.alarms` sweep, `abortControllers` delete-not-replace, `BoundedUrlSet` for `allowedUrls`, dead file removed.
- **`allowedDomains` bug**: permanent bypass on successful re-download fixed; converted to TTL Map.
- **Security audit**: `web_accessible_resources` restricted; DOM node construction for engine counts; sender validation; `sanitizeLabel`.
- **Startup race**: `startupRestorePromise` ensures `blockedDownloads` restore completes before listeners use it.
- **Stale entry sweep**: `sweepStaleEntries` every 5 min via `chrome.alarms`, `createdAt` timestamps on records.

## V1.3 (Chrome Web Store initial submission)
- Warning page with VT URL reputation check, host heuristics, overall risk score.
- FP reduction slider (HIGH / MEDIUM / LOW / NONE) with canonical deduplication.
- Engine count rows (all results + with FP reduction).
- Options page: API key, FP reduction, background colour, trusted domains.
- Post-download disclaimer with VT link.
- `ProtectionResult` extended with `rawStats`, `filteredStats`, `fpLevel`.
- Suspicious domain label shows `matchedDomain`.
- DOWNLOAD URL HEURISTICS divider hidden when no signals.
