"use strict";

/**
 * Quad9Protection.js
 * Checks a hostname against Quad9's malware-blocking DNS-over-HTTPS resolver.
 *
 * If Quad9 returns NXDOMAIN (Status 3) with no Authority records, the domain
 * is actively blocked by Quad9's threat-intel feed → score −100.
 *
 * A result that is neither BLOCKED nor ALLOWED carries a `reasonCode` (see
 * UNKNOWN_REASON below) so callers can tell "no threat-intel data for this
 * host" apart from a timeout, an HTTP error, or NXDOMAIN — these are not
 * interchangeable and the UI shows each one differently.
 *
 * ── Wire format, not the JSON convenience format (v3.0.4) ────────────────
 * This used to query `?name=<host>&type=A` with `Accept: application/dns-json`
 * — a convenience format that is NOT documented anywhere in Quad9's own FAQ
 * (which only ever describes "DNS over HTTPS queries can be sent to:
 * https://dns.quad9.net/dns-query", i.e. the standard RFC 8484 binary wire
 * format). Quad9 also retired a separate JSON-based DNS service in May 2025
 * ("diminishing query volume" for non-standard formats) — consistent with
 * JSON-style convenience endpoints not being something they commit to
 * supporting long-term. Reports of "Quad9 lookup failed (network error)"
 * firing reliably, with no way to tell why from the UI (the generic catch
 * swallowed the real fetch error), led to switching this module to the one
 * format Quad9 actually documents: a binary DNS query, base64url-encoded
 * into the `?dns=` query parameter, requesting `Accept: application/dns-message`
 * — same URL, same resolver, same blocklist, just the protocol Quad9
 * actually promises to keep working. See DOCS/CHANGELOG.md's v3.0.4 entry.
 *
 * Adapted from CallQuad9.js for use as an ES module.
 */
import { APP } from "../util/AppConstants.js";

export const Quad9Protection = (function () {

    const QUAD9_DOH  = "https://dns.quad9.net/dns-query";
    const TIMEOUT_MS = APP.QUAD9_TIMEOUT_MS; // defined in AppConstants.js

    // ── DNS wire-format (RFC 1035 / RFC 8484) constants — every magic number
    // for the query/response codec gathered here, single source of truth.
    const DNS = Object.freeze({
        TYPE_A:      1,
        TYPE_CNAME:  5,
        TYPE_AAAA:   28,
        CLASS_IN:    1,
        RCODE_NXDOMAIN: 3,
        HEADER_BYTES:   12,
        MAX_LABEL_BYTES: 63,   // RFC 1035 §2.3.4 — a single DNS label can't exceed this
        MAX_NAME_BYTES:  255,  // RFC 1035 §2.3.4 — a full encoded name can't exceed this
        POINTER_FLAG:    0xC0, // top two bits of a length byte mark a compression pointer
        MAX_POINTER_HOPS: 20,  // guard against a malicious/malformed response with a pointer loop
    });

    // ── UNKNOWN reason codes ────────────────────────────────────────────────
    // Single source of truth for *why* a check landed on UNKNOWN instead of
    // BLOCKED/ALLOWED. The UI (WarningPage.js) maps each code to its own
    // display text — never infer the reason from the free-text `reason`/
    // `label` string, which exists for logs/debugging only and may change
    // wording without notice.
    const UNKNOWN_REASON = Object.freeze({
        NO_THREAT_DATA: "NO_THREAT_DATA", // kept for the UI text table's forward-compat (see WarningPage.js); the wire-format protocol has no equivalent of the old JSON endpoint's "no threat data" 400 — a clean domain simply resolves (ALLOWED) — so this is never emitted here any more
        REQUEST_FAILED: "REQUEST_FAILED", // Quad9 API returned a non-OK HTTP status, or returned 200 with a body that didn't parse as a valid DNS message
        NXDOMAIN:       "NXDOMAIN",       // Name genuinely doesn't exist (NXDOMAIN + Authority present)
        NO_ANSWER:      "NO_ANSWER",      // OK response but no usable A/AAAA/CNAME records
        TIMEOUT:        "TIMEOUT",        // Request aborted after TIMEOUT_MS with no response
        ERROR:          "ERROR"           // Network failure or other unexpected exception
    });

    // ── DNS query encoding ──────────────────────────────────────────────────
    // Builds a minimal standards-compliant question: one QNAME/A/IN query,
    // recursion desired, no EDNS (not needed over HTTPS — there's no UDP
    // packet-size concern this would exist to solve).
    function encodeHostnameLabels(hostname) {
        const labels = hostname.split(".").filter(Boolean); // filter(Boolean) drops a trailing-dot's empty label
        const bytes = [];
        for (const label of labels) {
            const labelBytes = new TextEncoder().encode(label);
            if (labelBytes.length === 0 || labelBytes.length > DNS.MAX_LABEL_BYTES) return null; // malformed — refuse rather than build a corrupt query
            bytes.push(labelBytes.length, ...labelBytes);
        }
        bytes.push(0); // root label terminator
        return bytes.length <= DNS.MAX_NAME_BYTES ? bytes : null;
    }

    function encodeDnsQuery(hostname) {
        const qname = encodeHostnameLabels(hostname);
        if (!qname) return null;

        const header = [
            0x00, 0x00, // ID — 0 is fine, HTTP request/response pairing makes it redundant
            0x01, 0x00, // flags: RD (recursion desired) set, everything else 0
            0x00, 0x01, // QDCOUNT = 1
            0x00, 0x00, // ANCOUNT = 0
            0x00, 0x00, // NSCOUNT = 0
            0x00, 0x00, // ARCOUNT = 0
        ];
        const question = [...qname, 0x00, DNS.TYPE_A, 0x00, DNS.CLASS_IN];
        return new Uint8Array([...header, ...question]);
    }

    // base64url (no padding) — the form RFC 8484 requires for the `?dns=` param.
    function toBase64Url(bytes) {
        let binary = "";
        for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
        return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
    }

    // ── DNS response decoding ────────────────────────────────────────────────
    // Reads a (possibly compressed, RFC 1035 §4.1.4) name starting at offset;
    // returns { name, nextOffset } where nextOffset is just past the name AS
    // IT APPEARS IN THE MESSAGE (i.e. just past the first pointer byte pair,
    // not wherever a pointer jumped to) — callers use nextOffset to continue
    // reading the record that contained this name.
    function readName(view, startOffset) {
        const labels = [];
        let offset = startOffset;
        let afterFirstPointer = -1;
        let hops = 0;

        for (;;) {
            if (offset >= view.byteLength) throw new RangeError("name runs past end of message");
            const length = view.getUint8(offset);

            if ((length & DNS.POINTER_FLAG) === DNS.POINTER_FLAG) {
                if (++hops > DNS.MAX_POINTER_HOPS) throw new RangeError("too many compression pointer hops");
                if (afterFirstPointer === -1) afterFirstPointer = offset + 2; // first pointer ends the caller-visible region
                const pointerByte2 = view.getUint8(offset + 1);
                offset = ((length & 0x3F) << 8) | pointerByte2;
                continue;
            }
            if (length === 0) { offset += 1; break; } // root label — name ends here
            if (length > DNS.MAX_LABEL_BYTES) throw new RangeError("label exceeds max length");

            const labelStart = offset + 1;
            const labelBytes = new Uint8Array(view.buffer, view.byteOffset + labelStart, length);
            labels.push(new TextDecoder().decode(labelBytes));
            offset = labelStart + length;
        }

        return {
            name: labels.join("."),
            nextOffset: afterFirstPointer !== -1 ? afterFirstPointer : offset,
        };
    }

    /**
     * Parse a raw DNS wire-format response.
     * @returns {{ rcode: number, answerCount: number, authorityCount: number,
     *             answers: string[] }}
     */
    function parseDnsResponse(buffer) {
        const view = new DataView(buffer);
        if (buffer.byteLength < DNS.HEADER_BYTES) throw new RangeError("response shorter than a DNS header");

        const flags          = view.getUint16(2);
        const rcode           = flags & 0x0F;
        const questionCount   = view.getUint16(4);
        const answerCount     = view.getUint16(6);
        const authorityCount  = view.getUint16(8);

        let offset = DNS.HEADER_BYTES;
        for (let i = 0; i < questionCount; i++) {
            offset = readName(view, offset).nextOffset;
            offset += 4; // QTYPE (2) + QCLASS (2)
        }

        const answers = [];
        for (let i = 0; i < answerCount; i++) {
            offset = readName(view, offset).nextOffset;
            const type     = view.getUint16(offset);
            offset += 8; // TYPE (2) + CLASS (2) + TTL (4)
            const rdLength = view.getUint16(offset);
            offset += 2;

            if (type === DNS.TYPE_A && rdLength === 4) {
                const octets = [0, 1, 2, 3].map(j => view.getUint8(offset + j));
                answers.push(octets.join("."));
            } else if (type === DNS.TYPE_AAAA && rdLength === 16) {
                const groups = [];
                for (let j = 0; j < 16; j += 2) groups.push(view.getUint16(offset + j).toString(16));
                answers.push(groups.join(":"));
            } else if (type === DNS.TYPE_CNAME) {
                answers.push(readName(view, offset).name);
            }
            // Any other record type is skipped for our purposes — BLOCKED/
            // ALLOWED only cares whether *some* usable address/alias exists.

            offset += rdLength;
        }

        return { rcode, answerCount, authorityCount, answers };
    }

    /**
     * Query Quad9 DoH (standard wire format) for a hostname.
     * @param {string} hostname
     * @param {AbortSignal} [signal]
     * @returns {Promise<{ status: "BLOCKED"|"ALLOWED"|"UNKNOWN", reasonCode?: string, reason?: string, answers?: string[] }>}
     */
    async function checkHostname(hostname, signal) {
        const query = encodeDnsQuery(hostname);
        if (!query) {
            return {
                status:     "UNKNOWN",
                reasonCode: UNKNOWN_REASON.REQUEST_FAILED,
                reason:     "Hostname could not be encoded as a DNS query"
            };
        }

        const url = `${QUAD9_DOH}?dns=${toBase64Url(query)}`;
        const response = await fetch(url, {
            headers: { Accept: "application/dns-message" },
            signal
        });

        if (!response.ok) {
            return {
                status:     "UNKNOWN",
                reasonCode: UNKNOWN_REASON.REQUEST_FAILED,
                reason:     `Quad9 request failed (${response.status})`
            };
        }

        let parsed;
        try {
            parsed = parseDnsResponse(await response.arrayBuffer());
        } catch {
            return {
                status:     "UNKNOWN",
                reasonCode: UNKNOWN_REASON.REQUEST_FAILED,
                reason:     "Quad9 response could not be parsed as a DNS message"
            };
        }

        // NXDOMAIN — domain either blocked or genuinely non-existent
        if (parsed.rcode === DNS.RCODE_NXDOMAIN) {
            // Quad9 heuristic: Authority count 0 → actively blocked by threat-intel
            //                  Authority count >0 → domain simply doesn't exist
            if (parsed.authorityCount === 0) {
                return {
                    status: "BLOCKED",
                    reason: "Domain blocked by Quad9 threat-intelligence feed"
                };
            }
            return {
                status:     "UNKNOWN",
                reasonCode: UNKNOWN_REASON.NXDOMAIN,
                reason:     "Domain does not exist (NXDOMAIN)"
            };
        }

        if (parsed.answers.length === 0) {
            return {
                status:     "UNKNOWN",
                reasonCode: UNKNOWN_REASON.NO_ANSWER,
                reason:     parsed.answerCount === 0 ? "No DNS answer records returned" : "No A/AAAA/CNAME records found"
            };
        }

        return { status: "ALLOWED", answers: parsed.answers };
    }

    /**
     * Public API: check a hostname with a hard timeout.
     *
     * Returns:
     *   { status, score, label, reason?, reasonCode?, answers? }
     *
     *   status "BLOCKED"  → score −100, label "Confirmed malicious"
     *   status "ALLOWED"  → score 0 (neutral; RDAP age will add its own signal)
     *   status "UNKNOWN"  → score 0 (no data, don't penalise); reasonCode is
     *                       always set to one of UNKNOWN_REASON's values so
     *                       the UI can distinguish timeout / HTTP error /
     *                       NXDOMAIN / no-data without parsing free text
     */
    async function check(hostname) {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort("timeout"), TIMEOUT_MS);

        try {
            const result = await checkHostname(hostname, controller.signal);
            clearTimeout(timer);

            if (result.status === "BLOCKED") {
                return {
                    status:  "BLOCKED",
                    score:   -100,
                    label:   "Confirmed malicious (blocked by Quad9)",
                    reason:  result.reason
                };
            }

            if (result.status === "ALLOWED") {
                return {
                    status:   "ALLOWED",
                    score:    0,
                    label:    "Resolved (not on Quad9 block list)",
                    answers:  result.answers
                };
            }

            // UNKNOWN — no usable verdict either way (see UNKNOWN_REASON for why)
            return {
                status:     "UNKNOWN",
                score:      0,
                label:      result.reason || "No Quad9 data",
                reasonCode: result.reasonCode || UNKNOWN_REASON.ERROR
            };

        } catch (err) {
            clearTimeout(timer);
            if (err.name === "AbortError") {
                return {
                    status:     "UNKNOWN",
                    score:      0,
                    label:      "Quad9 check timed out",
                    reasonCode: UNKNOWN_REASON.TIMEOUT
                };
            }
            return {
                status:     "UNKNOWN",
                score:      0,
                label:      `Quad9 error: ${err.message}`,
                reasonCode: UNKNOWN_REASON.ERROR
            };
        }
    }

    return { check };
})();
