"use strict";

class ProtectionResult {
    /**
     * Constructor function for creating a browser protection result object.
     * @param {string} urlChecked - The URL that was checked.
     * @param {string} resultType - The result type of the protection check (e.g., "allowed", "malicious").
     * @param {number} resultOrigin - The origin of the result (e.g., from endpoint or known top site).
     */
    constructor(urlChecked, resultType, resultOrigin) {
        this.url = urlChecked;
        this.result = resultType;
        this.origin = resultOrigin;
    }
}

ProtectionResult.ResultType = {
    FAILED: "Failed",
    UNKNOWN: "Unknown",
    ALLOWED: "Allowed",
    SUSPICIOUS: "Suspicious",
    MALICIOUS: "Malicious"
};

ProtectionResult.ResultOrigin = {
    UNKNOWN: 0, // The result was determined via an unknown origin
    VIRUSTOTAL: 15 // The result was determined via VirusTotal
};

ProtectionResult.ResultOriginNames = {
    0: "Unknown",
    15: "VirusTotal"
};
