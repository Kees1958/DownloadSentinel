"use strict";

/**
 * BrowserProtection.js
 *
 * Orchestrates two independent reputation axes, run simultaneously:
 *
 *   A. VirusTotal URL check  (existing logic, community score removed)
 *   B. Host reputation       (Quad9 + RDAP + domain list + TLD list + URL pattern)
 *
 * Both complete independently. The caller (background.js) stores and
 * forwards both result objects to the warning page. The warning page
 * reports the worst overall score but shows both info boxes.
 *
 * URL cleaning is delegated to UrlUtils (shared module).
 */
const BrowserProtection = (function () {

    let abortControllers = new Map();

    function closeOpenConnections(key, reason) {
        if (abortControllers.has(key)) {
            abortControllers.get(key).abort(reason);
            abortControllers.set(key, new AbortController());
        }
    }

    // ── VT helpers ─────────────────────────────────────────────────────────

    function unknownVtResult(url, startTime, callback) {
        callback(
            new ProtectionResult(
                url,
                ProtectionResult.ResultType.UNKNOWN,
                ProtectionResult.ResultOrigin.VIRUSTOTAL
            ),
            Date.now() - startTime
        );
    }

    // ── Host-reputation check ───────────────────────────────────────────────

    /**
     * Run all four host-reputation checks simultaneously and return a combined
     * host-reputation result object.
     *
     * @param {string} url       - Original download URL
     * @param {string} fileType  - "executable" | "archive"
     * @returns {Promise<object>} hostResult
     */
    async function checkHostReputation(url, fileType) {

        const hostname = UrlUtils.getHostname(url);
        const tld      = UrlUtils.getTld(hostname);

        // Synchronous lookups — no network needed
        const domainHit  = SuspiciousDomains.lookup(hostname);
        const tldHit     = SuspiciousTlds.lookup(tld);
        const sketchyUrl = SketchyUrlCheck.check(url);

        // Async: Quad9 and RDAP run in parallel.
        // RDAP is kicked off immediately; we only *use* its result when Quad9
        // resolves (ALLOWED), but starting it now hides its latency.
        const registeredDomain = UrlUtils.getRegisteredDomain(hostname);

        const [quad9Result, rdapResult] = await Promise.all([
            Quad9Protection.check(hostname),
            RdapProtection.check(registeredDomain)
        ]);

        // If Quad9 blocked the domain, RDAP age is irrelevant to that signal
        // (but still shown in the breakdown if available).
        const rdapForScoring = (quad9Result.status === "ALLOWED") ? rdapResult : rdapResult;

        const evaluation = ScoringEngineV2.evaluateHostReputation({
            quad9:     quad9Result,
            rdap:      rdapForScoring,
            domainHit,
            tldHit,
            sketchyUrl,
            fileType
        });

        return {
            hostname,
            tld,
            registeredDomain,
            quad9:      quad9Result,
            rdap:       rdapResult,
            domainHit,
            tldHit,
            sketchyUrl,
            score:           evaluation.score,
            classification:  evaluation.classification,
            label:           evaluation.label,
            hardRuleApplied: evaluation.hardRuleApplied,
            breakdown:       evaluation.breakdown
        };
    }

    // ─────────────────────────────────────────────────────────────────────────

    return {

        abandonPendingRequests(key, reason) {
            closeOpenConnections(key, reason);
        },

        /**
         * Run VT URL check.
         * Called from background.js after download is intercepted.
         * Host reputation is run separately via checkHostReputation().
         */
        checkIfUrlIsMalicious(key, url, callback) {

            if (!key || !url || typeof callback !== "function") return;

            let urlObject;
            try { urlObject = new URL(url); }
            catch {
                console.warn("[DS:BrowserProtection] Invalid URL, skipping VT check:", url);
                return;
            }

            const startTime = Date.now();

            if (!abortControllers.has(key)) {
                abortControllers.set(key, new AbortController());
            }

            const doVtCheck = async (settings) => {

                if (!settings.extensionEnabled)               return;
                if (!settings.virusTotalEnabled)              return;
                if (!settings.isVtApiKeySet || !settings.vtApiKey) return;

                // Session cache: skip re-checking URLs already classified as safe
                if (BrowserProtection.allowedUrls.has(UrlUtils.cleanUrl(url))) {
                    callback(
                        new ProtectionResult(
                            url,
                            ProtectionResult.ResultType.PROBABLY_SAFE,
                            ProtectionResult.ResultOrigin.VIRUSTOTAL,
                            { score: 100, confidence: "Cached", hardRuleApplied: null }
                        ),
                        Date.now() - startTime
                    );
                    return;
                }

                const controller = abortControllers.get(key);
                const signal     = controller?.signal;

                let callbackFired = false;

                const timeoutId = setTimeout(() => {
                    if (callbackFired) return;
                    callbackFired = true;
                    controller?.abort("timeout");
                    unknownVtResult(url, startTime, callback);
                }, 15000);

                try {
                    // Small delay so warning page is mounted before result arrives
                    await new Promise(r => setTimeout(r, 100));

                    const urlId    = UrlUtils.toVtUrlId(url);
                    const response = await fetch(
                        `https://www.virustotal.com/api/v3/urls/${urlId}`,
                        { method: "GET", headers: { "x-apikey": settings.vtApiKey }, signal }
                    );

                    clearTimeout(timeoutId);
                    if (callbackFired) return;
                    callbackFired = true;

                    if (!response.ok) {
                        unknownVtResult(url, startTime, callback);
                        return;
                    }

                    const data       = await response.json();
                    const attributes = data?.data?.attributes ?? {};
                    const stats      = attributes.last_analysis_stats ?? {};

                    const evaluation = ScoringEngineV2.evaluate({
                        stats,
                        firstSubmissionDate: attributes.first_submission_date ?? null
                    });

                    const cleanUrl = UrlUtils.cleanUrl(url);
                    if (evaluation.classification === ProtectionResult.ResultType.PROBABLY_SAFE) {
                        BrowserProtection.allowedUrls.add(cleanUrl);
                    }

                    callback(
                        new ProtectionResult(
                            url,
                            evaluation.classification,
                            ProtectionResult.ResultOrigin.VIRUSTOTAL,
                            {
                                score:           evaluation.score,
                                confidence:      evaluation.confidence,
                                breakdown:       evaluation.breakdown,
                                hardRuleApplied: evaluation.hardRuleApplied
                            }
                        ),
                        Date.now() - startTime
                    );

                } catch (error) {
                    clearTimeout(timeoutId);
                    if (error.name === "AbortError") return;
                    if (callbackFired) return;
                    callbackFired = true;
                    console.warn("[DS:BrowserProtection] VT fetch error:", error?.message);
                    unknownVtResult(url, startTime, callback);
                }
            };

            Settings.get(settings => doVtCheck(settings));
        },

        /**
         * Run host-reputation checks for a download.
         * Returns a Promise that resolves with the host-reputation result.
         */
        checkHostReputation

    };

})();

BrowserProtection.allowedUrls = new Set();
