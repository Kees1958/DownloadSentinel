"use strict";

/**
 * SketchyUrlCheck.js
 *
 * Heuristic analysis of a download URL's structural properties.
 * Returns a score 0–100 (0 = nothing suspicious, 100 = maximally sketchy).
 *
 * Checks performed (in order):
 *   1. IP address as host                          → +25
 *   2. Punycode (xn--) — homograph/lookalike trick → +30
 *   3. Excessive subdomains (> 3 labels)           → +10
 *   4. Brand impersonation in hostname             → +15 per matched brand
 *   5. Digit-as-letter lookalike (0→o, 1→i/l …)   → fills remaining headroom to 100
 *
 * Dropped vs. original sketch:
 *   - Brand name in path  (too much noise)
 *   - Urgency words in path (too much noise)
 *   - Special characters in hostname (too much noise)
 *   - Raw digit count (replaced by lookalike rule)
 *   - Suspicious TLD (scored as a separate host-reputation check in ScoringEngineV2)
 */
const SketchyUrlCheck = (function () {

    // ── Brand table ────────────────────────────────────────────────────────────
    // canonical = the real hostname the brand owns.
    // Any host containing the keyword that is NOT the canonical or a subdomain
    // of it is flagged as impersonation.
    const BRANDS = [
        // Identity / OS / Productivity
        { keyword: "microsoft",     canonical: "microsoft.com"       },
        { keyword: "office",        canonical: "office.com"          },
        { keyword: "onedrive",      canonical: "onedrive.com"        },
        { keyword: "teams",         canonical: "teams.microsoft.com" },
        { keyword: "google",        canonical: "google.com"          },
        { keyword: "gmail",         canonical: "gmail.com"           },
        { keyword: "googledrive",   canonical: "drive.google.com"    },
        { keyword: "apple",         canonical: "apple.com"           },
        { keyword: "icloud",        canonical: "icloud.com"          },
        // E-commerce / Finance
        { keyword: "amazon",        canonical: "amazon.com"          },
        { keyword: "paypal",        canonical: "paypal.com"          },
        { keyword: "bankofamerica", canonical: "bankofamerica.com"   },
        { keyword: "hsbc",          canonical: "hsbc.com"            },
        { keyword: "revolut",       canonical: "revolut.com"         },
        // Social / Media
        { keyword: "meta",          canonical: "meta.com"            },
        { keyword: "facebook",      canonical: "facebook.com"        },
        { keyword: "instagram",     canonical: "instagram.com"       },
        { keyword: "netflix",       canonical: "netflix.com"         },
        { keyword: "spotify",       canonical: "spotify.com"         },
        { keyword: "linkedin",      canonical: "linkedin.com"        },
        // Productivity / Collaboration
        { keyword: "adobe",         canonical: "adobe.com"           },
        { keyword: "dropbox",       canonical: "dropbox.com"         },
        { keyword: "docusign",      canonical: "docusign.com"        },
        { keyword: "zoom",          canonical: "zoom.us"             },
        { keyword: "slack",         canonical: "slack.com"           },
        // Logistics
        { keyword: "fedex",         canonical: "fedex.com"           },
        { keyword: "dhl",           canonical: "dhl.com"             },
        { keyword: "ups",           canonical: "ups.com"             },
    ];

    // Digits visually similar to letters used in homograph/typosquatting attacks:
    // 0→o, 1→i/l, 3→e, 4→a, 5→s, 6→g, 8→b
    const LOOKALIKE_DIGITS = new Set(["0", "1", "3", "4", "5", "6", "8"]);

    /**
     * Returns true when the hostname contains a lookalike digit adjacent to
     * or between letters — indicating deliberate character substitution.
     * e.g. "micr0s0ft", "g00gle", "paypa1", "amaz0n"
     * Ignores digits at the end of a label (e.g. "server1.host.com" is normal).
     */
    function hasLookalikeDigit(host) {
        // Strip TLD so trailing digits before the dot aren't flagged
        const withoutTld = host.split(".").slice(0, -1).join(".");
        const chars = withoutTld.split("");
        for (let i = 0; i < chars.length; i++) {
            if (!LOOKALIKE_DIGITS.has(chars[i])) continue;
            const prevLetter = i > 0               && /[a-z]/i.test(chars[i - 1]);
            const nextLetter = i < chars.length - 1 && /[a-z]/i.test(chars[i + 1]);
            if (prevLetter || nextLetter) return true;
        }
        return false;
    }

    /**
     * Returns true when the host contains the brand keyword but is NOT
     * the canonical domain or a legitimate subdomain of it.
     */
    function isBrandImpersonation(host, brand) {
        if (!host.includes(brand.keyword)) return false;
        const canon = brand.canonical;
        return host !== canon && !host.endsWith("." + canon);
    }

    // ── Main function ──────────────────────────────────────────────────────────

    /**
     * Analyse a URL string for suspicious structural patterns.
     *
     * @param {string} inputUrl
     * @returns {{ score: number, signals: string[] }}
     *   score   — 0 (nothing suspicious) to 100 (maximally sketchy)
     *   signals — human-readable descriptions of triggered checks
     */
    function check(inputUrl) {
        let score     = 0;
        const signals = [];

        let url;
        try {
            url = new URL(inputUrl);
        } catch {
            // Unparseable URL — no score
            return { score: 0, signals: [] };
        }

        const host = url.hostname.toLowerCase();

        // ── 1. IP address ────────────────────────────────────────────────────
        if (/^\d+\.\d+\.\d+\.\d+$/.test(host)) {
            score += 25;
            signals.push("IP address used instead of domain name (+25)");
        }

        // ── 2. Punycode ──────────────────────────────────────────────────────
        if (host.includes("xn--")) {
            score += 30;
            signals.push("Punycode detected — possible lookalike domain (+30)");
        }

        // ── 3. Excessive subdomains ──────────────────────────────────────────
        const parts = host.split(".");
        if (parts.length > 3) {
            score += 10;
            signals.push(`Excessive subdomains: ${parts.length - 1} levels (+10)`);
        }

        // ── 4. Brand impersonation ───────────────────────────────────────────
        for (const brand of BRANDS) {
            if (isBrandImpersonation(host, brand)) {
                score += 15;
                signals.push(`Brand impersonation: "${brand.keyword}" in hostname (+15)`);
            }
        }

        // Clamp before lookalike so headroom calculation is accurate
        score = Math.min(score, 100);

        // ── 5. Digit-as-letter lookalike ─────────────────────────────────────
        // Fills all remaining headroom → always reaches 100 when detected.
        // A URL with only this signal scores 100; combined with others it still
        // reaches 100 but through the headroom mechanism.
        if (hasLookalikeDigit(host)) {
            const headroom = 100 - score;
            score += headroom;
            signals.push("Digit-as-letter substitution detected (e.g. 0→o, 1→i/l, 3→e) (+headroom to 100)");
        }

        return { score: Math.max(0, Math.min(100, score)), signals };
    }

    return { check };

})();
