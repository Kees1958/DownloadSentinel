"use strict";

window.SentinelPopup = window.SentinelPopup || (function () {

    const browserAPI = typeof browser === 'undefined' ? chrome : browser;

    // ── Helpers ────────────────────────────────────────────────────────────────

    /**
     * Determine banner / button state:
     *  'off'    → extension disabled
     *  'no-key' → extension on, no VT API key
     *  'ready'  → extension on, VT API key present
     */
    function getState(settings) {
        if (!settings.extensionEnabled) return 'off';
        if (!settings.isVtApiKeySet || !settings.vtApiKey) return 'no-key';
        return 'ready';
    }

    // ── UI update ──────────────────────────────────────────────────────────────

    function applyUI(settings) {
        const state      = getState(settings);
        const banner     = document.getElementById('banner');
        const logo       = document.getElementById('logo');
        const sw         = document.getElementById('extSwitch');
        const statusLbl  = document.getElementById('extStatus');
        const optionsBtn = document.getElementById('optionsBtn');

        // Banner color
        banner.className = 'banner state-' + state;

        // Icon: use _OFF variant when extension is disabled
        const iconFile = settings.extensionEnabled
            ? '../../assets/icons/icon128.png'
            : '../../assets/icons/icon128_OFF.png';
        logo.src = iconFile;

        // Switch
        sw.className = 'switch ' + (settings.extensionEnabled ? 'on' : 'off');

        // Status label
        if (state === 'off') {
            statusLbl.textContent = 'inactive';
            statusLbl.className   = 'status-label inactive';
        } else {
            statusLbl.textContent = 'active';
            statusLbl.className   = 'status-label';
        }

        // OPTIONS button color
        optionsBtn.className = 'options-btn ' + (state === 'ready' ? 'ready' : 'no-key');
    }

    // ── Switch toggle ──────────────────────────────────────────────────────────

    function bindSwitch() {
        const sw = document.getElementById('extSwitch');
        sw.addEventListener('click', () => {
            Settings.get((settings) => {
                const newEnabled = !settings.extensionEnabled;
                Settings.set({ extensionEnabled: newEnabled }, () => {
                    // Notify background so it can update icons
                    browserAPI.runtime.sendMessage({
                        type: 'EXTENSION_TOGGLE',
                        enabled: newEnabled
                    }).catch(() => {});
                    applyUI({ ...settings, extensionEnabled: newEnabled });
                });
            });
        });
    }

    // ── OPTIONS button ─────────────────────────────────────────────────────────

    function bindOptionsButton() {
        document.getElementById('optionsBtn').addEventListener('click', () => {
            browserAPI.tabs.create({
                url: browserAPI.runtime.getURL('pages/options/OptionsPage.html')
            });
            window.close();
        });
    }

    // ── Version label ──────────────────────────────────────────────────────────

    function showVersion() {
        const el = document.getElementById('versionLabel');
        if (!el) return;
        try {
            const manifest = browserAPI.runtime.getManifest();
            el.textContent = 'v' + manifest.version;
        } catch (_) {
            el.textContent = '';
        }
    }

    // ── Init ───────────────────────────────────────────────────────────────────

    function initialize() {
        showVersion();
        bindSwitch();
        bindOptionsButton();

        Settings.get((settings) => {
            applyUI(settings);
        });
    }

    return { initialize };
})();

document.addEventListener('DOMContentLoaded', () => {
    window.SentinelPopup.initialize();
});
