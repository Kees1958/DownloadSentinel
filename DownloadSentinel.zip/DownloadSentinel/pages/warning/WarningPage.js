// ── Setup ──────────────────────────────────────────────────────────────────────

const params     = new URLSearchParams(location.search);
const downloadId = Number(params.get("downloadId"));

if (!downloadId) {
    document.body.innerHTML = "<p style='color:white;padding:2rem'>Invalid warning page — no download ID found.</p>";
    throw new Error("[DownloadSentinel] WarningPage opened without a valid downloadId");
}

// ── DOM refs ───────────────────────────────────────────────────────────────────

const reasonText       = document.getElementById("reasonText");
const srcUrl           = document.getElementById("srcUrl");

// VT
const bpResult         = document.getElementById("bpResult");
const vtBreakdownBox   = document.getElementById("vtBreakdownBox");
const vtBreakdownList  = document.getElementById("vtBreakdownList");
const btnSubmitVt      = null; // removed

// Host reputation
const hostBox          = document.getElementById("hostBox");
const hostResult       = document.getElementById("hostResult");
const hostBreakdownBox = document.getElementById("hostBreakdownBox");
const hostBreakdownList= document.getElementById("hostBreakdownList");

// Overall worst score
const worstScoreBox    = document.getElementById("worstScoreBox");
const worstScoreValue  = document.getElementById("worstScoreValue");
const worstScoreBarFill= document.getElementById("worstScoreBarFill");

const btnBack          = document.getElementById("btn-back");
const btnAllow         = document.getElementById("btn-allow");
const disclaimer       = document.getElementById("disclaimerText");

let vtDone   = false;
let hostDone = false;

// Current known scores (null = not yet available)
let currentVtScore   = null;
let currentHostScore = null;

// Last received host data — used to populate vtUnknownPanel when VT result arrives after host data
let lastHostData = null;

// ── Settings ───────────────────────────────────────────────────────────────────

function applySettings(settings) {
    const r = settings.warningColorR ?? 179;
    const g = settings.warningColorG ?? 38;
    const b = settings.warningColorB ?? 30;
    document.body.style.backgroundColor = `rgb(${r}, ${g}, ${b})`;

    if (settings.isVtApiKeySet && settings.vtApiKey) {
        disclaimer.innerHTML =
            '<span style="color:#fff;">Disclaimer: this is what VirusTotal currently knows — file can still be malicious!</span>';
    } else {
        disclaimer.innerHTML =
            '<span style="color:#fff;">Reputation check not activated, please </span>' +
            '<a href="https://www.virustotal.com/gui/join-us" target="_blank" ' +
            'style="color:rgb(243,186,34);font-weight:600;text-decoration:none;">' +
            'Get a free API key</a>';
    }
}

function applyVtUnknownDisclaimer() {
    disclaimer.innerHTML =
        '<span style="color:#fff;">URL unknown at VirusTotal — </span>' +
        '<a href="https://www.virustotal.com/gui/home/file" target="_blank" ' +
        'style="color:rgb(243,186,34);font-weight:600;text-decoration:none;">' +
        'Upload file to VirusTotal for analysis</a>';
}

Settings.get(applySettings);

// ── Score bar helpers ──────────────────────────────────────────────────────────

function renderScoreBar(boxEl, fillEl, valueEl, score) {
    if (score === null || score === undefined) {
        boxEl.style.display = "none";
        return;
    }
    boxEl.style.display  = "";
    const isPositive     = score >= 0;
    const magnitude      = Math.min(100, Math.abs(score));

    valueEl.textContent  = `${isPositive ? "+" : ""}${score}%`;
    valueEl.className    = "score-bar-value " + (isPositive ? "positive" : "negative");
    fillEl.className     = "score-bar-fill "  + (isPositive ? "positive" : "negative");
    fillEl.style.width   = `${magnitude}%`;
}

function updateWorstScore() {
    const scores = [currentVtScore, currentHostScore].filter(s => s !== null);
    if (scores.length === 0) {
        worstScoreBox.style.display = "none";
        return;
    }
    const worst = Math.min(...scores);
    renderScoreBar(worstScoreBox, worstScoreBarFill, worstScoreValue, worst);
}

// ── VT rendering ──────────────────────────────────────────────────────────────

function applyVtStyling(result) {
    bpResult.classList.remove("vt-malicious", "vt-suspicious", "vt-questionable", "vt-safe", "vt-unknown");
    if (!result || result.startsWith("Checking") || result.startsWith("Blocked")) {
        bpResult.classList.add("vt-unknown");
    } else if (result.startsWith("Probably Safe")) {
        bpResult.classList.add("vt-safe");
    } else if (result.startsWith("Probably Inconclusive")) {
        bpResult.classList.add("vt-questionable");
    } else if (result.startsWith("Probably Suspicious")) {
        bpResult.classList.add("vt-suspicious");
    } else if (result.startsWith("Probably Malicious")) {
        bpResult.classList.add("vt-malicious");
    } else {
        bpResult.classList.add("vt-unknown");
    }
}

function renderVtScore(data) {
    if (typeof data.vtScore !== "number") {
        if (data.vtStatus === "done") {
            currentVtScore = null;
            applyVtUnknownDisclaimer();
            // If host data already arrived, ensure host reputation is visible
            if (lastHostData) renderHostReputation(lastHostData);
        }
        return;
    }

    currentVtScore = data.vtScore;
    updateWorstScore();
}

function renderVtBreakdown(data) {
    if (!data.vtBreakdown) {
        vtBreakdownBox.style.display = "none";
        return;
    }
    vtBreakdownBox.style.display = "";
    vtBreakdownList.innerHTML    = "";

    const { detection, age } = data.vtBreakdown;

    if (detection) {
        const li = document.createElement("li");
        li.textContent = `Detections: ${detection.label}`;
        vtBreakdownList.appendChild(li);
    }
    if (age) {
        const li = document.createElement("li");
        li.textContent = `First seen: ${age.label}`;
        vtBreakdownList.appendChild(li);
    }
    if (data.vtConfidence) {
        const li = document.createElement("li");
        li.textContent = `Confidence: ${data.vtConfidence}`;
        vtBreakdownList.appendChild(li);
    }
}

function applyVtResult(data) {
    srcUrl.textContent     = (data.url || "Unknown URL").split("?")[0].split("#")[0];
    reasonText.textContent = data.ext ? "." + data.ext : "Unknown";
    bpResult.textContent   = data.browserProtectionResult || "Checking...";
    applyVtStyling(data.browserProtectionResult);
    renderVtScore(data);
    renderVtBreakdown(data);

    if (data.vtStatus === "done") vtDone = true;
}

// ── Host reputation rendering ─────────────────────────────────────────────────

function classifyToStyle(classification) {
    if (!classification) return "vt-unknown";
    if (classification.startsWith("Probably Safe"))        return "vt-safe";
    if (classification.startsWith("Probably Inconclusive")) return "vt-questionable";
    if (classification.startsWith("Probably Suspicious"))  return "vt-suspicious";
    if (classification.startsWith("Probably Malicious"))   return "vt-malicious";
    return "vt-unknown";
}

function renderHostReputation(hostData) {
    if (!hostData) return;

    lastHostData = hostData;

    // When VT has no score, always show host reputation — it is the primary signal.
    // When VT has a score, hide host box only if there is truly no data at all.
    const vtUnknown = vtDone && currentVtScore === null;

    if (hostData.score === null && !vtUnknown) {
        hostBox.style.display          = "none";
        hostBreakdownBox.style.display = "none";
        return;
    }

    hostBox.style.display = "";

    // Primary result line — always use normal scoring label
    hostResult.textContent = hostData.label || hostData.classification || "Checked";
    hostResult.className   = "value " + classifyToStyle(hostData.classification);

    // Score bar — only update when there is a numeric score
    if (typeof hostData.score === "number") {
        currentHostScore = hostData.score;
        updateWorstScore();
    }

    // Breakdown list — Quad9 always first, then scoring rows, then RDAP age
    hostBreakdownBox.style.display = "";
    hostBreakdownList.innerHTML    = "";

    // 1. Quad9 — always shown
    if (hostData.quad9?.status) {
        const li = document.createElement("li");
        if (hostData.quad9.status === "BLOCKED") {
            li.textContent = "Quad9: Domain is on Quad9 blacklist (confirmed malicious)";
        } else if (hostData.quad9.status === "ALLOWED") {
            li.textContent = "Quad9: Not on Quad9 blacklist";
        } else {
            li.textContent = `Quad9: ${hostData.quad9.reason || "Not in Quad9 threat database"}`;
        }
        hostBreakdownList.appendChild(li);
    }

    // 2. Scoring rows (domain list, TLD list, sketchy URL etc.)
    const rows = hostData.breakdown || [];
    for (const row of rows) {
        if (row.source === "Quad9") continue; // already shown above
        const li = document.createElement("li");
        li.textContent = `${row.source}: ${row.label} (score ${row.score})`;
        hostBreakdownList.appendChild(li);
    }

    // 3. RDAP domain age
    if (hostData.rdap?.ageDays !== undefined && hostData.rdap.ageDays !== null) {
        const li = document.createElement("li");
        li.textContent = `Domain age: ${hostData.rdap.ageDays} days`;
        hostBreakdownList.appendChild(li);
    }

    // 4. MIME consistency — always shown
    if (hostData.mimeResult) {
        const li = document.createElement("li");
        li.textContent = `MimeCheck: ${hostData.mimeResult.label}`;
        hostBreakdownList.appendChild(li);
    }

    // 5. File size warning — only shown when it exceeds VT maximum
    if (hostData.sizeResult?.exceeds) {
        const li = document.createElement("li");
        li.textContent = `SizeCheck: ${hostData.sizeResult.label}`;
        hostBreakdownList.appendChild(li);
    }

    // Hide breakdown box if it ended up empty
    if (hostBreakdownList.children.length === 0) {
        hostBreakdownBox.style.display = "none";
    }
}

// ── Initial data fetch + VT poll ─────────────────────────────────────────────

chrome.runtime.sendMessage(
    { type: "GET_BLOCKED_DOWNLOAD", downloadId },
    data => {
        if (!data) return;
        applyVtResult(data);

        // Render host data if already done by the time the page loads
        if (data.hostResult) {
            renderHostReputation(data.hostResult);
            hostDone = true;
        }
        // If not yet done, leave host box hidden; it appears only when signals exist

        if (!vtDone || !hostDone) {
            const pollStart    = Date.now();
            const POLL_TIMEOUT = 15000;

            const pollInterval = setInterval(() => {
                if (Date.now() - pollStart >= POLL_TIMEOUT) {
                    clearInterval(pollInterval);

                    if (!vtDone) {
                        vtDone = true;
                        bpResult.textContent = "Unknown reputation — " +
                            (data.ext ? "." + data.ext + " download" : "download");
                        applyVtStyling(bpResult.textContent);
                        // vtUnknownPanel will render once host data arrives
                    }

                    if (!hostDone) {
                        hostDone = true;
                        hostResult.textContent = "Host reputation check timed out";
                        hostResult.className   = "value vt-unknown";
                    }
                    return;
                }

                chrome.runtime.sendMessage(
                    { type: "GET_BLOCKED_DOWNLOAD", downloadId },
                    polled => {
                        if (!polled) { clearInterval(pollInterval); return; }

                        if (!vtDone) {
                            applyVtResult(polled);
                        }
                        if (!hostDone && polled.hostResult) {
                            renderHostReputation(polled.hostResult);
                            hostDone = true;
                        }
                        if (vtDone && hostDone) clearInterval(pollInterval);
                    }
                );
            }, 250);
        }
    }
);

// ── Push updates from background ─────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg) => {
    if (msg.downloadId !== downloadId) return;

    if (msg.type === "VT_RESULT_UPDATE") {
        vtDone = true;
        applyVtResult({
            vtStatus:               "done",
            url:                    srcUrl.textContent,
            ext:                    reasonText.textContent.replace(/^\./, ""),
            browserProtectionResult: msg.browserProtectionResult,
            vtScore:                msg.vtScore,
            vtConfidence:           msg.vtConfidence,
            vtBreakdown:            msg.vtBreakdown,
            vtHardRule:             msg.vtHardRule
        });
    }

    if (msg.type === "HOST_RESULT_UPDATE") {
        hostDone = true;
        renderHostReputation(msg.hostResult);
    }
});

// ── Cancel / Allow ────────────────────────────────────────────────────────────

btnBack.addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "CANCEL_DOWNLOAD", downloadId }, () => window.close());
});

btnAllow.addEventListener("click", () => {
    btnAllow.disabled    = true;
    btnAllow.textContent = "Starting download...";

    chrome.runtime.sendMessage({ type: "ALLOW_DOWNLOAD", downloadId }, response => {
        if (response && response.success) {
            window.close();
        } else {
            btnAllow.disabled    = false;
            btnAllow.textContent = "Ignore & Proceed";
            console.error("[DS] Failed to allow download:", response?.error);
        }
    });
});
