// ── Setup ──────────────────────────────────────────────────────────────────────

const params     = new URLSearchParams(location.search);
const downloadId = Number(params.get("downloadId"));

const reasonText  = document.getElementById("reasonText");
const srcUrl      = document.getElementById("srcUrl");
const bpResult    = document.getElementById("bpResult");
const btnBack     = document.getElementById("btn-back");
const btnAllow    = document.getElementById("btn-allow");
const disclaimer  = document.getElementById("disclaimerText");

let vtDone = false;

// ── Apply settings (background color + disclaimer text) ───────────────────────

function applySettings(settings) {
    // Custom background color
    const r = settings.warningColorR ?? 179;
    const g = settings.warningColorG ?? 38;
    const b = settings.warningColorB ?? 30;
    document.body.style.backgroundColor = `rgb(${r}, ${g}, ${b})`;

    // Disclaimer text
    if (settings.isVtApiKeySet && settings.vtApiKey) {
        disclaimer.innerHTML =
            '<span style="color:#fff;">Disclaimer: this is what Virus Total currently knows, file can still be malicious!</span>';
    } else {
        disclaimer.innerHTML =
            '<span style="color:#fff;">Reputatie check inactief</span> ' +
            '<a href="https://www.virustotal.com/gui/join-us" target="_blank" ' +
            'style="color:rgb(243,186,34);font-weight:600;text-decoration:none;">' +
            'Get a free API key</a>';
    }
}

// Load settings as soon as the page is ready
Settings.get(applySettings);

// ── Download data ──────────────────────────────────────────────────────────────

function applyResult(data) {
    srcUrl.textContent     = data.url || "Unknown URL";
    reasonText.textContent = data.ext ? "." + data.ext : "Unknown";
    bpResult.textContent   = data.browserProtectionResult || "Checking...";
    applyVtStyling(data.browserProtectionResult);

    if (data.vtStatus === "done") vtDone = true;
}

// Initial fetch from background
chrome.runtime.sendMessage(
    { type: "GET_BLOCKED_DOWNLOAD", downloadId },
    data => {
        if (!data) return;
        applyResult(data);

        if (data.vtStatus !== "done") {
            const pollInterval = setInterval(() => {
                chrome.runtime.sendMessage(
                    { type: "GET_BLOCKED_DOWNLOAD", downloadId },
                    polled => {
                        if (!polled) { clearInterval(pollInterval); return; }
                        applyResult(polled);
                        if (polled.vtStatus === "done") clearInterval(pollInterval);
                    }
                );
            }, 1000);
        }
    }
);

// Push update from background (whichever arrives first wins)
chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === "VT_RESULT_UPDATE" && msg.downloadId === downloadId) {
        if (vtDone) return;
        vtDone = true;
        bpResult.textContent = msg.browserProtectionResult;
        applyVtStyling(msg.browserProtectionResult);
    }
});

// ── VT styling ─────────────────────────────────────────────────────────────────

function applyVtStyling(result) {
    bpResult.classList.remove("vt-malicious", "vt-safe", "vt-unknown");

    if (!result || result.startsWith("Checking")) {
        bpResult.classList.add("vt-unknown");
    } else if (result.startsWith("Clean")) {
        bpResult.classList.add("vt-safe");
    } else if (
        result.startsWith("Unknown") ||
        result.startsWith("Reputation check failed")
    ) {
        bpResult.classList.add("vt-unknown");
    } else {
        bpResult.classList.add("vt-malicious");
    }
}

// ── Buttons ────────────────────────────────────────────────────────────────────

btnBack.addEventListener("click", () => window.close());

btnAllow.addEventListener("click", () => {
    btnAllow.disabled     = true;
    btnAllow.textContent  = "Starting download...";

    chrome.runtime.sendMessage({ type: "ALLOW_DOWNLOAD", downloadId }, response => {
        if (response && response.success) {
            window.close();
        } else {
            btnAllow.disabled    = false;
            btnAllow.textContent = "Ignore & Proceed";
            console.error("[DownloadProtection] Failed to allow download:", response?.error);
        }
    });
});
