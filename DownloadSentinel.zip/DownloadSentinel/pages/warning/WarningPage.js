// ── Setup ──────────────────────────────────────────────────────────────────────

const params     = new URLSearchParams(location.search);
const downloadId = Number(params.get("downloadId"));

if (!downloadId) {
    document.body.innerHTML = "<p style='color:white;padding:2rem'>Invalid warning page — no download ID found.</p>";
    throw new Error("[DownloadSentinel] WarningPage opened without a valid downloadId");
}

// ── DOM refs ───────────────────────────────────────────────────────────────────

const reasonText       = document.getElementById("reasonText");
const srcUrl           = document.getElementById("srcUrl");

// VT
const bpResult         = document.getElementById("bpResult");
const vtBreakdownBox   = document.getElementById("vtBreakdownBox");
const vtBreakdownList  = document.getElementById("vtBreakdownList");
const btnSubmitVt      = null; // removed — replaced by vtUnknownBox

// VT Unknown secondary check panel
const vtUnknownBox     = document.getElementById("vtUnknownBox");
const vtUnknownList    = document.getElementById("vtUnknownList");

// Host reputation
const hostBox          = document.getElementById("hostBox");
const hostResult       = document.getElementById("hostResult");
const hostBreakdownBox = document.getElementById("hostBreakdownBox");
const hostBreakdownList= document.getElementById("hostBreakdownList");

// Overall worst score
const worstScoreBox    = document.getElementById("worstScoreBox");
const worstScoreValue  = document.getElementById("worstScoreValue");
const worstScoreBarFill= document.getElementById("worstScoreBarFill");

const btnBack          = document.getElementById("btn-back");
const btnAllow         = document.getElementById("btn-allow");
const disclaimer       = document.getElementById("disclaimerText");

let vtDone   = false;
let hostDone = false;

// Current known scores (null = not yet available)
let currentVtScore   = null;
let currentHostScore = null;

// Last received host data — used to populate vtUnknownPanel when VT result arrives after host data
let lastHostData = null;

// ── Settings ───────────────────────────────────────────────────────────────────

function applySettings(settings) {
    const r = settings.warningColorR ?? 179;
    const g = settings.warningColorG ?? 38;
    const b = settings.warningColorB ?? 30;
    document.body.style.backgroundColor = `rgb(${r}, ${g}, ${b})`;

    if (settings.isVtApiKeySet && settings.vtApiKey) {
        disclaimer.innerHTML =
            '<span style="color:#fff;">Disclaimer: this is what VirusTotal currently knows — file can still be malicious!</span>';
    } else {
        disclaimer.innerHTML =
            '<span style="color:#fff;">Reputation check not activated, please </span>' +
            '<a href="https://www.virustotal.com/gui/join-us" target="_blank" ' +
            'style="color:rgb(243,186,34);font-weight:600;text-decoration:none;">' +
            'Get a free API key</a>';
    }
}

function applyVtUnknownDisclaimer() {
    disclaimer.innerHTML =
        '<span style="color:#fff;">Download URL unknown at VirusTotal, please </span>' +
        '<a href="https://www.virustotal.com/gui/home/url" target="_blank" ' +
        'style="color:rgb(243,186,34);font-weight:600;text-decoration:none;">' +
        'Check download URL manually at VT</a>';
}

Settings.get(applySettings);

// ── Score bar helpers ──────────────────────────────────────────────────────────

function renderScoreBar(boxEl, fillEl, valueEl, score) {
    if (score === null || score === undefined) {
        boxEl.style.display = "none";
        return;
    }
    boxEl.style.display  = "";
    const isPositive     = score >= 0;
    const magnitude      = Math.min(100, Math.abs(score));

    valueEl.textContent  = `${isPositive ? "+" : ""}${score}%`;
    valueEl.className    = "score-bar-value " + (isPositive ? "positive" : "negative");
    fillEl.className     = "score-bar-fill "  + (isPositive ? "positive" : "negative");
    fillEl.style.width   = `${magnitude}%`;
}

function updateWorstScore() {
    const scores = [currentVtScore, currentHostScore].filter(s => s !== null);
    if (scores.length === 0) {
        worstScoreBox.style.display = "none";
        return;
    }
    const worst = Math.min(...scores);
    renderScoreBar(worstScoreBox, worstScoreBarFill, worstScoreValue, worst);
}

// ── VT rendering ──────────────────────────────────────────────────────────────

function applyVtStyling(result) {
    bpResult.classList.remove("vt-malicious", "vt-suspicious", "vt-questionable", "vt-safe", "vt-unknown");
    if (!result || result.startsWith("Checking") || result.startsWith("Blocked")) {
        bpResult.classList.add("vt-unknown");
    } else if (result.startsWith("Probably Safe")) {
        bpResult.classList.add("vt-safe");
    } else if (result.startsWith("Probably Inconclusive")) {
        bpResult.classList.add("vt-questionable");
    } else if (result.startsWith("Probably Suspicious")) {
        bpResult.classList.add("vt-suspicious");
    } else if (result.startsWith("Probably Malicious")) {
        bpResult.classList.add("vt-malicious");
    } else {
        bpResult.classList.add("vt-unknown");
    }
}

function renderVtScore(data) {
    // VT submit button removed — URL-unknown case is handled by renderVtUnknownPanel()

    if (typeof data.vtScore !== "number") {
        if (data.vtStatus === "done") {
            currentVtScore = null;
            applyVtUnknownDisclaimer();
            // If host data already arrived, populate the secondary check panel now
            if (lastHostData) renderVtUnknownPanel(lastHostData);
        }
        return;
    }

    // VT did know the URL — hide the secondary-check panel
    vtUnknownBox.style.display = "none";
    currentVtScore = data.vtScore;
    updateWorstScore();
}

/**
 * Populate the "Secondary Security Check" panel shown when VT does not know
 * the download URL.  Shows three items:
 *   1. Quad9 DNS result (not blacklisted / malicious)
 *   2. Domain age in days from RDAP
 *   3. Domain-list or TLD-list score with explanatory text
 *
 * @param {object} hostData  - the hostResult object from BrowserProtection
 */
function renderVtUnknownPanel(hostData) {
    if (!hostData) return;

    vtUnknownBox.style.display = "";
    vtUnknownList.innerHTML    = "";

    // ── 1. Quad9 result ──────────────────────────────────────────────────────
    // Only shown when Quad9 gave a definitive answer (BLOCKED or ALLOWED).
    // UNKNOWN (e.g. 400 from Quad9, TLD not in threat database) is suppressed
    // to avoid confusing noise in the secondary check panel.
    const quad9 = hostData.quad9;
    if (quad9 && quad9.status !== "UNKNOWN") {
        const li = document.createElement("li");
        if (quad9.status === "BLOCKED") {
            li.textContent = "Download domain is blacklisted by Quad9 (confirmed malicious)";
        } else {
            li.textContent = "Download domain is not blacklisted by Quad9";
        }
        vtUnknownList.appendChild(li);
    }

    // ── 2. RDAP domain age ───────────────────────────────────────────────────
    const rdap = hostData.rdap;
    if (rdap && rdap.ageDays !== undefined && rdap.ageDays !== null) {
        const li = document.createElement("li");
        li.textContent = `Domain age: ${rdap.ageDays} day${rdap.ageDays === 1 ? "" : "s"}`;
        vtUnknownList.appendChild(li);
    } else if (rdap) {
        const li = document.createElement("li");
        li.textContent = `Domain age: ${rdap.label || "unknown"}`;
        vtUnknownList.appendChild(li);
    }

    // ── 3. Domain-list or TLD-list score ────────────────────────────────────
    const domainHit = hostData.domainHit;
    const tldHit    = hostData.tldHit;

    if (domainHit) {
        const li = document.createElement("li");
        li.textContent = `Download domain risk score: ${domainHit.score}/100 — often abused download domain`;
        vtUnknownList.appendChild(li);
    } else if (tldHit) {
        const li = document.createElement("li");
        li.textContent = `Top Level Domain risk score: ${tldHit.score}/100 — often abused Top Level Domain`;
        vtUnknownList.appendChild(li);
    }
}

function renderVtBreakdown(data) {
    if (!data.vtBreakdown) {
        vtBreakdownBox.style.display = "none";
        return;
    }
    vtBreakdownBox.style.display = "";
    vtBreakdownList.innerHTML    = "";

    const { detection, age } = data.vtBreakdown;

    if (detection) {
        const li = document.createElement("li");
        li.textContent = `Detections: ${detection.label}`;
        vtBreakdownList.appendChild(li);
    }
    if (age) {
        const li = document.createElement("li");
        li.textContent = `First seen: ${age.label}`;
        vtBreakdownList.appendChild(li);
    }
    if (data.vtConfidence) {
        const li = document.createElement("li");
        li.textContent = `Confidence: ${data.vtConfidence}`;
        vtBreakdownList.appendChild(li);
    }
}

function applyVtResult(data) {
    srcUrl.textContent     = (data.url || "Unknown URL").split("?")[0].split("#")[0];
    reasonText.textContent = data.ext ? "." + data.ext : "Unknown";
    bpResult.textContent   = data.browserProtectionResult || "Checking...";
    applyVtStyling(data.browserProtectionResult);
    renderVtScore(data);
    renderVtBreakdown(data);

    if (data.vtStatus === "done") vtDone = true;
}

// ── Host reputation rendering ─────────────────────────────────────────────────

function classifyToStyle(classification) {
    if (!classification) return "vt-unknown";
    if (classification.startsWith("Probably Safe"))        return "vt-safe";
    if (classification.startsWith("Probably Inconclusive")) return "vt-questionable";
    if (classification.startsWith("Probably Suspicious"))  return "vt-suspicious";
    if (classification.startsWith("Probably Malicious"))   return "vt-malicious";
    return "vt-unknown";
}

function renderHostReputation(hostData) {
    if (!hostData) return;

    lastHostData = hostData;

    // Always try to populate the VT-unknown panel — it checks internally whether VT knew the URL
    // (currentVtScore === null after vtDone means VT didn't know it)
    if (vtDone && currentVtScore === null) {
        renderVtUnknownPanel(hostData);
    }

    // No signals — hide host boxes entirely; VT score is used alone
    if (hostData.score === null || !hostData.breakdown || hostData.breakdown.length === 0) {
        hostBox.style.display        = "none";
        hostBreakdownBox.style.display = "none";
        return;
    }

    hostBox.style.display = "";

    // Primary result line
    hostResult.textContent = hostData.label || hostData.classification || "Checked";
    hostResult.className   = "value " + classifyToStyle(hostData.classification);

    // Score bar
    currentHostScore = (typeof hostData.score === "number") ? hostData.score : null;
    updateWorstScore();

    // Breakdown list
    const rows = hostData.breakdown;

    hostBreakdownBox.style.display = "";
    hostBreakdownList.innerHTML    = "";

    for (const row of rows) {
        // Skip Quad9 rows here — shown once explicitly below, without the score suffix
        if (row.source === "Quad9") continue;
        const li = document.createElement("li");
        li.textContent = `${row.source}: ${row.label} (score ${row.score})`;
        hostBreakdownList.appendChild(li);
    }

    // Quad9 result — only shown when definitive (BLOCKED or ALLOWED); suppress UNKNOWN
    if (hostData.quad9?.status && hostData.quad9.status !== "UNKNOWN") {
        const li = document.createElement("li");
        li.textContent = `Quad9: ${hostData.quad9.label || hostData.quad9.status}`;
        hostBreakdownList.appendChild(li);
    }
    if (hostData.rdap?.ageDays !== undefined && hostData.rdap.ageDays !== null) {
        const li = document.createElement("li");
        li.textContent = `Domain registered: ${hostData.rdap.registered ?? "unknown"} (${hostData.rdap.ageDays} days ago)`;
        hostBreakdownList.appendChild(li);
    }
}

// ── Initial data fetch + VT poll ─────────────────────────────────────────────

chrome.runtime.sendMessage(
    { type: "GET_BLOCKED_DOWNLOAD", downloadId },
    data => {
        if (!data) return;
        applyVtResult(data);

        // Render host data if already done by the time the page loads
        if (data.hostResult) {
            renderHostReputation(data.hostResult);
            hostDone = true;
        }
        // If not yet done, leave host box hidden; it appears only when signals exist

        if (!vtDone || !hostDone) {
            const pollStart    = Date.now();
            const POLL_TIMEOUT = 15000;

            const pollInterval = setInterval(() => {
                if (Date.now() - pollStart >= POLL_TIMEOUT) {
                    clearInterval(pollInterval);

                    if (!vtDone) {
                        vtDone = true;
                        bpResult.textContent = "Unknown reputation — " +
                            (data.ext ? "." + data.ext + " download" : "download");
                        applyVtStyling(bpResult.textContent);
                        // vtUnknownPanel will render once host data arrives
                    }

                    if (!hostDone) {
                        hostDone = true;
                        hostResult.textContent = "Host reputation check timed out";
                        hostResult.className   = "value vt-unknown";
                    }
                    return;
                }

                chrome.runtime.sendMessage(
                    { type: "GET_BLOCKED_DOWNLOAD", downloadId },
                    polled => {
                        if (!polled) { clearInterval(pollInterval); return; }

                        if (!vtDone) {
                            applyVtResult(polled);
                        }
                        if (!hostDone && polled.hostResult) {
                            renderHostReputation(polled.hostResult);
                            hostDone = true;
                        }
                        if (vtDone && hostDone) clearInterval(pollInterval);
                    }
                );
            }, 250);
        }
    }
);

// ── Push updates from background ─────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg) => {
    if (msg.downloadId !== downloadId) return;

    if (msg.type === "VT_RESULT_UPDATE") {
        vtDone = true;
        applyVtResult({
            vtStatus:               "done",
            url:                    srcUrl.textContent,
            ext:                    reasonText.textContent.replace(/^\./, ""),
            browserProtectionResult: msg.browserProtectionResult,
            vtScore:                msg.vtScore,
            vtConfidence:           msg.vtConfidence,
            vtBreakdown:            msg.vtBreakdown,
            vtHardRule:             msg.vtHardRule
        });
    }

    if (msg.type === "HOST_RESULT_UPDATE") {
        hostDone = true;
        renderHostReputation(msg.hostResult);
    }
});

// ── Cancel / Allow ────────────────────────────────────────────────────────────

btnBack.addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "CANCEL_DOWNLOAD", downloadId }, () => window.close());
});

btnAllow.addEventListener("click", () => {
    btnAllow.disabled    = true;
    btnAllow.textContent = "Starting download...";

    chrome.runtime.sendMessage({ type: "ALLOW_DOWNLOAD", downloadId }, response => {
        if (response && response.success) {
            window.close();
        } else {
            btnAllow.disabled    = false;
            btnAllow.textContent = "Ignore & Proceed";
            console.error("[DS] Failed to allow download:", response?.error);
        }
    });
});
