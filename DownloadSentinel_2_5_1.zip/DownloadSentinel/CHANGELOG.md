# Download Sentinel — Changelog

## V2.5.1
### Fixed: unchecking "Personalize" on the options page didn't reset the warning color/title
`bindSaveAll()` in `OptionsPage.js` always read the color and title `<input>` values
straight from the DOM, regardless of whether the "Personalize" checkbox was checked.
Unchecking it only hid the section (`display:none`) — the inputs still held whatever
was last typed in, so clicking "Save All" silently re-saved the old customized values
instead of resetting to the defaults. Fixed by:
- `bindSaveAll()` now checks the Personalize checkbox state directly and forces the
  default color/title (via the new `APP.WARNING_COLOR_DEFAULT_R/G/B` constants) when
  it is unchecked, instead of trusting the hidden fields.
- `bindPersonalize()` also now visually clears the color/title fields back to default
  the moment the checkbox is unchecked, so the UI never shows stale values.
- Default warning color (previously hardcoded as `179/38/30` in both `Settings.js`
  and `OptionsPage.js`) is now centralized in `AppConstants.js` as
  `WARNING_COLOR_DEFAULT_R/G/B`, matching the existing pattern for `WARNING_TITLE_DEFAULT`.

## V2.5.0
Migrated the whole codebase to real ES modules (`import`/`export`) — the manifest's
service worker now loads with `"type": "module"`, and every page HTML loads its
controller as `<script type="module">`. Each file now imports exactly the modules it
uses directly, instead of relying on `importScripts`/`<script>` load order and an
implicit shared global scope. ESLint (`.eslintrc.json`, `eslint:recommended`,
`sourceType: "module"`) resolves all of this natively — no manually-maintained globals
list needed. This also surfaced real issues the classic-script setup had been masking:

### Fixed: `originalUrl` was silently ignored in the VirusTotal check
`BrowserProtection.checkIfUrlIsMalicious(key, url, callback, originalUrl)` accepted
`originalUrl` as a parameter — both call sites in `background.js` pass it — but never
read it. `checkHostReputation()` already runs its heuristics on both the final and
original (pre-redirect) URL and takes the worse result, precisely because a redirect
to a different domain can indicate a masked malicious source. The VT check now does
the same: when `originalUrl` resolves to a different registered domain than the final
URL, both are checked against VirusTotal in parallel (sharing one `AbortController`)
and the worse (lower-scoring) verdict is reported. The safe-URL cache is still keyed
only to the exact final URL, never inferred from the original URL's result.

### Fixed: lookalike-character heuristic false positive, then re-enabled
`SketchyUrlCheck.js`'s generic lookalike-character check (`hasLookalikeChar`) had been
disabled because it flagged legitimate numbered infrastructure names (e.g.
`download3.operacdn.com`) — a trailing digit right before a dot was treated the same
as a real letter substitution. Fixed and re-enabled:
- A lookalike character immediately before a **dot** (a real DNS label boundary) is no
  longer flagged — trailing numeric suffixes (`download3.`, `cdn1.`, `mirror2.`,
  `ns2.`) are a normal infrastructure-naming convention.
- A lookalike character immediately before a **hyphen/underscore/tilde**, or at the
  absolute end of the hostname, is still flagged — same-label position, still a
  plausible substitution (e.g. `paypa1-security.info`).
- Detection now works on *runs* of consecutive lookalike characters, not just single
  characters, gated by a curated set of plausible letter-pairs (`oo`, `ee`, `ie`, `ei`,
  `oi`, `io`, `ea`, `ai`, `ia`, `ss`) — this catches `g00gle` and `prev10us` without
  also flagging meaningless digit runs (version strings, resolutions, build numbers).
- Known trade-off: a legitimate version-number idiom like `app-v1-prod` can now also
  trigger (single digit after a letter, before a hyphen) — the same structural shape
  as a genuine attack pattern like `paypa1-`. Not distinguishable at the character
  level; noted for future refinement if it proves too noisy in practice.
- All of this file's score weights (previously inline magic numbers) are now named
  constants in one `SCORES` block at the top of the file.

### Also cleaned up (no behavior change)
- `pages/options/OptionsPage.js`: removed an unnecessary regex escape in `DOMAIN_RE`.
- `pages/warning/WarningPage.js`: removed `vtDone`, a module-level variable that was
  written but never read (dead state).
- `protection/BrowserProtection.js`: `abortControllers` now declared `const` (never
  reassigned, only mutated); the old nested `parseVtResponse` function declaration
  inside a `try` block (annex-B legacy syntax) was replaced entirely by the new
  `fetchVtEvaluation` helper used by the `originalUrl` fix above; the unused
  `urlObject` variable (kept only for its `new URL()` validity check) was removed.
- `protection/ScoringEngineV2.js`: documented the intentionally-empty URL-parse
  `catch` block; `total` now declared `const` (never reassigned); removed `rdapLabel`,
  a dead variable whose fallback could never trigger (`RdapProtection.js` always sets
  `label`) and whose one real usage read `rdap.label` directly anyway.

## V2.4.0
Two new download heuristics using existing permissions only. No new permissions required.

### New check 13: Double extension in filename (`ScoringEngineV2.js`, `background.js`)
Detects filenames where a dangerous extension is hidden behind a safe-looking decoy:
`invoice.pdf.exe`, `photo.jpg.scr`, `setup.zip.bat`. High-confidence signal — virtually
never seen in legitimate software. `getDoubleExtension(filename)` helper added to
`background.js`. Score constant: `SCORING_CONFIG.DOUBLE_EXTENSION_SCORE` (−50).

### New check 6: Opaque download path (`SketchyUrlCheck.js`)
Legitimate software distribution almost always uses a meaningful filename in the URL path.
A path ending in a script endpoint or query-parameter delivery pattern with no visible
extension is a common redirect-chain malware delivery pattern. Three pattern groups:
- Query-param delivery (`?id=`, `?file=`, `?dl=`, `?token=`, `?key=`, `?hash=`)
- Generic download endpoint (`/download/`, `/dl/`, `/get/`, `/serve/`, `/fetch/`)
- Server-side script endpoint (`.php`, `.aspx`, `.asp`, `.cfm`, `.cgi`, `.jsp`)
Adds +20 to the SketchyUrl score. Skipped when the URL already has a visible dangerous
extension (those are caught by the extension classifier, not this heuristic).

### Considered and dropped: Chrome Safe Browsing danger field
`DangerCheck.js` was implemented and then removed. For the danger values that matter
(`url`, `content`, `host`, `unwanted`) Chrome already shows its own interstitial warning
and blocks the download before our warning page ever opens — making the check redundant.
The remaining values (`uncommon`, `potentially_unwanted`) were too weak to justify keeping
the module. `DangerCheck.js` deleted; all `danger` params removed from
`BrowserProtection.checkHostReputation()` and `ScoringEngineV2.evaluateHostReputation()`.

### Considered and dropped: No referrer on executable
A `referrer === ""` signal was implemented but removed before release. Chrome does not
expose the referrer policy applied by the server or the browser, making it impossible to
distinguish a genuinely absent referrer from one stripped by: command-line flags
(`--no-referrers`), adblockers modifying request headers, `rel="noreferrer"` links,
bookmarks, or the address bar. False positive rate was too high to justify a scored penalty.

### Wiring (`background.js`, `BrowserProtection.js`)
- `getDoubleExtension()` passed to all three `BrowserProtection.checkHostReputation()`
  call sites: `onCreated`, late-entry `onChanged`, and obfuscation re-run `onChanged`.
- `BrowserProtection.checkHostReputation()` signature extended with one new optional
  parameter: `doubleExt` (defaults to `null`).

### Manifest (V2.4.0)
- Version bumped to `2.4.0`.
- No new permissions required — all new signals use `downloads` API data already available.

---

## V2.3.1
Warning page — situation-aware button labels, disclaimers, and URLs.
No scoring or logic changes.

### Warning page (`WarningPage.js`)
- **Disclaimer — VT has results**: updated to
  *"This is what VirusTotal knows about the download URL. When in doubt, upload
  the download itself at VirusTotal using the button."*
- **Disclaimer — VT unknown**: replaced with
  *"Accept conditions, ignore e-mail requirement and select QUICK SCAN for free
  hybrid analysis at METADEFENDER and CROWDSTRIKE, before opening the downloaded
  file!"*
- **`btn-vt` label — VT has results**: `Check download at VT` (unchanged).
- **`btn-vt` label — VT unknown**: dynamically set to
  `Check download at Hybrid Analysis` by `renderDisclaimer()`.
- **`btn-vt` target — VT unknown**: opens `https://hybrid-analysis.com/`
  instead of the VirusTotal homepage.
- Both buttons continue to call `DISMISS_CHECK` and `window.close()` on click.

### Manifest (V2.3.1)
- Version bumped to `2.3.1`.

---

## V2.3.0
Dead-code removal and constant extraction. No logic or behaviour changes.

### Dead code removed (`WarningPage.js`)
- **`SCRIPT_EXTS_CLIENT`**: declared but never read anywhere in the file
  (`eslint-disable-line no-unused-vars` was the tell). Removed the `const`
  declaration and its reference in the module header comment.
- **`window._warningTitlePost`**: assigned in `applySettings()` with a comment
  referencing `applySlippedThroughUi`, a function that does not exist anywhere
  in the codebase. Removed the assignment and the stale comment.
- **`ScriptExts.js` script tag** (`WarningPage.html`): loaded solely to populate
  `SCRIPT_EXTS_CLIENT`; removed alongside that constant.
- **`ScriptExts.js` web_accessible_resources entry** (`manifest.json`): no page
  context loads it anymore; removed from the accessible-resources list. The file
  itself remains, loaded by the service worker via `importScripts`.

### Constant extracted (`ScoringEngineV2.js`, `background.js`)
- **`FP_UNKNOWN_MULTIPLIERS`**: the four FP-level host-score multipliers
  (`HIGH: 0.5 / MEDIUM: 1.0 / LOW: 1.5 / NONE: 2.0`) were an inline object
  literal in `background.js` (onChanged). Moved into `SCORING_CONFIG` in
  `ScoringEngineV2.js` as `FP_UNKNOWN_MULTIPLIERS` with a full explanatory
  comment. `background.js` now references `SCORING_CONFIG.FP_UNKNOWN_MULTIPLIERS`.

### CSS extracted (`WarningPage.html`, `WarningPage.css`)
- **`vtScoreRow` / `hostScoreRow` inline styles**: `display:none`,
  `margin-top`, `font-size`, `border-top`, `padding-top` were inline on the
  div; `font-weight` and `font-family` were inline on the inner span.
  Replaced with `.score-row` and `.score-row-value` CSS classes (audit A6).
  JS continues to reveal these rows with `style.display = ""` as before.

### Manifest (V2.3.0)
- Version bumped to `2.3.0`.
- `ScriptExts.js` removed from `web_accessible_resources`.

---

## V2.2.0
Trust boundary hardening and file-extension obfuscation detection.

### Trust boundary — built-in domain whitelist tightened
- **Google Drive, OneDrive, iCloud, Dropbox removed** from the built-in
  do-not-check list. These are user-controlled storage services — any user
  can upload a malicious file and share a download link. Bypassing all checks
  for these domains was a security gap, not a convenience feature.
- **SharePoint removed** from the built-in list for the same reason (org-controlled
  content; any org member can upload). Offered instead as a pre-populated entry
  in the user-configurable custom domain whitelist so existing users can restore
  it if needed.
- Built-in list now contains only platform-vetted app stores where every upload
  passes mandatory review: `chromewebstore.google.com`, `apps.microsoft.com`,
  `apps.apple.com`.
- Each remaining entry documented with a comment explaining why it is trusted.

### File-extension obfuscation detection (new)
- **`getObfuscationSignal(originalExt, confirmedExt)`** (`background.js`): compares
  the extension known at `onCreated` time with the confirmed extension from
  `onChanged`. Returns a descriptor when the extension was hidden or switched
  category, or `null` when clean.
  - `UNKNOWN_REVEALED`: no extension at creation time → dangerous ext confirmed
    at completion (e.g. Google Drive redirect chains hiding the filename).
  - `CATEGORY_CHANGED`: extension was known but switched risk category between
    creation and completion.
- **Late-entry path** (`onChanged`): downloads where Chrome did not know the
  filename at `onCreated` (e.g. Drive redirect chains) are now picked up at
  completion via `chrome.downloads.search()`. A minimal record is built and
  host reputation is run synchronously, including the obfuscation signal.
- **Obfuscation scoring** (`ScoringEngineV2.js`): obfuscation signals feed into
  the host-reputation score via `APP.OBFUSCATION_UNKNOWN_SCORE` (−40) and
  `APP.OBFUSCATION_CATEGORY_CHANGE_SCORE` (−20).
- **`getExtCategory(ext)`** (`background.js`): classifies an extension as
  `"executable"`, `"archive"`, or `"none"` — used by `getObfuscationSignal`
  to detect category changes.

### Manifest (V2.2.0)
- Version bumped to `2.2.0`.
- Permissions and `host_permissions` unchanged.

---

## V2.1.0
Audit pass — structural, defensive-programming, and documentation improvements.
No logic or behaviour changes; scoring and UI remain identical.

### Bug fixes
- **`vtDone` undeclared variable** (`WarningPage.js`): was assigned without `let`/`const`,
  creating an implicit global. Declared as `let vtDone = false` with module state docs.
- **`-50` vs `-40` scoring discrepancy** (`ScoringEngineV2.js`): the 5–9 suspicious
  detection branch hardcoded `-50` but `SCORING_CONFIG.VT_SUSPICIOUS_5_9` was `-40`.
  The config value is now corrected to `-50` (matches the algorithm intent) and the
  hardcode is removed; the branch references the config constant.
- **SUBMIT_URL_TO_VT catch path** (`background.js`): network errors during VT submission
  polling now broadcast a `VT_RESULT_UPDATE` with null scores so the warning page
  does not wait indefinitely.
- **`openWarningPage` silent failure** (`background.js`): `chrome.windows.create()`
  failures are now caught and logged; the orphaned `pendingChecks` entry is cleaned up.

### Architecture
- **`util/AppConstants.js`** (new): single source of truth for all magic numbers —
  timeouts (`VT_WAIT_BUDGET_MS`, `VT_FETCH_TIMEOUT_MS`, `QUAD9_TIMEOUT_MS`, etc.),
  collection caps (`ALLOWED_URLS_MAX`), UI limits (`DOMAIN_WHITELIST_MAX`,
  `AUTO_ALLOW_THRESHOLD_MIN/MAX/DEFAULT`), and the default warning title string.
- **`util/MessageTypes.js`** (new): `MSG` frozen object — single source of truth for
  all `chrome.runtime` message type strings. Every send and receive site now references
  `MSG.GET_PENDING_CHECK` etc. instead of bare string literals.
- **Message router** (`background.js`): replaced `if/else if` chain with a single
  `switch (msg.type)` statement (audit C3).
- **`submitAndPollVt()`** (`background.js`): extracted the 60-line inline IIFE inside
  the `SUBMIT_URL_TO_VT` handler into a named top-level function (audit C1/C11).
- **`SCORING_CONFIG`** (`ScoringEngineV2.js`): `HOST_DOMAIN_BASE_SCORE`,
  `HOST_TLD_BASE_SCORE`, and `HOST_SKETCHY_URL_BASE` moved in from local `const`s
  (audit B1). All host-reputation base scores now live alongside VT scoring config.
- **`BrowserProtection.cleanup()`** (new): explicit lifecycle cleanup function — aborts
  all in-flight VT requests and clears the session URL cache (audit C8).
- **`WarningPage.js`**: wrapped in an IIFE so all variables are module-scoped rather
  than window-globals (audit C1). Added `chrome.runtime.onMessage` listener for
  `VT_RESULT_UPDATE` push messages.

### Defensive programming
- **`checkedIds` orphan sweep** (`background.js`): `sweepStaleEntries()` now also
  removes `checkedIds` entries that have no corresponding `pendingChecks` record
  (could arise after a SW restart mid-download).
- **`Settings.set` error handling** (`OptionsPage.js`, `PopupPage.js`): callbacks now
  check `chrome.runtime.lastError` and show an error message on storage failure
  instead of silently reporting success.
- **`BoundedUrlSet.clear()`** (new): allows `BrowserProtection.cleanup()` to reset
  the allowed-URLs cache.

### Code quality
- **Dead settings keys removed** (`Settings.js`): `warningTitlePost`,
  `isInstanceIDInitialized`, and `instanceID` removed from defaults — they were
  never written or read by any current code path. Users with stale `warningTitlePost`
  values will see it ignored on next settings merge (backward-compatible).
- **`browserAPI` shim removed**: all three page contexts and `Storage.js` used a
  `typeof browser === 'undefined' ? chrome : browser` shim. MV3 in Chrome has no
  `browser` global; replaced with direct `chrome` references throughout.
- **Default warning title deduplication**: `APP.WARNING_TITLE_DEFAULT` is now the
  single source of truth used by `Settings.js`, `OptionsPage.js`, and `WarningPage.js`.
- **`host-signals-empty` CSS class** (`WarningPage.css`): the inline
  `li.style.color = "#6b7280"` for the "no alarming signals" row is now a proper
  CSS class (audit A6).
- **Script load order**: `AppConstants.js` and `MessageTypes.js` are now listed first
  in all `importScripts()` and `<script src>` lists, reflecting their Tier 5/4
  position in the dependency tree. `<script>` tags moved from `<head>` to bottom of
  `<body>` in OptionsPage and PopupPage.
- **Module header comments**: all files now have a standard header documenting purpose,
  public interface, dependencies, and owned state (audit C10).

### Manifest (V2.1.0)
- Version bumped to `2.1.0`.
- `web_accessible_resources` updated to include `AppConstants.js`, `MessageTypes.js`,
  `Storage.js`, `Settings.js`, `ScriptExts.js`, and `ScoringEngineV2.js` — all loaded
  by the warning page at runtime and must be declared accessible.
- Permissions unchanged (`downloads`, `storage`, `alarms`).
- `host_permissions` unchanged (VirusTotal, Quad9, RDAP).

---

## V2.0.1
- Minor fixes following V2.0 release.

## V2.0
- **ScoringEngineV2**: two-axis scoring (VT + host reputation); full scoring
  configuration block (`SCORING_CONFIG`).
- **ScriptExts.js**: script/LOLBin extensions extracted to single shared file.
- **BoundedUrlSet**: `allowedUrls` capped at 200 entries with FIFO eviction.
- **State/timer/guards reference comments** added to `background.js`.
- **`abortControllers` leak fixed**: delete-not-replace on completion.

## V1.8
- **Auto-proceed feature**: option to automatically allow downloads above a configurable risk score threshold.
- **Two-score UI**: host reputation and VT each show their own confidence score.
- **Scoring overhaul**: simple additive scoring (VT score + age score + heuristics).
- **ABC consensus bonus**: percentage-based clean-engine bonus.
- **Loop guard**: `interceptPaused` boolean prevents `resume()` → `onCreated` loop.

## V1.7
- **Scoring refactor**: VT + age additive scoring; risky hosting scores rebalanced.
- **TLD list**: removed `.app`, `.dev`, `.cloud`, `.tech`, `.pro`.
- **MIME check**: `text/plain` neutral for binaries, mild penalty for scripts.
- **Script detection**: `SCRIPT_EXTS` list; `−25` heuristic for script-format downloads.

## V1.4.2
- Two-box layout: VT and heuristics in separate info boxes.

## V1.4.1
- Fixed duplicate "VirusTotal rates it currently as…" line.

## V1.4
- Post-download safety net: `onChanged` listener.
- Performance/memory: `chrome.alarms` sweep, `BoundedUrlSet`, dead file removed.
- Security: `web_accessible_resources` restricted; DOM node construction; sender validation.

## V1.3 (Chrome Web Store initial submission)
- Warning page with VT URL reputation check, host heuristics, overall risk score.
- FP reduction slider (HIGH / MEDIUM / LOW / NONE).
- Options page: API key, FP reduction, background colour, trusted domains.
