"use strict";

import { FpReductionEngines } from "../util/FpReductionEngines.js"; // getRawStats, filterResults — used by evaluateFromAnalysisResults below
import { UrlUtils } from "../util/UrlUtils.js"; // getHostname() — handles blob: URLs correctly (see that file)

/**
 * ScoringEngineV2.js
 *
 * Scores a download URL across two independent axes:
 *
 *   A. VirusTotal URL reputation
 *      Weights: detection 70 %, age (VT first-seen) 30 %
 *      Community score removed.
 *
 *   B. Host reputation  (five parallel checks)
 *      1. Quad9 DNS block check
 *      2. RDAP registration age  (only when Quad9 resolves the domain)
 *         • Standalone signal (no domain/TLD/URL hit): score × 2  (e.g. < 30 days → −40)
 *         • Combined with domain/TLD/URL hit: capped at −20 (supporting signal)
 *      3. Suspicious-domain list match  (domain score × VT-suspicious-≥9 multiplier, base −70)
 *      4. Suspicious-TLD list match     (TLD score   × VT-suspicious-5–9 multiplier, base −50)
 *      5. Sketchy URL pattern heuristics (SketchyUrlCheck score × base −35)
 *      6. MIME type vs file extension consistency (mismatch → −60, consistent → 0)
 *      7. File size vs VirusTotal maximum 650 MB  (exceeds → −20)
 *      8. HTTP protocol (when Quad9 resolves domain)  → −40
 *      9. IP address as download host (IPv4 or IPv6)  → −30
 *     10. Risky hosting platform                    → −15 to −80
 *     11. Script format (LOLBin-style)               → −25
 *     12. Extension obfuscation (onCreated vs onChanged) → −20 to −40
 *     13. HTTPS-to-HTTP redirect downgrade            → −35
 *     14. Double/deceptive extension chain            → −50
 *     15. URL contains embedded credentials           → −45
 *     16. Linux .desktop launcher file                → −35
 *
 *   The caller (BrowserProtection / background.js) runs both axes in parallel
 *   and reports whichever produces the worst (lowest) final score.
 */
// ─────────────────────────────────────────────────────────────────────────────
// SCORING CONFIGURATION — tune all thresholds and bonuses here.
// Changing a value here affects the entire scoring system automatically.
// ─────────────────────────────────────────────────────────────────────────────
export const SCORING_CONFIG = {

    // ── VT detection base scores ──────────────────────────────────────────────
    VT_CLEAN_BASE:          30,    // base score when all engines clean
    VT_LONGEVITY_7D:        10,    // bonus: URL first seen > 7 days ago
    VT_LONGEVITY_30D:       30,    // bonus: URL first seen > 30 days ago

    // ── ABC consensus bonus (percentage of responding engines that are clean) ──
    ABC_A_PCT:              90,    // ≥ 90% clean → bonus A
    ABC_B_PCT:              70,    // ≥ 70% clean → bonus B
    ABC_C_PCT:              50,    // ≥ 50% clean → bonus C
    ABC_A_BONUS:            30,
    ABC_B_BONUS:            20,
    ABC_C_BONUS:            10,
    ABC_MIN_DAYS:            7,    // hard block: URL must be > 7 days old for bonus to apply

    // ── VT age penalties ──────────────────────────────────────────────────────
    VT_AGE_UNDER2D:        -20,    // URL first seen < 2 days ago
    VT_AGE_UNDER7D:        -10,    // URL first seen 2–7 days ago

    // ── VT detection penalties ────────────────────────────────────────────────
    VT_MALICIOUS_5PLUS:   -100,
    VT_MALICIOUS_3_4:      -80,    // base, scaled by age multiplier
    VT_MALICIOUS_1_2:      -60,    // base, scaled
    VT_SUSPICIOUS_10PLUS:  -70,
    VT_SUSPICIOUS_5_9:     -50,    // base, scaled  ← was -40 in config but -50 in code; -50 is correct
    VT_SUSPICIOUS_3_4:     -30,    // base, scaled
    VT_SUSPICIOUS_2:       -20,    // base
    VT_SUSPICIOUS_1:       -15,    // base

    // ── Host reputation base scores ───────────────────────────────────────────
    // Align with the VT detection tiers they correspond to:
    //   DOMAIN_BASE: mirrors VT suspicious ≥ 9 class (−70)
    //   TLD_BASE:    mirrors VT suspicious 5–8 class (−50)
    //   SKETCHY_URL: heuristic only — lower confidence than list hits
    HOST_DOMAIN_BASE_SCORE: -70,
    HOST_TLD_BASE_SCORE:    -50,
    HOST_SKETCHY_URL_BASE:  -35,

    // ── Classification thresholds (combined VT + host score) ─────────────────
    THRESHOLD_SAFE:         30,    // score ≥ 30  → probably safe
    THRESHOLD_QUESTIONABLE: -30,   // score ≥ -30 → probably inconclusive
    THRESHOLD_SUSPICIOUS:   -60,   // score ≥ -60 → probably suspicious
                                   // score <  -60 → probably malicious

    // ── VT confidence thresholds ──────────────────────────────────────────────
    CONFIDENCE_HIGH_DAYS:  180,    // > 180 days → High confidence
    CONFIDENCE_MED_DAYS:    30,    // > 30 days  → Medium confidence

    // ── Host reputation: script format ────────────────────────────────────────
    SCRIPT_FORMAT_SCORE:   -25,    // penalty for script downloads (.ps1, .vbs, etc.)

    // ── Host reputation: HTTP / IP penalties ──────────────────────────────────
    HTTP_PENALTY:          -40,
    // IP_HOST_PENALTY now covers IPv4, IPv6, and any noncanonical IPv4 form
    // (integer/hex/octal) that the browser's URL parser already canonicalizes
    // to a literal IP before we ever see it — see isIpHost() below (DS-H005).
    IP_HOST_PENALTY:       -30,

    // ── DS-H006 — HTTPS-to-HTTP redirect downgrade ─────────────────────────────
    // Download started on HTTPS but the final URL is unencrypted HTTP.
    // Independent signal from HTTP_PENALTY above (which fires when the whole
    // download was HTTP from the start) — a downgrade is a stronger signal
    // because it implies an active redirect stripped encryption mid-flight.
    HTTPS_DOWNGRADE_SCORE: -35,

    // ── DS-H004 — URL contains embedded credentials (user:pass@host) ───────────
    // Classic disguise: the visible text before "@" can look like a trusted
    // hostname while the actual destination (url.hostname) is something else.
    URL_CREDENTIALS_SCORE: -45,

    // ── DS-H001 — Linux .desktop launcher file ──────────────────────────────────
    // A .desktop file can define an Exec= line that runs an arbitrary shell
    // command when opened from a file manager — comparable risk tier to a
    // raw script (see SCRIPT_FORMAT_SCORE) but slightly higher because the
    // "double-click to run a document" affordance makes it easier to trigger
    // by accident than a visibly-scripty file.
    LINUX_LAUNCHER_SCORE:  -35,

    // ── Double extension in filename ──────────────────────────────────────────
    // e.g. invoice.pdf.exe — the true dangerous extension is hidden behind a
    // decoy extension. Virtually never legitimate. High-confidence signal.
    DOUBLE_EXTENSION_SCORE:            -50,

    // ── VT-unknown host-score multipliers ─────────────────────────────────────
    // Applied in background.js (onChanged) when VT has no data for the URL.
    // Scales negative host-reputation signals based on FP reduction level:
    //   HIGH   → conservative (dampen alarm when VT data is absent)
    //   MEDIUM → neutral (no scaling)
    //   LOW    → amplify (lean toward warning when VT data is absent)
    //   NONE   → most aggressive amplification
    // Positive host scores are never scaled (no free bonus from VT absence).
    FP_UNKNOWN_MULTIPLIERS: Object.freeze({
        HIGH:   0.5,
        MEDIUM: 1.0,
        LOW:    1.5,
        NONE:   2.0,
    }),
};

export const ScoringEngineV2 = (function () {

    const Classification = {
        PROBABLY_SAFE:         "Probably Safe",
        PROBABLY_QUESTIONABLE: "Probably Inconclusive",
        PROBABLY_SUSPICIOUS:   "Probably Suspicious",
        PROBABLY_MALICIOUS:    "Probably Malicious"
    };

    const SECONDS_PER_DAY = 86400;

    // ─────────────────────────────────────────────────────────────────────────
    // A.1  Detection Score  (VT analysis stats)
    //      Age-weighted: recent first-seen dates amplify negative signals.
    // ─────────────────────────────────────────────────────────────────────────
    function scoreDetection(stats, ageDays) {

        const malicious  = stats.malicious  ?? 0;
        const suspicious = stats.suspicious ?? 0;
        const harmless   = stats.harmless   ?? 0;

        const under2 = ageDays !== null && ageDays < 2;
        const under7 = ageDays !== null && ageDays < 7;

        // ── Malicious ────────────────────────────────────────────────────────
        if (malicious >= 5) {
            return { score: SCORING_CONFIG.VT_MALICIOUS_5PLUS, label: "≥ 5 malicious detections" };
        }
        if (malicious >= 3) {
            const score = Math.round(SCORING_CONFIG.VT_MALICIOUS_3_4 * (under7 ? 1.0 : 0.5));
            return { score, label: "3–4 malicious detections" };
        }
        if (malicious >= 1) {
            const mult  = under2 ? 1.0 : under7 ? 0.5 : 0.1;
            const score = Math.round(SCORING_CONFIG.VT_MALICIOUS_1_2 * mult);
            const label = malicious === 1 ? "1 malicious detection" : "2 malicious detections";
            return { score, label };
        }

        // ── Suspicious ───────────────────────────────────────────────────────
        if (suspicious >= 10) {
            return { score: SCORING_CONFIG.VT_SUSPICIOUS_10PLUS, label: "≥ 10 suspicious detections" };
        }
        if (suspicious >= 5) {
            const score = Math.round(SCORING_CONFIG.VT_SUSPICIOUS_5_9 * (under7 ? 1.0 : 0.5));
            return { score, label: "5–9 suspicious detections" };
        }
        if (suspicious >= 3) {
            const score = Math.round(SCORING_CONFIG.VT_SUSPICIOUS_3_4 * (under7 ? 1.0 : 0.5));
            return { score, label: "3–4 suspicious detections" };
        }
        if (suspicious === 2) {
            const mult  = under2 ? 1.5 : under7 ? 1.0 : 0.1;
            const score = Math.round(SCORING_CONFIG.VT_SUSPICIOUS_2 * mult);
            return { score, label: "2 suspicious detections" };
        }
        if (suspicious === 1) {
            const mult  = under2 ? 2.0 : under7 ? 1.0 : 0.5;
            const score = Math.round(SCORING_CONFIG.VT_SUSPICIOUS_1 * mult);
            return { score, label: "1 suspicious detection" };
        }

        // Clean file — apply longevity bonus + ABC consensus bonus.
        // Longevity: file has been in VT's database long enough to be scrutinised.
        // ABC bonus: rewards clean consensus across many engines (see evaluate()).
        if (harmless > 0) {
            const over30      = ageDays !== null && ageDays >= 30;
            const over7       = ageDays !== null && ageDays >= 7;
            const longevity   = over30 ? SCORING_CONFIG.VT_LONGEVITY_30D : over7 ? SCORING_CONFIG.VT_LONGEVITY_7D : 0;
            const score       = SCORING_CONFIG.VT_CLEAN_BASE + longevity + (arguments[2] || 0); // abcBonus passed as 3rd arg
            const label       = over30
                ? "No malicious detections (established file)"
                : "No malicious detections";
            return { score, label };
        }
        return { score: 10, label: "Undetected" };
    }

    // ─────────────────────────────────────────────────────────────────────────
    // A.2  VT First-Seen Age Score
    //      Cut-points: < 2 days → −20,  2–7 days → −10,  > 7 days → 0
    // ─────────────────────────────────────────────────────────────────────────
    function scoreVtAge(firstSubmissionDate) {

        if (firstSubmissionDate === null || firstSubmissionDate === undefined) {
            return { score: 0, ageDays: null, label: "Unknown age" };
        }

        const ageDays = (Date.now() / 1000 - firstSubmissionDate) / SECONDS_PER_DAY;
        const days    = Math.max(0, Math.floor(ageDays));

        if (ageDays > 7)  return { score: 0, ageDays, label: `${days} days since first seen` };
        if (ageDays > 2)  return { score: SCORING_CONFIG.VT_AGE_UNDER7D, ageDays, label: `${days} days since first seen` };
        return                   { score: SCORING_CONFIG.VT_AGE_UNDER2D, ageDays, label: `${days} days since first seen` };
    }

    // ─────────────────────────────────────────────────────────────────────────
    // A.3  Confidence (VT axis only — reflects data richness, not score)
    // ─────────────────────────────────────────────────────────────────────────
    function computeVtConfidence(ageDays) {
        if (ageDays === null || ageDays === undefined) return "Low";
        if (ageDays > SCORING_CONFIG.CONFIDENCE_HIGH_DAYS) return "High";
        if (ageDays >= SCORING_CONFIG.CONFIDENCE_MED_DAYS) return "Medium";
        return "Low";
    }

    // ─────────────────────────────────────────────────────────────────────────
    // A.4  Hard Rules (VT axis — override score-based classification)
    // ─────────────────────────────────────────────────────────────────────────
    function applyHardRules(malicious, suspicious) {
        if (malicious >= 5) {
            return { classification: Classification.PROBABLY_MALICIOUS, reason: "≥ 5 malicious detections" };
        }
        if (suspicious >= 10) {
            return { classification: Classification.PROBABLY_MALICIOUS, reason: "≥ 10 suspicious detections" };
        }
        if (malicious >= 1) {
            return {
                classification: Classification.PROBABLY_SUSPICIOUS,
                reason: `${malicious} malicious detection${malicious > 1 ? "s" : ""}`
            };
        }
        return null;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Score → Classification  (shared by both axes)
    // ─────────────────────────────────────────────────────────────────────────
    function classifyByScore(score) {
        if (score >= SCORING_CONFIG.THRESHOLD_SAFE)         return Classification.PROBABLY_SAFE;
        if (score >= SCORING_CONFIG.THRESHOLD_QUESTIONABLE) return Classification.PROBABLY_QUESTIONABLE;
        if (score >= SCORING_CONFIG.THRESHOLD_SUSPICIOUS)   return Classification.PROBABLY_SUSPICIOUS;
        return Classification.PROBABLY_MALICIOUS;
    }

    // =========================================================================
    // B.  Host Reputation Scoring
    //
    // Base multipliers come from VT detection tiers:
    //   suspicious ≥ 9  → −70  (used for domain-list check)
    //   suspicious 5–8  → −50  (used for TLD check)
    //
    // The domain-list/TLD risk score (0–100) acts as a proportion of that
    // multiplier, e.g. a domain with score 80 contributes 80/100 × −70 = −56.
    //
    // RDAP registration age is applied additively after the base score, using
    // the 30-day cut-point:
    //   < 30 days  →  −20
    //   30–90 days →  −10
    //   > 90 days  →    0
    // =========================================================================

    // Host base scores are now in SCORING_CONFIG (HOST_DOMAIN_BASE_SCORE,
    // HOST_TLD_BASE_SCORE, HOST_SKETCHY_URL_BASE) — no local consts needed.

    /**
     * Evaluate host reputation from the four parallel checks.
     *
     * @param {object} params
     * @param {object} params.quad9          - result from Quad9Protection.check()
     * @param {object} params.rdap           - result from RdapProtection.check()
     * @param {object|null} params.domainHit  - result from SuspiciousDomains.lookup()
     * @param {object|null} params.tldHit     - result from SuspiciousTlds.lookup()
     * @param {object|null} params.sketchyUrl - result from SketchyUrlCheck.check()
     * @param {string} params.fileType        - "executable" | "archive"
     * @param {string|null} params.originalUrl - pre-redirect URL, used for the
     *        HTTPS-to-HTTP downgrade check (DS-H006); omit or pass same as
     *        url when there was no redirect.
     * @param {boolean} params.isLinuxLauncher - true when the confirmed
     *        extension is ".desktop" (DS-H001).
     */
    function evaluateHostReputation({ quad9, rdap, domainHit, tldHit, sketchyUrl, mimeResult, sizeResult, riskyHosting, url, originalUrl = null, fileType = "executable", isScript = false, obfuscation = null, doubleExt = null, isLinuxLauncher = false }) {

        const results = [];

        // ── Check 1: Quad9 block ─────────────────────────────────────────────
        if (quad9) {
            if (quad9.status === "BLOCKED") {
                const label = `Confirmed malicious (${fileType} from Quad9-blocked domain)`;
                results.push({ score: -100, label, source: "Quad9" });
            }
            // ALLOWED / UNKNOWN contribute 0; RDAP and domain/TLD checks add their own signals
        }

        // ── RDAP age penalty ──────────────────────────────────────────────────
        // Two modes depending on whether a domain/TLD list hit is also present:
        //   • Standalone (no domainHit, no tldHit): full score × 2 multiplier
        //     e.g. < 30 days → −30 × 2 = −40  (young domain is the only signal)
        //   • Combined with domainHit/tldHit: capped at −20 (supporting signal only)
        const rdapRaw   = rdap?.score ?? 0;
        // Parse URL once for protocol checks; hostname comes from
        // UrlUtils.getHostname() instead of parsedUrl.hostname directly,
        // since the latter is "" for blob: URLs (see UrlUtils.js) — using it
        // directly here would silently disable the IP-host check and blank
        // out the credentials-check label below for any blob: download.
        let parsedUrl = null;
        try { parsedUrl = new URL(url || ""); } catch { /* invalid/empty URL — parsedUrl stays null, isHttp/isIpHost fall through to false */ }
        const hostname = UrlUtils.getHostname(url) || "";

        // DS-H005 — IPv4 dotted-decimal OR IPv6 literal (bracketed by the URL
        // parser, e.g. "[2001:db8::1]"). Integer/hex/octal IPv4 forms
        // (e.g. "0x7f000001", "2130706433") need no extra handling here: the
        // WHATWG URL parser already canonicalizes those to dotted-decimal in
        // hostname before this code ever runs, so the IPv4 regex alone
        // already catches them.
        const isIpv4Host = /^\d+\.\d+\.\d+\.\d+$/.test(hostname);
        const isIpv6Host = hostname.startsWith("[") && hostname.endsWith("]");
        const isIpHost    = !!(isIpv4Host || isIpv6Host);
        const isHttp    = parsedUrl && parsedUrl.protocol === "http:";

        // DS-H006 — HTTPS-to-HTTP downgrade: compare the ORIGINAL URL's
        // protocol (before any redirect) against the final URL's protocol.
        // Parsed separately from parsedUrl above since originalUrl may be a
        // different URL entirely (redirect chain), not just a variant of url.
        let parsedOriginalUrl = null;
        if (originalUrl && originalUrl !== url) {
            try { parsedOriginalUrl = new URL(originalUrl); } catch { /* leave null — no downgrade signal without a valid original URL */ }
        }
        const isHttpsToHttpDowngrade = !!(
            parsedOriginalUrl && parsedUrl &&
            parsedOriginalUrl.protocol === "https:" &&
            parsedUrl.protocol === "http:"
        );

        // DS-H004 — URL contains embedded username and/or password. Parsed
        // fields only (url.username / url.password) — never string matching,
        // so an encoded "@" inside a normal path can't produce a false hit.
        const hasUrlCredentials = !!(parsedUrl && (parsedUrl.username || parsedUrl.password));

        const hasListHit = !!(domainHit || tldHit || (sketchyUrl && sketchyUrl.score > 0) || (mimeResult && mimeResult.score < 0) || isHttp || isIpHost || riskyHosting || isScript || hasUrlCredentials || isHttpsToHttpDowngrade || isLinuxLauncher);

        // Score used additively inside domain/TLD combined entries
        const rdapAdditive = rdapRaw < 0 ? Math.max(rdapRaw, -20) : 0;

        // Score used when RDAP is the only signal (2× multiplier)
        const rdapStandalone = rdapRaw < 0 ? Math.max(rdapRaw * 2, -100) : 0;

        if (quad9?.status === "ALLOWED" && rdapRaw < 0 && !hasListHit) {
            results.push({
                score:  rdapStandalone,
                label:  `New domain registration: ${rdap.label}`,
                source: "RDAP"
            });
        }

        // ── Check 3: Suspicious domain list ──────────────────────────────────
        if (domainHit) {
            const baseScore      = Math.round((domainHit.score / 100) * SCORING_CONFIG.HOST_DOMAIN_BASE_SCORE);
            const combined       = Math.max(-100, baseScore + rdapAdditive);
            results.push({
                score:  combined,
                label:  `Suspicious domain "${domainHit.matchedDomain}"`,
                source: "DomainList"
            });
        }

        // ── Check 4: Suspicious TLD ───────────────────────────────────────────
        if (tldHit) {
            const baseScore   = Math.round((tldHit.score / 100) * SCORING_CONFIG.HOST_TLD_BASE_SCORE);
            const combined    = Math.max(-100, baseScore + rdapAdditive);
            results.push({
                score:  combined,
                label:  `Top Level Domain .${tldHit.tld} is on the much abused TLD list`,
                source: "TldList"
            });
        }

        // ── Check 5: Sketchy URL pattern heuristics ──────────────────────────
        if (sketchyUrl && sketchyUrl.score > 0) {
            const baseScore = Math.round((sketchyUrl.score / 100) * SCORING_CONFIG.HOST_SKETCHY_URL_BASE);
            const combined  = Math.max(-100, baseScore + rdapAdditive);
            const topSignal = (sketchyUrl.signals && sketchyUrl.signals[0]) || "Suspicious URL pattern";
            // Strip the score suffix from signal text e.g. "(+20)" or "(+15)"
            const cleanSignal = topSignal.replace(/\s*\(\+\d+\).*$/, "").trim();
            results.push({
                score:  combined,
                label:  `Suspicious URL pattern: ${cleanSignal}`,
                source: "SketchyUrl"
            });
        }

        // ── Check 6: MIME type consistency ───────────────────────────────────
        if (mimeResult && !mimeResult.neutral) {
            if (mimeResult.score < 0) {
                results.push({
                    score:  Math.max(-100, mimeResult.score + rdapAdditive),
                    label:  `File extension ".${mimeResult.ext || ""}" does not match MIME type "${mimeResult.mime || ""}"`,
                    source: "MimeCheck"
                });
            }
            // Consistent result (score 0) — added as informational after scoring
        }

        // ── Check 7: File size vs VirusTotal maximum ──────────────────────────
        if (sizeResult && sizeResult.exceeds) {
            results.push({
                score:  sizeResult.score,
                label:  "File size exceeds scan maximum, only use if you are 100% certain it is safe",
                source: "SizeCheck"
            });
        }

        // ── Check 8: HTTP protocol ───────────────────────────────────────────
        // Only penalise when Quad9 confirms the domain resolves (ALLOWED).
        // If blocked or unknown, other signals already cover the risk.
        if (isHttp && quad9?.status === "ALLOWED") {
            results.push({
                score:  SCORING_CONFIG.HTTP_PENALTY,
                label:  "Download served over unencrypted HTTP (not HTTPS)",
                source: "ProtocolCheck"
            });
        }

        // ── Check 9: IP address as download host ──────────────────────────────
        // Covers IPv4, IPv6, and noncanonical IPv4 (see isIpv4Host/isIpv6Host
        // derivation above) — DS-H005.
        if (isIpHost) {
            results.push({
                score:  SCORING_CONFIG.IP_HOST_PENALTY,
                label:  `Download hosted directly on an IP address (${hostname}) rather than a normal domain`,
                source: "IpAddressCheck"
            });
        }

        // ── Check 13: HTTPS-to-HTTP redirect downgrade ─────────────────────────
        // DS-H006 — the download began on an encrypted connection but the
        // final URL is unencrypted HTTP, implying a redirect stripped TLS.
        if (isHttpsToHttpDowngrade) {
            results.push({
                score:  SCORING_CONFIG.HTTPS_DOWNGRADE_SCORE,
                label:  "Download was redirected from an encrypted HTTPS connection to an unencrypted HTTP connection",
                source: "ProtocolDowngrade"
            });
        }

        // ── Check 15: URL contains embedded credentials ────────────────────────
        // DS-H004 — e.g. https://trusted.example@evil.example/file — the text
        // before "@" can be crafted to look like a trusted host while
        // hostname (the actual destination) is something else.
        if (hasUrlCredentials) {
            results.push({
                score:  SCORING_CONFIG.URL_CREDENTIALS_SCORE,
                label:  `Download URL contains embedded credentials — the actual destination is "${hostname}"`,
                source: "UrlCredentials"
            });
        }

        // ── Check 16: Linux desktop launcher file ───────────────────────────────
        // DS-H001 — a .desktop file can define an Exec= line that runs an
        // arbitrary shell command when opened.
        if (isLinuxLauncher) {
            results.push({
                score:  SCORING_CONFIG.LINUX_LAUNCHER_SCORE,
                label:  "This file is a Linux desktop launcher and may execute a command when opened",
                source: "LinuxLauncher"
            });
        }

        // ── Check 10: Risky hosting platform ─────────────────────────────────
        if (riskyHosting) {
            results.push({
                score:  riskyHosting.score,
                label:  riskyHosting.label,
                source: "RiskyHosting"
            });
        }

        // ── Check 11: Script format (LOLBin-style interpreted scripts) ────────
        // A download that is a raw script (.ps1, .vbs, .sh, .py, etc.) rather
        // than a compiled binary is a meaningful anomaly: legitimate software
        // distribution overwhelmingly ships compiled installers, not bare
        // scripts. Scripts execute via a trusted system interpreter (LOLBin
        // technique), which is a common malware delivery and evasion pattern.
        // -25: notable signal on its own, but not enough alone to reach the
        // "probably malicious" threshold (-60) since legitimate scripts
        // (setup.sh, install.py, dev tooling) do exist.
        if (isScript) {
            results.push({
                score:  SCORING_CONFIG.SCRIPT_FORMAT_SCORE,
                label:  "The download is a script, not a program — this is suspicious",
                source: "ScriptFormat"
            });
        }

        // ── Check 12: Extension obfuscation ───────────────────────────────────
        // Fires when the confirmed extension (onChanged) reveals danger that was
        // hidden at download-creation time (onCreated). Two tiers:
        //   UNKNOWN_REVEALED  : no extension was detectable at creation; the
        //                       server actively concealed what it was serving.
        //   CATEGORY_CHANGED  : an extension was known but switched risk category
        //                       (e.g. archive → executable) after redirect/rename.
        if (obfuscation) {
            if (obfuscation.type === "UNKNOWN_REVEALED") {
                results.push({
                    score:  SCORING_CONFIG.OBFUSCATION_UNKNOWN_SCORE,
                    label:  `Dangerous file type (.${obfuscation.confirmedExt}) was hidden — no extension visible at download start`,
                    source: "Obfuscation"
                });
            } else if (obfuscation.type === "CATEGORY_CHANGED") {
                results.push({
                    score:  SCORING_CONFIG.OBFUSCATION_CATEGORY_CHANGE_SCORE,
                    label:  `File type category changed from ${obfuscation.fromCategory} (.${obfuscation.originalExt}) to ${obfuscation.toCategory} (.${obfuscation.confirmedExt})`,
                    source: "Obfuscation"
                });
            }
        }

        // ── Check 14: Deceptive extension chain ─────────────────────────────────
        // e.g. invoice.pdf.exe, invoice.pdf.zip.exe — a dangerous extension
        // hidden behind one or more decoy extensions. Virtually never seen in
        // legitimate software. High-confidence signal. DS-H003 generalized
        // this from a strict "last two labels" check to the full chain.
        if (doubleExt) {
            const repeatedDotsNote = doubleExt.repeatedDots
                ? " (with repeated or empty extension segments)" : "";
            results.push({
                score:  SCORING_CONFIG.DOUBLE_EXTENSION_SCORE,
                label:  `The filename contains a misleading extension chain${repeatedDotsNote}: "${doubleExt.decoy}" hiding ".${doubleExt.dangerous}"`,
                source: "DoubleExtension"
            });
        }

        if (results.length === 0) {
            // All checks passed with no negative signals — report as Probably Clean.
            // Score 0 maps to PROBABLY_QUESTIONABLE by threshold, so we override
            // the classification directly to PROBABLY_SAFE here.
            return {
                score:           0,
                classification:  Classification.PROBABLY_SAFE,
                label:           "No alarming signals found — domain probably safe",
                hardRuleApplied: null,
                breakdown:       []
            };
        }

        // Worst (lowest) score wins — SketchyUrl always shown last in breakdown
        const LAST_SOURCES = new Set(["SketchyUrl", "IpAddressCheck", "ProtocolCheck", "RiskyHosting"]);
        results.sort((a, b) => {
            const aLast = LAST_SOURCES.has(a.source);
            const bLast = LAST_SOURCES.has(b.source);
            if (aLast && !bLast) return  1;
            if (!aLast && bLast) return -1;
            return a.score - b.score;
        });
        const worst = results.find(r => !LAST_SOURCES.has(r.source)) || results[0];

        // Quad9 block is always Probably Malicious regardless of numeric score
        const hardRule = (worst.source === "Quad9" && worst.score === -100)
            ? `${worst.label}`
            : null;

        const classification = hardRule
            ? Classification.PROBABLY_MALICIOUS
            : classifyByScore(worst.score);

        const hostLabel = classification === Classification.PROBABLY_MALICIOUS
            ? "Suspicious signals found — domain probably malicious"
            : "Suspicious signals found — domain probably suspicious";

        return {
            score:           worst.score,
            classification,
            label:           hostLabel,
            hardRuleApplied: hardRule,
            breakdown:       results
        };
    }

    // =========================================================================
    // A.  VirusTotal URL Evaluation  (public — called by BrowserProtection)
    // =========================================================================

    /**
     * Evaluate VT analysis results.
     * Weights: detection 70 %, age 30 %.  Community removed.
     */
    function evaluate({
        stats               = {},
        rawStats            = null,
        firstSubmissionDate = null,
        fpLevel             = "NONE"
    } = {}) {

        const safeStats  = (stats !== null && typeof stats === "object") ? stats : {};
        const malicious  = safeStats.malicious  ?? 0;
        const suspicious = safeStats.suspicious ?? 0;

        const age = scoreVtAge(firstSubmissionDate);

        // ── ABC consensus bonus ───────────────────────────────────────────────
        // Rewards a strong clean consensus across responding VT engines.
        // Percentage-based: cleanCount / (cleanCount + suspicious + malicious)
        // so 21/21 = 100% regardless of how many engines total responded.
        //
        // Hard block — bonus cannot fire when:
        //   • URL first seen at VT < 7 days ago  (too new to trust consensus)
        //   • Any engine at the current FP level flagged suspicious or malicious
        //
        // Cut-offs:    A ≥ 90% → +30,  B ≥ 70% → +20,  C ≥ 50% → +10
        const cleanCount     = (safeStats.harmless || 0) + (safeStats.undetected || 0);
        const respondedCount = cleanCount + (safeStats.suspicious || 0) + (safeStats.malicious || 0);
        const cleanPct       = respondedCount > 0 ? (cleanCount / respondedCount) * 100 : 0;
        const vtTooNew       = age.ageDays !== null && age.ageDays < SCORING_CONFIG.ABC_MIN_DAYS;

        let abcBonus = 0;
        let abcLabel = null;
        if (cleanCount > 0 && malicious === 0 && suspicious === 0 && !vtTooNew) {
            if      (cleanPct >= SCORING_CONFIG.ABC_A_PCT) { abcBonus = SCORING_CONFIG.ABC_A_BONUS; abcLabel = "A"; }
            else if (cleanPct >= SCORING_CONFIG.ABC_B_PCT) { abcBonus = SCORING_CONFIG.ABC_B_BONUS; abcLabel = "B"; }
            else if (cleanPct >= SCORING_CONFIG.ABC_C_PCT) { abcBonus = SCORING_CONFIG.ABC_C_BONUS; abcLabel = "C"; }
        }

        const detection = scoreDetection(safeStats, age.ageDays, abcBonus);

        // VT score = detection score + age score — simple addition, no weighting.
        // Age influence comes through two clean mechanisms:
        //   1. Longevity bonus inside scoreDetection (+10 at >7 days, +30 at >30 days)
        //   2. Age penalty here (−10 at 2–7 days, −20 at <2 days)
        //   3. ABC hard block prevents bonus firing when first seen < 7 days
        // The old 70/30 weighted split is removed — it was redundant with the
        // longevity bonus already baked into detection.
        const total = Math.max(-100, Math.min(100, detection.score + age.score));

        const hardRule       = applyHardRules(malicious, suspicious);
        const classification = hardRule ? hardRule.classification : classifyByScore(total);

        return {
            classification,
            score:           total,
            confidence:      computeVtConfidence(age.ageDays),
            hardRuleApplied: hardRule?.reason ?? null,
            breakdown:       { detection: { ...detection, abcLabel }, age },
            rawStats:        rawStats || safeStats,
            filteredStats:   safeStats,
            fpLevel
        };
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Compose the full "count votes → filter → score" sequence from a raw VT
    // last_analysis_results object. Shared by background.js and
    // BrowserProtection.js, which previously ran this identical 3-call
    // sequence (FpReductionEngines.getRawStats → .filterResults →
    // ScoringEngineV2.evaluate) independently (jscpd-flagged duplicate, audit
    // pass). No behavior change — same three calls, same order, same inputs.
    //
    // Returns { eval, raw, filtered } — matches the shape both call sites
    // already used.
    // ─────────────────────────────────────────────────────────────────────────
    function evaluateFromAnalysisResults(results, fpLevel, firstSubmissionDate) {
        const raw      = FpReductionEngines.getRawStats(results);
        const filtered = FpReductionEngines.filterResults(results, fpLevel);
        const evalResult = evaluate({
            stats:               filtered,
            rawStats:            raw,
            firstSubmissionDate: firstSubmissionDate ?? null,
            fpLevel
        });
        return { eval: evalResult, raw, filtered };
    }

    // ─────────────────────────────────────────────────────────────────────────
    return {
        Classification,
        evaluate,
        evaluateFromAnalysisResults,
        evaluateHostReputation,
        classifyByScore
    };

})();
