# Download Sentinel — Changelog

> Note on this file: entries from V2.6.1 onward are reconstructed with high
> confidence from the working session that produced them. History before
> V2.6.1 (this project's earlier versions, up to and including V2.5.3) is
> not reproduced here — that content was never available in a session that
> also had write access to this file, so rather than guess at it, this
> starts clean from V2.6.1. If you have the original file, the entries
> below should be merged above it, not replace it.

## V2.6.3
**Fixed a real bug: `blob:` download URLs were never matching the trusted-domains list (or any other host-based check), because `blob:` isn't a "special" URL scheme and the code was extracting an empty hostname from every blob download. Rebuilt the full dev-tooling bundle (tests/, tools/, config), which had been lost between sessions.**

Working from v2.6.2 (the latest packaged release).

### Bug fix: `blob:` URL hostname extraction
- **Root cause:** `new URL("blob:https://claude.ai/uuid").hostname` is `""` — always. `blob:` is not a "special" scheme per the WHATWG URL spec (unlike http/https/ftp/ws/wss/file), so the parser never extracts an authority/host from one. The real hostname is embedded in `.pathname` instead (the full inner URL, e.g. `"https://claude.ai/uuid"`).
- **Fixed at the source:** `UrlUtils.getHostname()` now detects `protocol === "blob:"` and re-parses `.pathname` as its own URL to recover the real host. That origin is set by the browser itself at blob-creation time and can't be forged by a page, so this is a reliable signal, not a guess. A sandboxed/opaque-origin blob (`blob:null/uuid`) falls back to `null` — the same conservative result an unparseable URL gets, since there's genuinely no host to trust there.
- **Three call sites were bypassing `UrlUtils` entirely** with their own direct `new URL(...).hostname` parses, so fixing `UrlUtils.getHostname()` alone wasn't sufficient — each needed rerouting:
  - `background.js`'s `isTrustedDomain()` — the actual function your trusted-domains list feeds into, and the direct cause of the reported symptom (adding `claude.ai` to trusted domains had no effect on blob downloads from claude.ai).
  - `protection/SketchyUrlCheck.js`'s `check()` — contributed to false "no extension visible" framing on blob downloads generally (not a scoring bug itself, just inherited the empty-hostname problem for its own host-based checks).
  - `protection/ScoringEngineV2.js`'s `evaluateHostReputation()` — the IP-host check and two message labels used `parsedUrl.hostname` directly instead of the already-correct `UrlUtils.getHostname()` pattern used everywhere else in that function.
- `protection/BrowserProtection.js` needed **zero changes** — it already consistently used `UrlUtils.getHostname()` everywhere, so it inherited the fix automatically once the source was corrected.
- New regression tests added to `tests/UrlUtils.test.js` (blob unwrapping, port handling, non-http inner origin, opaque-origin fallback), `tests/ScoringEngineV2.test.js` (IP-host detection through a blob-wrapped URL), and `tests/SketchyUrlCheck.test.js` (blob-wrapped brand domain, blob-wrapped impersonation).

### Dev-tooling bundle rebuilt
The full working tree (`tests/`, `tools/complete-check.mjs`, `package.json`, `.eslintrc.json`, `knip.json`, `.depcheckrc.json`, `.gitignore`) only ever existed inside a prior session's temporary sandbox and was never packaged separately from the extension-only zip — so it was genuinely lost between sessions, not just misplaced. Rebuilt from the session record and reapplied on top of the current (fixed) source. Two real bugs were found and fixed during the rebuild, independent of the blob-URL fix:
- **`package.json`'s `test` and `test:coverage` scripts both had the `node --test <directory>` bug** documented elsewhere in this file for `tools/complete-check.mjs` — Node's test runner mis-resolves a directory positional argument in this project's setup. `complete-check.mjs` already used the fixed form (`node --test`, no argument, relying on `cwd`), but the *standalone* `npm test` script still had the broken form and had apparently never been run on its own before now. Fixed to match.
- **`tools/complete-check.mjs`'s message-routing cross-reference (step 5) had two false-failure gaps**, found immediately on the first rebuild run: it only recognized a sender as `sendMessage(...MSG.X...)` on one line, missing `background.js`'s actual pattern of building a message object with a separate `type: MSG.X` field; and it only recognized a router as a `switch`/`case`, missing `WarningPage.js`'s actual pattern of an `if (msg.type !== MSG.X) return;` guard clause. Both patterns are broadened for now.

### Verification performed
`npm run check` passes end to end: 34 files parsed cleanly, ESLint clean, JSON valid, C20/C20a cross-references clean (once the two gaps above were fixed), 130/130 unit tests passing, no circular dependencies, no unused files/exports, no unused dependencies, no duplicate code. `npm test`, `npm run test:coverage` (95.3% statement coverage), `npm run circular`, `npm run deps`, and `npm run unused` all independently verified working as standalone scripts, not just through `npm run check`.

## V2.6.2
**Brand-detector integration (SketchyUrlCheck.js) — typo-tolerant brand-impersonation detection.**

Working from v2.6.1 (the latest packaged release).

Investigated an uploaded brand-detector prototype (Levenshtein-distance brand-name scoring + a SymSpell-style fuzzy-match sketch). Adopted the small, low-risk piece — edit-distance matching against a curated brand list — and skipped the larger piece (a 100k-domain corpus + SymSpell index), which was unfinished, needed external data not available, and was disproportionate to this project's scale.

- **Brand table expanded from 29 to 113 entries**, sourced from Interbrand's Best Global Brands 2025 and Comparably's Top 1000 Brands (only the first 100 of the latter were reachable). Every canonical domain individually verified rather than assumed from the company name; several were non-obvious: Schneider Electric → `se.com`, Monster → `monsterenergy.com`, American Eagle → `ae.com`, Peloton → `onepeloton.com`, Bungie → `bungie.net`, GE Aerospace → `geaerospace.com`, Johnson & Johnson → `jnj.com`, Procter & Gamble → `pg.com`.
- **New fuzzy (edit-distance) brand matching** (`isFuzzyBrandImpersonation`, `SCORES.FUZZY_BRAND_IMPERSONATION` = 12) — catches a genuine misspelling used as the whole domain (`gooogle.com`, `microsft.com`) that exact substring matching can't. Scope limit: whole-label comparison only, so a typo combined with a suffix (`micrsoft-support.com`) isn't caught by this layer — exact matching already covers that case when the brand name is spelled correctly.
- **Generic-word false positives found and fixed via automated sweep testing**, in several rounds: `booking`/`monster` bare-word guards (used `booking.com`/`monsterenergy` as the keyword instead); a pre-existing bug where `zoominfo.com` was misflagged as Zoom (fixed with a new per-brand `exceptions` field); `app`/`mail` common-subdomain collisions and two pairs of real, unrelated brands in the table being coincidentally near each other (`shopify`↔`spotify`, `cisco`↔`costco`) — fixed with a `FUZZY_EXCLUDED_LABELS` set and a whole-host `isKnownLegitimateBrandHost()` early-out; `space`/`teach` colliding with 5-letter keywords — fixed by scaling the allowed edit distance with keyword length.
- **Known accepted gap, documented rather than silently left:** the length-scaled threshold means a classic "rn→m" homograph trick (`arnazon.com`) isn't caught on 6-letter-or-shorter brands. Left as a possible future, more surgical (bigram-aware) addition.
- New `tests/SketchyUrlCheck.test.js` (24 tests) covering all of the above.
- Performance verified: ~230µs per `check()` call at the full 113-brand table — negligible for a once-per-download check.

## V2.6.1
**Added a local test suite and expanded `tools/complete-check.mjs` from 6 to 11 steps; fixed several small audit findings; fixed all four jscpd-flagged code duplicates. No scoring/protection/UI logic changed.**

### Testing infrastructure
- `tests/` — unit tests using Node's built-in test runner (zero extra deps), covering every pure/deterministic module: `UrlUtils`, `DangerousExts`, `DangerousMimes`, `FilenameAnalysis`, `MimeCheck`, `FpReductionEngines`, `ScoringEngineV2` (both scoring axes), and `Storage`/`Settings` (via an in-memory `chrome.storage.local` mock with explicit install/reset/uninstall lifecycle guards).
- New `util/FilenameAnalysis.js` — extracted 7 pure filename/extension functions out of `background.js` into their own module (one module, one responsibility) so they can be unit-tested without a `chrome.*` mock. No logic change — same canonical sources, just moved.
- `package.json` declares `"type": "module"` (needed for Node's own tooling to parse the ESM syntax the extension already used everywhere).
- `.eslintrc.json`: bumped `parserOptions.ecmaVersion` to 2022 (top-level `await` support).

### `tools/complete-check.mjs`: 6 steps → 11
Added: unit tests (hard gate), circular-dependency check via madge (hard gate), unused-file/export detection via knip (soft — and root-caused a real crash in knip's experimental `oxc-parser` "raw transfer" mode, fixed with `KNIP_DISABLE_RAW_TRANSFER=1`, wired portably via `cross-env`), unused-dependency detection via depcheck (soft), duplicate-code detection via jscpd (soft).

### jscpd findings — all four fixed
- New `FilenameAnalysis.classifyDownload()` replaced two identical inline blocks in `background.js` (`onCreated` and the `onChanged` late-entry path).
- New `buildSettingsSnapshot()` in `background.js` replaced two identical inline settings-snapshot blocks.
- New `ScoringEngineV2.evaluateFromAnalysisResults()` replaced a duplicated 3-call scoring sequence in both `background.js` and `BrowserProtection.js`.
- `util/UrlUtils.js` added to `manifest.json`'s `web_accessible_resources`; `WarningPage.js`'s inline `toVtUrlId()` (duplicated to avoid that exact manifest change, before other `util/` files established the same precedent) was removed in favor of importing the real one.

### Small audit findings fixed
- C9a naming: `Storage.js`/`Settings.js`'s public methods were anonymous function expressions assigned to object properties — now named.
- CSS bug: `rgb(256, 256, 256)` (out of RGB range) in two CSS files, fixed to `rgb(255, 255, 255)`.
