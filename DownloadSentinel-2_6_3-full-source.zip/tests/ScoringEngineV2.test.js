"use strict";

import { test, describe } from "node:test";
import assert from "node:assert/strict";
import { ScoringEngineV2, SCORING_CONFIG } from "../protection/ScoringEngineV2.js";

describe("ScoringEngineV2.classifyByScore", () => {
    test("boundary cases map to the documented tiers", () => {
        assert.equal(ScoringEngineV2.classifyByScore(30), ScoringEngineV2.Classification.PROBABLY_SAFE);
        assert.equal(ScoringEngineV2.classifyByScore(29), ScoringEngineV2.Classification.PROBABLY_QUESTIONABLE);
        assert.equal(ScoringEngineV2.classifyByScore(-30), ScoringEngineV2.Classification.PROBABLY_QUESTIONABLE);
        assert.equal(ScoringEngineV2.classifyByScore(-31), ScoringEngineV2.Classification.PROBABLY_SUSPICIOUS);
        assert.equal(ScoringEngineV2.classifyByScore(-60), ScoringEngineV2.Classification.PROBABLY_SUSPICIOUS);
        assert.equal(ScoringEngineV2.classifyByScore(-61), ScoringEngineV2.Classification.PROBABLY_MALICIOUS);
    });
});

describe("ScoringEngineV2.evaluate (VT axis)", () => {
    test("hard rule: 5+ malicious detections is always Probably Malicious", () => {
        const r = ScoringEngineV2.evaluate({ stats: { malicious: 5, suspicious: 0, harmless: 10 } });
        assert.equal(r.classification, ScoringEngineV2.Classification.PROBABLY_MALICIOUS);
        assert.ok(r.hardRuleApplied);
    });

    test("hard rule: 10+ suspicious detections is always Probably Malicious", () => {
        const r = ScoringEngineV2.evaluate({ stats: { malicious: 0, suspicious: 10, harmless: 5 } });
        assert.equal(r.classification, ScoringEngineV2.Classification.PROBABLY_MALICIOUS);
    });

    test("clean file, old and well-established, scores in the safe range", () => {
        const oneYearAgo = Math.floor(Date.now() / 1000) - 365 * 86400;
        const r = ScoringEngineV2.evaluate({
            stats: { malicious: 0, suspicious: 0, harmless: 60, undetected: 10 },
            firstSubmissionDate: oneYearAgo
        });
        assert.equal(r.classification, ScoringEngineV2.Classification.PROBABLY_SAFE);
        assert.equal(r.confidence, "High");
    });

    test("clean but brand new (< 7 days) does not get the ABC consensus bonus", () => {
        const twoDaysAgo = Math.floor(Date.now() / 1000) - 2 * 86400;
        const withBonus = ScoringEngineV2.evaluate({
            stats: { malicious: 0, suspicious: 0, harmless: 60 },
            firstSubmissionDate: Math.floor(Date.now() / 1000) - 365 * 86400
        });
        const tooNew = ScoringEngineV2.evaluate({
            stats: { malicious: 0, suspicious: 0, harmless: 60 },
            firstSubmissionDate: twoDaysAgo
        });
        assert.equal(withBonus.breakdown.detection.abcLabel, "A");
        assert.equal(tooNew.breakdown.detection.abcLabel, null);
    });

    test("no data at all (unknown to VT) does not crash and yields a neutral-ish result", () => {
        const r = ScoringEngineV2.evaluate();
        assert.equal(typeof r.score, "number");
        assert.equal(r.confidence, "Low");
    });

    test("score is clamped to the documented [-100, 100] range", () => {
        const r = ScoringEngineV2.evaluate({
            stats: { malicious: 0, suspicious: 0, harmless: 100 },
            firstSubmissionDate: Math.floor(Date.now() / 1000) - 1000 * 86400
        });
        assert.ok(r.score <= 100 && r.score >= -100);
    });
});

describe("ScoringEngineV2.evaluateHostReputation", () => {
    test("Quad9 block is always Probably Malicious regardless of other signals", () => {
        const r = ScoringEngineV2.evaluateHostReputation({
            quad9: { status: "BLOCKED" },
            rdap: null, domainHit: null, tldHit: null, sketchyUrl: null,
            mimeResult: null, sizeResult: null, riskyHosting: null,
            url: "https://evil.example/malware.exe"
        });
        assert.equal(r.classification, ScoringEngineV2.Classification.PROBABLY_MALICIOUS);
        assert.ok(r.hardRuleApplied);
    });

    test("no signals at all reports Probably Safe with an empty breakdown", () => {
        const r = ScoringEngineV2.evaluateHostReputation({
            quad9: { status: "ALLOWED" },
            rdap: null, domainHit: null, tldHit: null, sketchyUrl: null,
            mimeResult: null, sizeResult: null, riskyHosting: null,
            url: "https://example.com/file.exe"
        });
        assert.equal(r.classification, ScoringEngineV2.Classification.PROBABLY_SAFE);
        assert.deepEqual(r.breakdown, []);
    });

    test("IP-address host is flagged (IPv4)", () => {
        const r = ScoringEngineV2.evaluateHostReputation({
            quad9: { status: "ALLOWED" }, rdap: null, domainHit: null, tldHit: null,
            sketchyUrl: null, mimeResult: null, sizeResult: null, riskyHosting: null,
            url: "http://203.0.113.5/file.exe"
        });
        assert.ok(r.breakdown.some(b => b.source === "IpAddressCheck"));
    });

    test("IPv6 literal host is also flagged", () => {
        const r = ScoringEngineV2.evaluateHostReputation({
            quad9: { status: "ALLOWED" }, rdap: null, domainHit: null, tldHit: null,
            sketchyUrl: null, mimeResult: null, sizeResult: null, riskyHosting: null,
            url: "http://[2001:db8::1]/file.exe"
        });
        assert.ok(r.breakdown.some(b => b.source === "IpAddressCheck"));
    });

    test("HTTP-only penalty fires only when Quad9 ALLOWED the domain", () => {
        const allowed = ScoringEngineV2.evaluateHostReputation({
            quad9: { status: "ALLOWED" }, rdap: null, domainHit: null, tldHit: null,
            sketchyUrl: null, mimeResult: null, sizeResult: null, riskyHosting: null,
            url: "http://example.com/file.exe"
        });
        assert.ok(allowed.breakdown.some(b => b.source === "ProtocolCheck"));

        const unknown = ScoringEngineV2.evaluateHostReputation({
            quad9: { status: "UNKNOWN" }, rdap: null, domainHit: null, tldHit: null,
            sketchyUrl: null, mimeResult: null, sizeResult: null, riskyHosting: null,
            url: "http://example.com/file.exe"
        });
        assert.ok(!unknown.breakdown.some(b => b.source === "ProtocolCheck"));
    });

    test("HTTPS-to-HTTP downgrade is detected independently of the HTTP-only check", () => {
        const r = ScoringEngineV2.evaluateHostReputation({
            quad9: { status: "UNKNOWN" }, rdap: null, domainHit: null, tldHit: null,
            sketchyUrl: null, mimeResult: null, sizeResult: null, riskyHosting: null,
            url: "http://example.com/file.exe",
            originalUrl: "https://example.com/file.exe"
        });
        assert.ok(r.breakdown.some(b => b.source === "ProtocolDowngrade"));
    });

    test("embedded URL credentials are detected via parsed fields, not string matching", () => {
        const r = ScoringEngineV2.evaluateHostReputation({
            quad9: { status: "ALLOWED" }, rdap: null, domainHit: null, tldHit: null,
            sketchyUrl: null, mimeResult: null, sizeResult: null, riskyHosting: null,
            url: "https://user:pass@evil.example/file.exe"
        });
        assert.ok(r.breakdown.some(b => b.source === "UrlCredentials"));
    });

    test("an '@' inside an encoded path segment does not false-positive as credentials", () => {
        const r = ScoringEngineV2.evaluateHostReputation({
            quad9: { status: "ALLOWED" }, rdap: null, domainHit: null, tldHit: null,
            sketchyUrl: null, mimeResult: null, sizeResult: null, riskyHosting: null,
            url: "https://example.com/user%40handle/file.exe"
        });
        assert.ok(!r.breakdown.some(b => b.source === "UrlCredentials"));
    });

    test("double-extension chain and script format both surface in the breakdown", () => {
        const r = ScoringEngineV2.evaluateHostReputation({
            quad9: { status: "ALLOWED" }, rdap: null, domainHit: null, tldHit: null,
            sketchyUrl: null, mimeResult: null, sizeResult: null, riskyHosting: null,
            url: "https://example.com/invoice.pdf.exe",
            doubleExt: { decoy: ".pdf", dangerous: "exe", repeatedDots: false },
            isScript: true
        });
        assert.ok(r.breakdown.some(b => b.source === "DoubleExtension" && b.score === SCORING_CONFIG.DOUBLE_EXTENSION_SCORE));
        assert.ok(r.breakdown.some(b => b.source === "ScriptFormat" && b.score === SCORING_CONFIG.SCRIPT_FORMAT_SCORE));
    });

    test("suspicious domain-list hit is scaled from the 0-100 input score", () => {
        const r = ScoringEngineV2.evaluateHostReputation({
            quad9: { status: "ALLOWED" }, rdap: null,
            domainHit: { score: 100, matchedDomain: "evil.example" },
            tldHit: null, sketchyUrl: null, mimeResult: null, sizeResult: null, riskyHosting: null,
            url: "https://evil.example/file.exe"
        });
        const hit = r.breakdown.find(b => b.source === "DomainList");
        assert.ok(hit);
        assert.equal(hit.score, SCORING_CONFIG.HOST_DOMAIN_BASE_SCORE); // 100% of base
    });

    test("blob: URL host is correctly unwrapped for the IP-address and credentials checks", () => {
        // Regression test: these checks used to read parsedUrl.hostname
        // directly, which is "" for blob: URLs — silently disabling the
        // IP-host check and blanking the credentials-check label for any
        // blob: download. Now routed through UrlUtils.getHostname().
        const r = ScoringEngineV2.evaluateHostReputation({
            quad9: { status: "ALLOWED" }, rdap: null, domainHit: null, tldHit: null,
            sketchyUrl: null, mimeResult: null, sizeResult: null, riskyHosting: null,
            url: "blob:http://203.0.113.5/deadbeef-1234-1234-1234-123456789012"
        });
        assert.ok(r.breakdown.some(b => b.source === "IpAddressCheck"));
    });
});

describe("ScoringEngineV2.evaluateFromAnalysisResults", () => {
    test("composes getRawStats + filterResults + evaluate and returns all three", () => {
        const results = {
            "BitDefender": { category: "malicious" },
            "Kaspersky":   { category: "harmless" }
        };
        const r = ScoringEngineV2.evaluateFromAnalysisResults(results, "NONE", null);
        assert.ok(r.eval);
        assert.ok(r.raw);
        assert.ok(r.filtered);
        assert.equal(r.raw.malicious, 1);
        assert.equal(r.filtered.malicious, 1); // NONE level does no filtering
        assert.equal(typeof r.eval.score, "number");
    });

    test("matches calling the three steps manually (no behavior change from the pre-extraction version)", () => {
        const results = { "Sophos": { category: "suspicious" }, "ESET-NOD32": { category: "harmless" } };
        const combined = ScoringEngineV2.evaluateFromAnalysisResults(results, "HIGH", 1000000000);
        // manual equivalent
        const manualEval = ScoringEngineV2.evaluate({
            stats: { malicious: 0, suspicious: 1, harmless: 1, undetected: 0 },
            rawStats: { malicious: 0, suspicious: 1, harmless: 1, undetected: 0 },
            firstSubmissionDate: 1000000000,
            fpLevel: "HIGH"
        });
        assert.equal(combined.eval.score, manualEval.score);
        assert.equal(combined.eval.classification, manualEval.classification);
    });
});
