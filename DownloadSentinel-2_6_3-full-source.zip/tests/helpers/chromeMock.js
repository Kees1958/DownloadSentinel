"use strict";

/**
 * chromeMock.js — minimal in-memory chrome.storage.local mock for unit tests.
 *
 * Storage.js / Settings.js are the only modules allowed to touch
 * chrome.storage directly (C4 — single storage layer), so this is the only
 * mock the test suite needs for storage-dependent code.
 *
 * Resource lifecycle (guard pattern, matches AppConstants.js conventions):
 *   installChromeMock()   — INIT:  attach globalThis.chrome, empty store
 *   resetChromeMock()     — CLEAR: wipe stored data between tests, keep mock installed
 *   uninstallChromeMock() — RELEASE: remove globalThis.chrome entirely
 */

let store = {};

function installChromeMock() {
    store = {};
    globalThis.chrome = {
        storage: {
            local: {
                get(key, callback) {
                    const result = {};
                    if (Object.prototype.hasOwnProperty.call(store, key)) {
                        result[key] = store[key];
                    }
                    queueMicrotask(() => callback(result));
                },
                set(data, callback) {
                    Object.assign(store, data);
                    queueMicrotask(() => { if (callback) callback(); });
                }
            }
        },
        runtime: {
            lastError: undefined
        }
    };
}

function resetChromeMock() {
    store = {};
}

function uninstallChromeMock() {
    delete globalThis.chrome;
    store = {};
}

export { installChromeMock, resetChromeMock, uninstallChromeMock };
