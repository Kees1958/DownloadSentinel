"use strict";

import { test, describe } from "node:test";
import assert from "node:assert/strict";
import { MimeCheck } from "../protection/MimeCheck.js";

describe("MimeCheck.checkMime", () => {
    test("consistent extension/MIME pair scores 0", () => {
        const r = MimeCheck.checkMime("exe", "application/x-msdownload");
        assert.equal(r.consistent, true);
        assert.equal(r.score, 0);
    });
    test("genuine mismatch scores -60", () => {
        const r = MimeCheck.checkMime("exe", "image/jpeg");
        assert.equal(r.consistent, false);
        assert.equal(r.score, -60);
    });
    test("application/octet-stream is neutral", () => {
        const r = MimeCheck.checkMime("exe", "application/octet-stream");
        assert.equal(r.neutral, true);
        assert.equal(r.score, 0);
    });
    test("text/plain served for a script extension gets a mild penalty", () => {
        const r = MimeCheck.checkMime("ps1", "text/plain");
        assert.equal(r.neutral, false);
        assert.equal(r.score, -20);
    });
    test("text/plain for a non-script extension is neutral", () => {
        const r = MimeCheck.checkMime("txt", "text/plain");
        assert.equal(r.neutral, true);
        assert.equal(r.score, 0);
    });
    test("strips MIME parameters before comparing", () => {
        const r = MimeCheck.checkMime("exe", "application/x-msdownload; charset=binary");
        assert.equal(r.consistent, true);
    });
    test("missing extension or MIME is unevaluable", () => {
        assert.equal(MimeCheck.checkMime("", "image/jpeg").neutral, true);
        assert.equal(MimeCheck.checkMime("exe", "").neutral, true);
    });
    test("unmapped extension is unevaluable, not a false mismatch", () => {
        const r = MimeCheck.checkMime("xyzabc", "application/octet-stream");
        assert.equal(r.neutral, true);
        assert.equal(r.score, 0);
    });
});

describe("MimeCheck.checkSize", () => {
    test("under the VT limit does not exceed", () => {
        const r = MimeCheck.checkSize(10 * 1024 * 1024);
        assert.equal(r.exceeds, false);
        assert.equal(r.score, 0);
    });
    test("over the VT limit (650 MB) exceeds and penalizes", () => {
        const r = MimeCheck.checkSize(700 * 1024 * 1024);
        assert.equal(r.exceeds, true);
        assert.equal(r.score, -20);
    });
    test("unknown size (0/null/negative) is treated as unknown, not exceeding", () => {
        assert.equal(MimeCheck.checkSize(0).exceeds, false);
        assert.equal(MimeCheck.checkSize(null).exceeds, false);
        assert.equal(MimeCheck.checkSize(-5).exceeds, false);
    });
});
