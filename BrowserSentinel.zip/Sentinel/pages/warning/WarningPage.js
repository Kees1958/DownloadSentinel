// ── Setup ──────────────────────────────────────────────────────────────────────

const params     = new URLSearchParams(location.search);
const downloadId = Number(params.get("downloadId"));

// If downloadId is missing or invalid, there's nothing to show
if (!downloadId) {
    document.body.innerHTML = "<p style='color:white;padding:2rem'>Invalid warning page — no download ID found.</p>";
    throw new Error("[DownloadSentinel] WarningPage opened without a valid downloadId");
}

const reasonText  = document.getElementById("reasonText");
const srcUrl      = document.getElementById("srcUrl");
const bpResult    = document.getElementById("bpResult");
const btnBack     = document.getElementById("btn-back");
const btnAllow    = document.getElementById("btn-allow");
const disclaimer  = document.getElementById("disclaimerText");

let vtDone = false;

// ── Apply settings (background color + disclaimer text) ───────────────────────

function applySettings(settings) {
    // Custom background color
    const r = settings.warningColorR ?? 179;
    const g = settings.warningColorG ?? 38;
    const b = settings.warningColorB ?? 30;
    document.body.style.backgroundColor = `rgb(${r}, ${g}, ${b})`;

    // Disclaimer text
    if (settings.isVtApiKeySet && settings.vtApiKey) {
        disclaimer.innerHTML =
            '<span style="color:#fff;">Disclaimer: this is what Virus Total currently knows, file can still be malicious!</span>';
    } else {
        disclaimer.innerHTML =
            '<span style="color:#fff;">Reputation check not activated, please </span>' +
            '<a href="https://www.virustotal.com/gui/join-us" target="_blank" ' +
            'style="color:rgb(243,186,34);font-weight:600;text-decoration:none;">' +
            'Get a free API key</a>';
    }
}

// Load settings as soon as the page is ready
Settings.get(applySettings);

// ── Download data ──────────────────────────────────────────────────────────────

function applyResult(data) {
    srcUrl.textContent     = data.url || "Unknown URL";
    reasonText.textContent = data.ext ? "." + data.ext : "Unknown";
    bpResult.textContent   = data.browserProtectionResult || "Checking...";
    applyVtStyling(data.browserProtectionResult);

    if (data.vtStatus === "done") vtDone = true;
}

// Initial fetch from background
chrome.runtime.sendMessage(
    { type: "GET_BLOCKED_DOWNLOAD", downloadId },
    data => {
        if (!data) return;
        applyResult(data);

        if (!vtDone) {
            const pollStart    = Date.now();
            const POLL_TIMEOUT = 3000;

            const pollInterval = setInterval(() => {
                // Hard cap: if VT hasn't answered within 3000ms, show Failed and stop
                if (Date.now() - pollStart >= POLL_TIMEOUT) {
                    clearInterval(pollInterval);
                    if (vtDone) return;
                    vtDone = true;
                    const suffix = data.ext ? "." + data.ext + " download" : "download";
                    bpResult.textContent = "Reputation check failed — " + suffix;
                    applyVtStyling(bpResult.textContent);
                    return;
                }

                chrome.runtime.sendMessage(
                    { type: "GET_BLOCKED_DOWNLOAD", downloadId },
                    polled => {
                        if (!polled) { clearInterval(pollInterval); return; }
                        applyResult(polled);
                        if (polled.vtStatus === "done") clearInterval(pollInterval);
                    }
                );
            }, 250);
        }
    }
);

// ── VT styling ─────────────────────────────────────────────────────────────────

function applyVtStyling(result) {
    bpResult.classList.remove("vt-malicious", "vt-suspicious", "vt-safe", "vt-unknown");

    if (!result || result.startsWith("Checking") || result.startsWith("Blocked")) {
        bpResult.classList.add("vt-unknown");
    } else if (result.startsWith("Probably clean")) {
        bpResult.classList.add("vt-safe");
    } else if (result.startsWith("Suspicious")) {
        bpResult.classList.add("vt-suspicious");
    } else if (
        result.startsWith("Unknown") ||
        result.startsWith("Questionable") ||
        result.startsWith("Reputation check failed")
    ) {
        bpResult.classList.add("vt-unknown");
    } else {
        bpResult.classList.add("vt-malicious");
    }
}

// ── Buttons ────────────────────────────────────────────────────────────────────

btnBack.addEventListener("click", () => window.close());

btnAllow.addEventListener("click", () => {
    btnAllow.disabled     = true;
    btnAllow.textContent  = "Starting download...";

    chrome.runtime.sendMessage({ type: "ALLOW_DOWNLOAD", downloadId }, response => {
        if (response && response.success) {
            window.close();
        } else {
            btnAllow.disabled    = false;
            btnAllow.textContent = "Ignore & Proceed";
            console.error("[DownloadProtection] Failed to allow download:", response?.error);
        }
    });
});
