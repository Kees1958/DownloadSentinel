"use strict";

// ── AppConstants.js ───────────────────────────────────────────────────────────
// Single source of truth for all application-wide magic numbers, limits, and
// timing values that are not specific to the VT scoring algorithm.
//
// Scoring thresholds and VT-analysis weights live in SCORING_CONFIG inside
// ScoringEngineV2.js because they are tightly coupled to the algorithm.
// Everything else — timeouts, collection caps, UI limits — lives here.
//
// Public interface:
//   APP  {Object}  — frozen map of named constants
//
// Dependencies: none
//
// Usage:
//   Service worker:   importScripts("util/AppConstants.js")
//   Page contexts:    <script src="../../util/AppConstants.js">
// ─────────────────────────────────────────────────────────────────────────────

export const APP = Object.freeze({

    // ── VirusTotal ─────────────────────────────────────────────────────────────

    // Single source of truth for VT's "join us" / free-API-key signup page —
    // used by the Options page's own link and by the startup VT-key nudge
    // popup (pages/vtkeyprompt/VtKeyPrompt.js, v3.0.7).
    VT_JOIN_URL: "https://www.virustotal.com/gui/join-us",

    // Fixed size for the VT-key nudge popup window (background.js's
    // openVtKeyPrompt()) — a small dialog, not maximized like the warning
    // page, since it's a short read with two buttons. Height is measured
    // content height (~337px at this width, via headless rendering) plus
    // just enough slack that the empty space below the Ignore/Request
    // buttons never exceeds the buttons' own height (~33px) — any more
    // reads as a visibly oversized window.
    VT_KEY_PROMPT_WINDOW_WIDTH:  520,
    VT_KEY_PROMPT_WINDOW_HEIGHT: 348,

    // ── Timing — service worker ───────────────────────────────────────────────

    // Total budget (ms) from download-created timestamp to when we give up
    // waiting for VT in the onChanged handler.
    // Breakdown: 3000 ms VT timeout + 100 ms BP startup delay +
    //            50 ms Settings.get overhead + 50 ms event-loop jitter +
    //            50 ms network RTT buffer.
    // The timestamp is set BEFORE API calls start so the budget covers all
    // setup overhead.
    VT_WAIT_BUDGET_MS: 3250,

    // How long a pendingChecks entry may live before the sweep removes it.
    ENTRY_MAX_AGE_MS: 30 * 60 * 1000,      // 30 minutes

    // How often the stale-entry alarm fires (minutes, as required by chrome.alarms).
    SWEEP_ALARM_PERIOD_MINUTES: 5,

    // Name of the chrome.alarms alarm used for stale-entry sweeping.
    SWEEP_ALARM_NAME: "sweepStaleEntries",

    // ── Timing — VT fetch (BrowserProtection.js) ─────────────────────────────

    // Hard timeout on the VT GET request; users get impatient beyond this.
    // Cached VT lookups typically resolve in 200–800 ms.
    VT_FETCH_TIMEOUT_MS: 3000,

    // Small pause before VT fetch so the warning page is mounted before the
    // result arrives (avoids a race where the result fires before listeners
    // are registered).
    VT_FETCH_STARTUP_DELAY_MS: 100,

    // ── Timing — VT submission polling (background.js SUBMIT_URL_TO_VT) ──────

    // Maximum time to wait for a freshly submitted URL to be analysed by VT.
    VT_SUBMIT_POLL_DEADLINE_MS: 15000,

    // Interval between poll attempts while waiting for VT analysis results.
    VT_SUBMIT_POLL_INTERVAL_MS: 1000,

    // ── Timing — DNS threat-intel / RDAP ──────────────────────────────────────

    // Hard timeout on a DNS-over-HTTPS threat-intel request (Quad9,
    // Cloudflare Security or Control D — whichever the user picked; see
    // DNS_PROVIDERS below). Renamed from QUAD9_TIMEOUT_MS in v3.0.6 when the
    // single-provider Quad9 check became "pick 2 of 3".
    DNS_TIMEOUT_MS: 8000,

    // Hard timeout on RDAP domain-registration-age requests.
    RDAP_TIMEOUT_MS: 8000,

    // ── DNS threat-intel providers (v3.0.6) ───────────────────────────────────
    // Single source of truth: every provider the user can pick as their
    // "first"/"second" DNS check, keyed by its storage id. Consumed by
    // protection/DnsThreatProtection.js (to build/parse the actual DoH
    // request) and pages/options/OptionsPage.js (to populate the two
    // dropdowns) — add a provider here once and both pick it up.
    //
    // blockStyle — how each resolver signals "this domain is blocked":
    //   "nxdomain-no-authority" — NXDOMAIN with an empty Authority section
    //                             (Quad9's heuristic — see DnsThreatProtection.js)
    //   "zero-ip"               — answers with 0.0.0.0 / :: instead of NXDOMAIN
    //                             (Cloudflare Security, Control D)
    DNS_PROVIDERS: Object.freeze({
        quad9:      Object.freeze({ id: "quad9",      label: "Quad9",                          host: "dns.quad9.net",               url: "https://dns.quad9.net/dns-query",               blockStyle: "nxdomain-no-authority" }),
        cloudflare: Object.freeze({ id: "cloudflare", label: "Cloudflare Security (malware)",   host: "security.cloudflare-dns.com", url: "https://security.cloudflare-dns.com/dns-query", blockStyle: "zero-ip" }),
        controld:   Object.freeze({ id: "controld",   label: "Control D (malware)",             host: "freedns.controld.com",        url: "https://freedns.controld.com/p1",               blockStyle: "zero-ip" }),
    }),

    // Storage value meaning "don't run this DNS check slot at all".
    DNS_NONE: "none",

    // Defaults for a first install: Quad9 as the first check, Control D as
    // the second (two different threat feeds, neither needing an account).
    DEFAULT_DNS_FIRST:  "quad9",
    DEFAULT_DNS_SECOND: "controld",

    // ── Collection caps ───────────────────────────────────────────────────────

    // Maximum number of safe URLs held in BrowserProtection.allowedUrls
    // (FIFO eviction when exceeded).
    ALLOWED_URLS_MAX: 200,

    // ── UI limits — Options page ──────────────────────────────────────────────

    // Maximum number of custom trusted-domain entries the user can add.
    DOMAIN_WHITELIST_MAX: 12,

    // Minimum and maximum values for the auto-allow threshold input.
    AUTO_ALLOW_THRESHOLD_MIN: 30,
    AUTO_ALLOW_THRESHOLD_MAX: 100,

    // Default auto-allow threshold when not set.
    AUTO_ALLOW_THRESHOLD_DEFAULT: 80,

    // ── Host reputation: obfuscation penalties ────────────────────────────────
    // Fired when the confirmed extension (onChanged) differs from what was known
    // at download-creation time (onCreated).
    //   UNKNOWN → dangerous : extension was completely hidden at creation time
    //   category change      : extension was known but switched risk category
    OBFUSCATION_UNKNOWN_SCORE:          -40,
    OBFUSCATION_CATEGORY_CHANGE_SCORE:  -20,

    // ── Default UI strings — shared between Settings, OptionsPage, WarningPage ─
    // Changing a default here updates all three consumers automatically.
    // May contain a single <br> for display purposes — only ever used via
    // innerHTML in WarningPage.js when no custom title has been set.
    WARNING_TITLE_DEFAULT:
        "Download requires your attention!",

    // ── Default warning window color ("Google Red") ──────────────────────────
    // Single source of truth for the default RGB triplet. Shared between
    // Settings.js (stored default), OptionsPage.js (color pickers + the
    // "reset to default when Personalize is unchecked" logic) and any future
    // consumer — never hardcode 179/38/30 anywhere else.
    WARNING_COLOR_DEFAULT_R: 179,
    WARNING_COLOR_DEFAULT_G: 38,
    WARNING_COLOR_DEFAULT_B: 30,

    // ── Built-in trusted domains — never checked ──────────────────────────────
    // Only platform-vetted app stores belong here. User-controlled cloud storage
    // (Google Drive, OneDrive, iCloud) and org-controlled hosting (SharePoint)
    // are intentionally excluded so malicious files served from those domains
    // are still inspected. SharePoint is offered as a starter entry in the user
    // whitelist (Settings.js → customDomains) so users can restore it if needed.
    // Shared between background.js (enforcement) and OptionsPage.js (display)
    // so the options page never shows a stale hardcoded list.
    BUILTIN_DO_NOT_CHECK_DOMAINS: [
        "chromewebstore.google.com",
        "apps.microsoft.com",
        "apps.apple.com",
    ],

});
