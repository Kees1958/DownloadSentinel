# Changelog History — DownloadSentinel

Full technical record of releases: what changed, why, how, known limitations and the source worked from.
The brief user-facing summary is CHANGELOG.md.

---

## 3.5.2 — staged warning window (WarnPolicy: thresholds per FP level + exceptions); quiet-download badge

Source worked from: DownloadSentinel 3.5.1 (delivered 2026-10-25). Design agreed with the user 2026-10-25 (user idea:
no window above −30 at FP Medium/High; refined together: exceptions that always warn, staged values per level, same
mechanism for 3P Matrix's site dialog). Built first in 3P Matrix 4.4.1's copy of this library, identical here.

### Shared library
- NEW protection/WarnPolicy.js — see its header. DOWNLOAD_WARN_FROM { HIGH −45, MEDIUM −30, LOW −15, NONE always };
  exceptions per check (download: KNOWN_BAD = DnsThreat or VT malicious ≥ 1, IMPERSONATION = LookalikeDomain /
  PlatformBrand, FILE_ITSELF = any WHAT-question signal, LURE_ROUTE = MessageOrigin, YOUNG_DOMAIN = RDAP ≤
  APP.RDAP_YOUNG_SCORE; site: KNOWN_BAD, IMPERSONATION). Explained entries never count. `windowHint()` = the Options
  sentence per level (both extensions).
- APP.RDAP_YOUNG_DAYS / RECENT_DAYS / YOUNG_SCORE / RECENT_SCORE / NO_DATE_SCORE (were literals in
  RdapProtection.scoreAge and copied in 3P Matrix).
- util/DeliveryPatterns.js: OPEN_PLATFORMS / ORG_PAGE_PLATFORMS + isOpenPlatform() / brandOnPlatform() (moved from
  3P Matrix 4.4.0's site check). ScoringEngineV2 Check 28 "PlatformBrand" for downloads (LOOKALIKE_SITE_SCORE);
  CombinationScoring FAMILY_MAP PlatformBrand → URL_SHAPE.
- SCORING_CONFIG.SCORE_FLOOR / SCORE_CEILING / DNS_BLOCKED_SCORE replace seven −100 / 100 literals in the engine.

### background.js
- After R1 always-warn and autoAllow ("Silent when probably safe", unchanged): `warnDecision(record, combined)`. Quiet →
  `record.quiet`, QuietLog.add({ filename, host, verdict, score, at }), releaseDownload() (keeps the record while a
  silent VT retry runs). The final-record fields (combinedScore, …) are now stored before this decision.
- handleLateVtResult: a quiet record opens the window only when warnDecision now says so; a dismissed window reopens
  when worse (unchanged).

### Quiet downloads — toolbar badge + popup
- NEW util/QuietLog.js (init / add / read / clear): newest APP.QUIET_LOG_MAX (10) entries in chrome.storage.session
  (APP.QUIET_LOG_KEY) — survives service-worker restarts, cleared on browser restart; badge text = count, colour
  APP.QUIET_BADGE_COLOR, title APP.QUIET_BADGE_TITLE. No new permission (storage + action already present).
- util/Storage.js: getFromSessionStore / setToSessionStore (single storage layer, C4).
- Popup: "Checked without a warning window" list (file, host · verdict (score)); opening the popup clears list + badge.
  Rendered and checked in headless Chromium.

### Options
- FP hint: "Higher = fewer false alarms: filters VirusTotal results and sets from which score a download gets a
  warning window." + WarnPolicy.windowHint(level).

### Tests
- tests/WarnPolicy.test.js (23): thresholds per level (boundary ±1), order, default level, every exception at every
  level, non-exceptions (route quirks, moderately new domain, explained), site check list, siteDecision, windowHint,
  brandOnPlatform incl. org page and DDNS, Check 28, RDAP constants. No typed scores — all from constants.
- tools/fp-sweep.mjs flows: "W / ·" (window / quiet) per FP level; attack flows must get a window wherever gated
  (Medium, Low, None). Result: at High and Medium 15 of 16 legit flows quiet (the extensionless Linux binary warns
  by design); every attack flow gets a window at every level, High included (A04 via LURE_ROUTE).
- Suite 509 → 532.

---

## 3.5.1 — hosting-platform list refreshed; IDN platform rules stored as punycode

Source worked from: DownloadSentinel 3.5.0 (zipped and delivered 2026-10-24). Trigger: 3P Matrix 4.4.0 is a minor
release, which rebuilds the shared lists (lib/downloadsentinel/ stays byte-identical to DS, so DS gets them too).
- PlatformSuffixes rebuilt from
  a fresh PSL (github.com/publicsuffix/list main, 2026-10-25 — publicsuffix.org itself is not reachable from the
  build sandbox): 3,447 → 3,448 entries. BUG FIXED in tools/update-domain-age-lists.mjs: PRIVATE rules were stored
  verbatim, so the 13 internationalized ones ("günstigbestellen.de", "биз.рус", …) were Unicode and could never
  match a hostname (the URL API reports punycode) — now converted with `toAscii()` (same as 3P Matrix's builder);
  DS and 3P Matrix builds are now identical. RdapCctlds and TopSitesFilter (CrUX 202609 is still the newest)
  unchanged. Runtime PublicSuffixList.json not rebuilt (its own 180-day freshness rule). Note: the freshness
  advisory reads raw-file dates, so tools/lists-raw/public_suffix_list.dat now reads "0 days old" for both.
- tools/check-mv3.mjs: header comment "3P Matrix 4.3.8" → "4.4.0" (4.3.8 was never released); identical file in both.
- util/PlatformSuffixes.js header: the typed "3,447 entries" (stale after the refresh — derived-literal check)
  replaced by a reference to data/PlatformSuffixes.json.

---

## 3.5.0 — delivery context: explained route quirks, weak-signal cluster, established-site credit, FP-level strategies; flow corpus

Source worked from: DownloadSentinel 3.4.0 (this session, never zipped). Trigger (user, 2026-10-24): weak signals
count when alone but never add up when several co-occur; asked for better decision rules / grouping, e.g. CDN
deliveries, and different strategies per FP reduction level ("think out of the box"). Approved plan: 1) richer
test collection first, 2) then the rules; ship as 3.5.0 (3.4.0 folded in).

### Step 1 — flow corpus (tests/fixtures/fp-corpus.json "flows", 23 entries)
- Complete journeys (referrer, redirect, domain age mock, extension hidden at start) the single-URL corpus could
  not express. 16 legit vendor flows (expect "quiet") and 7 attack flows (expect "flag"); see each entry's story.
- Found first: the old corpus never had more than ONE weak signal per download (good or bad), so no threshold
  could be tested; the sweep never passed referrer/obfuscation context.
- tools/fp-sweep.mjs scores every flow at HIGH/MEDIUM/LOW/NONE with VirusTotal unknown, through the new shared
  `ScoringEngineV2.scaleHostScoreForUnknownVt()` (moved out of background.js computeCombinedScore — single
  source). Gates (FLOW_GATES): quiet → below Suspicious at HIGH/MEDIUM, never Malicious at LOW (NONE listed
  only: it counts everything in full and doubles it); flag → Suspicious or worse (or R1 always-warn) at
  MEDIUM/LOW/NONE (HIGH listed only).
- Measured on 3.4.0 rules (MEDIUM): VLC HTTP mirror −35 Suspicious, 7-Zip via SourceForge link −35 Suspicious,
  Discord attachment .exe from chat −12 (RiskyHosting −20 HALVED as "solo" because the −12 referrer is below the
  stacking floor), raw-GitHub PowerShell from chat −25, webmail → 2-month domain −12 (identical to the legit
  2-month startup) — 6 gate failures.

### Step 2 — rules
- util/DeliveryPatterns.js (new, pure tables + matchers): VENDOR_DELIVERY (vendor-owned delivery hosts only —
  never user-content hosts, rent-a-CDN domains or keywords; whole-label match), MIRROR_NETWORKS,
  PLATFORM_DOWNLOAD_LINKS (SourceForge `projects/*/files/…/download`), MESSAGE_ORIGINS (webmail/chat; Discord
  only under /channels/).
- protection/DeliveryContext.js (new, pure), run in evaluateHostReputation after all checks, before
  combination:
  - EXPLAIN (HIGH/MEDIUM): ReferrerMismatch, UrlShortener, MessageOrigin, HiddenExtension → vendor host;
    HiddenExtension also → platform download link; ProtocolDowngrade → chain starts at a mirror network.
    Blocked by any WHO signal (identity lists, domain age, TLD), except a platform link may coexist with that
    platform's RiskyHosting entry (which still counts). WHAT signals are never explainable. Explained entries are
    removed from combination (so they cannot make a family "present" for combo rules) and shown at 0 with
    plain-language text (`EXPLAINED_TEXT` + " — normal for <reason>"; original kept as `rawLabel`).
  - CLUSTER: worst entry per family; families whose worst is weaker than STACK_MIN_SIGNAL (−1…−14) are weak;
    when their count ≥ strategy.weakClusterMin (HIGH 4, MEDIUM 3, LOW/NONE 2; −1 on a RiskyHosting host,
    floor 2) one `WeakSignalCluster` entry (family CLUSTER) = their sum, floored at −45, is added. It stacks, and
    also counts as corroboration for the RiskyHosting solo-halving rule.
  - CREDIT (HIGH/MEDIUM): `EstablishedSite` +10 after combination (final = min(score + 10, 10)) when the host's
    registered domain is in TopSitesFilter, HTTPS, a DNS check resolved, and no WHO/WHAT signal. Never with a
    hard rule. (TopSitesFilter is a Bloom filter, ~1% false matches — worst case +10 where nothing else is wrong.)
  - Strategies: `DeliveryContext.CONFIG.FP_STRATEGIES`; the SCORING_CONFIG.FP_UNKNOWN_MULTIPLIERS still apply.
- CombinationScoring: new families DELIVERY (HiddenExtension), ORIGIN (MessageOrigin), CLUSTER
  (WeakSignalCluster); `QUESTION` / `FAMILY_QUESTION` / `questionOf()` (WHAT / WHO / ROUTE); rule C2 also fires
  on DELIVERY (young domain + extension hidden until landing).
- ScoringEngineV2: Obfuscation UNKNOWN_REVEALED now has source "HiddenExtension" (family DELIVERY, a ROUTE
  question; CATEGORY_CHANGED stays "Obfuscation"/FILE_DECEPTION); Check 27 MessageOrigin
  (`MESSAGE_ORIGIN_SCORE` −10, referrer or start of the redirect chain); param `fpLevel`; when every negative
  signal is explained the result is Probably Safe with the explained rows listed.
- Plumbing: `DownloadShape.shapeOf` → `contextOf(record)` now also carries `fpLevel`;
  `BrowserProtection.checkHostReputation(…, downloadShape)` → `downloadContext` (both unreleased 3.4.0 names).
- Warning page: explained rows (`.host-signal-explained`, grey) and the credit (`.host-signal-credit`, green)
  are listed; other 0-score rows stay hidden. `sanitizeLabel()` now keeps U+2010–2015 dashes, U+2018–201F
  quotes, U+2026, U+2192 (the em dash used to be deleted: "was hidden no extension"); bidi controls are still
  stripped. Rendered in headless Chromium with engine-built records for CCleaner (MEDIUM/LOW) and a Discord .exe.

### Result (MEDIUM, VT unknown) — every flow gate passes
| Flow | 3.4.0 | 3.5.0 |
|---|---|---|
| L01/L02 CCleaner / Avast (avcdn.net) | −20 | 0 (explained) |
| L08 VLC via HTTP mirror | −35 Suspicious | −25 |
| L16 7-Zip via SourceForge link | −35 Suspicious | −12 |
| L06 GitHub release asset | −12 | −22 (open-platform cluster of 2) |
| L13 2-month-old indie domain | −12 | −12 |
| A07 Discord attachment .exe from chat | −12 | −32 Suspicious |
| A03 raw GitHub .ps1 from chat | −25 | −44 Suspicious |
| A04 webmail → 2-month domain | −12 | −32 Suspicious |
| A01 Discord extensionless (R1) | −27 (always warns) | −36 Suspicious |
| A05 `cdn-ccleaner-update.top` | −72 | −72 (the word "cdn" gives nothing) |
- HIGH column: attacks A03/A04/A06/A07 stay Inconclusive (×0.5 multiplier and cluster needs 4) — listed, not
  gated; see "open" below.

### Tests
- tests/DeliveryContext.test.js (28): anchors (label boundary, keywords, user-content hosts, table shape),
  explain (modes, WHO block, WHAT never, platform tolerance, mirror downgrade, no mutation), cluster (thresholds,
  same-family = one oddity, strong family excluded, open platform, floor, explained excluded), credit conditions,
  integration (screenshot case Probably Safe at MEDIUM, LOW keeps signals, C2 on DELIVERY, families registered).
- Suite 478 → 506, all pass; complete-check passes (fp-sweep incl. 23 flows × 4 levels, MV3).

### Also in 3.5.0 (added before release) — FP level HIGH multiplier; shared MV3 check; IANA list
User decision 2026-10-24 on the "open" item below, folded into 3.5.0 (nothing published yet).
- `SCORING_CONFIG.FP_UNKNOWN_MULTIPLIERS.HIGH` 0.5 → 1.0. HIGH was lenient twice (DeliveryContext strategy +
  halving). Flows at HIGH, before → after: A03 raw-GitHub .ps1 from chat −22 → −44 Suspicious; A06 invoice.pdf as an
  executable −22 → −45 Suspicious; A02/A05 −36 → −72 Malicious; A01 −13 → −27, A04/A07 −6 → −12 (stay
  Inconclusive: HIGH needs 4 weak oddities by design). Every legit flow stays below Suspicious at HIGH (worst:
  VLC HTTP mirror and Ubuntu over HTTP −25). No test pinned the old value; no UI text promised halving.
- tools/check-mv3.mjs: no longer imports repoPaths.mjs (3P Matrix's flat tools folder has none); default folder
  computed from its own location (DS layout); accepts `--ext` and `--extension`. Byte-identical with
  3P Matrix 4.4.0's copy.
- IANA RDAP bootstrap refreshed from the user-supplied dns.json (publication 2026-10-22T23:00:04Z):
  RdapCctlds 72 → 73 (`sc` added). The tool also regenerated PlatformSuffixes from the CACHED
  tools/lists-raw/public_suffix_list.dat, which is OLDER than the PSL the shipped list was built from (it would
  drop 78 recent entries, e.g. new AWS suffixes, and re-add 18 removed ones) — that output was discarded and the
  shipped PlatformSuffixes kept in 3.5.0 (refreshed in 3.5.1).

### Same-company referrers + rule C7 (user report 2026-10-24, Discord screenshot)
- Report: a Discord attachment (cdn.discordapp.com) clicked in a Discord chat showed "Download referrer
  ("discord.com") is unrelated to the download host" — false: one company. User proposed dropping the referrer
  signal when the host name contains "CDN"; not done that way (keyword is attacker-controlled — fp flow A05
  `cdn-ccleaner-update.top`), replaced by an anchored table, as agreed.
- util/DeliveryPatterns.js `SAME_COMPANY` (Discord, GitHub, Google, Microsoft, Mozilla, Gen Digital, Valve, Dropbox,
  Apple, Meta, Telegram, MEGA) + `companyOf(host)` / `sameCompany(hostA, hostB)`, matched on host labels — not via
  the registered domain, because the PSL lists some as platform suffixes (githubusercontent.com).
  FilenameUrlHeuristics.checkReferrerMismatch returns null for same-company pairs (a relation, not trust:
  user-content domains are listed on purpose; RiskyHosting still scores the host).
- Side effect found by measuring: without the false −12 the Discord .exe fell to −10 (RiskyHosting halved as
  "solo", MessageOrigin −10 below the stacking floor). Fixed with the agreed rule:
  CombinationScoring C7 (−15) "File on a file-sharing platform, link opened from a chat or webmail" = RiskyHosting +
  MessageOrigin, and `SCORING_CONFIG.RISKY_HOSTING_CORROBORATING_SOURCES = ["MessageOrigin"]` (no halving then).
  Result MEDIUM: Discord .exe from chat −35 Suspicious (was −32 via the false referrer).
- Flows (MEDIUM): L06 GitHub release −22 → −5; L07 −29 → −15; A01 −36 → −42; A03 −44 → −59; A07 −32 → −35; at LOW,
  Firefox/Steam/Discord-app now 0 (referrer no longer counted). All gates pass.
- Host label (ScoringEngineV2): always "<n> heuristic risk signal(s) detected — <classification>". Before: the
  combined case showed only the count (no verdict — user report, Discord screenshot), and the single-signal case
  always said "domain probably suspicious"/"probably malicious", even for an Inconclusive −12. Test updated.
- WarningPage.css: `#bpResult, #hostResult { word-break: normal; overflow-wrap: anywhere }` — the longer verdict
  line broke inside a word ("suspicio/us") under `.value`'s break-all (kept for URLs). 3P Matrix already had this.
- A "Together: <rule>" line on the warning page was tried and removed at the user's request (the page already
  says how many signals were found); combination rules stay internal, as before.
- Tests: CCleaner case (no referrer signal any more), Discord case (−35, C7, not halved), C7 needs both, same-company
  matching incl. negatives (notdiscord.com, evil.github.io). Suite 506 → 509.

### Open
- Vendor table is hand-curated: add vendors on request; review yearly (hosts move).
- Decided 2026-10-24: cdn.jsdelivr.net stays on SuspiciousDomains; `vue.global.js` remains an accepted knownGood exception.
- Public Suffix List raw file in tools/lists-raw is stale (see above): refresh before the next PlatformSuffixes rebuild.

---

## 3.4.0 (not released separately — included in 3.5.0) — heuristics R1/R2/R4 (extensionless binaries, risky hosts, name vs type); signal weight review; MV3 compliance check; fp-sweep as a hard gate

Source worked from: DownloadSentinel 3.3.1 extension + tools + docs (uploaded 2026-10-24).
Trigger (user, 2026-10-24): URLhaus #3982093 — `https://cdn.discordapp.com/attachments/…/6962f1be0c?ex=…`,
80.3 MB, `application/octet-stream`, saved as `6962f1be0c`; no warning. Root cause: `classifyDownload()`
returned null (no dangerous/archive extension, MIME not in EXECUTABLE_MIMES), so none of the existing signals
(RiskyHosting −20 for cdn.discordapp.com, MimeCheck) ever ran. Decided with the user: R1 = always warn plus a
score (−15 chosen over the user's first idea −5: −5 sits below the stacking floor and would never combine);
R2 and R4 as proposed; each signal its own value. Same change to be ported to 3P Matrix (shared lib).

### R1 — extensionless generic binary (util/FilenameAnalysis.js, util/DangerousMimes.js)
- New `DangerousMimes.GENERIC_BINARY_MIMES` (single source): application/octet-stream, binary/octet-stream,
  application/x-octet-stream, application/binary, application/x-binary, application/unknown,
  application/force-download, application/x-download, application/download.
- New `FilenameAnalysis.FILE_TYPE` enum { EXECUTABLE, ARCHIVE, UNKNOWN_BINARY } replaces the two literals.
- "Visible extension" = text after the last dot matching `VISIBLE_EXT_PATTERN` (1–10 of [a-z0-9], ≥1 letter);
  `getVisibleExt()`, `findVisibleExt(url, rawUrl, filename)` (filename → final URL → original URL).
  So `tool-v1.2` and `rg-14.1.0-x86_64-linux` count as extensionless; `notes.txt` does not.
- classifyDownload: `isUnknownBinary` = no monitored ext, no visible ext, MIME ∈ GENERIC_BINARY_MIMES →
  fileType UNKNOWN_BINARY. An empty MIME (common at onCreated) never triggers it; the late-entry path does.
- Score: `SCORING_CONFIG.EXTENSIONLESS_BINARY_SCORE = −15` (Check 26, source "ExtensionlessBinary", family
  FILE_DECEPTION). Equal to `CombinationScoring.CONFIG.STACK_MIN_SIGNAL`, so it stacks — a Discord hit is then
  no longer a "solo" RiskyHosting (halved to −10) but −20 combined with −15.
- Switch `APP.EXTENSIONLESS_BINARY_ALWAYS_WARN = true`: skips autoAllow ("Silent when probably safe") for
  these records — a minutes-old upload is usually unknown to VirusTotal, so "probably safe" says little.
- StagingCheck lure words weigh an UNKNOWN_BINARY like an executable (was: 0, as "other").

### R1 completion handling — new util/DownloadShape.js (pure, shared with 3P Matrix)
- `reevaluate(record, confirmedFilename)` → OUTCOME.KEEP | RELEASE | BECAME_KNOWN, using classifyDownload
  with the confirmed name: ordinary name (`clip.mp4`) → RELEASE (background.js `releaseWithoutWarning()`:
  pendingChecks entry deleted, in-flight VT aborted, checkedIds kept for dedup — cleaned by onErased/sweep as
  before); dangerous/archive name (`setup.exe`) → BECAME_KNOWN: record updated, host reputation re-run, and the
  existing obfuscation signal (UNKNOWN_REVEALED −50) reports the hidden extension instead of R1.
- `mustAlwaysWarn(record)`, `shapeOf(source)` → the new trailing `downloadShape` argument of
  `BrowserProtection.checkHostReputation(…, dnsSettings, downloadShape)` ({ visibleExt, isUnknownBinary };
  null keeps old behaviour — every existing caller/test unchanged).

### R2 — risky hosting
- No list change: cdn.discordapp.com / media.discordapp.net / attachments.discord.com stay −20. What changed is
  that R1 lets these downloads reach the check at all, and corroboration stops the halving (see R1 score).

### R4 — visible extension vs MIME type
- MimeCheck now receives `ext || visibleExt`: `invoice.pdf` served as application/x-msdownload scores the
  mismatch (−45 after the weight review below) (before: ext null → "MIME type unavailable", 0).
- New derived `DangerousMimes.ARCHIVE_MIMES`; classifyDownload `isMimeArchive`: archive MIME + visible ext the
  MIME table does not list for it → monitored as ARCHIVE (e.g. `invoice.pdf` as application/zip).
- New `ZIP_CONTAINER_EXTS` (docx/docm/xlsx/xlsm/pptx/pptm, odt/ods/odp/odg, epub, whl/egg/nupkg/vsix/aar,
  jar/apk/xpi, kmz/3mf/xps/oxps) added to the three zip MIME entries — found by fp-sweep: the knownGood PyPI
  wheel (`requests-…-none-any.whl` as application/zip) became monitored without it. Back to "Not monitored".
- MimeCheck's neutral set is now GENERIC_BINARY_MIMES + text/plain (was three literals): an `.exe` served as
  application/force-download (or x-download, …) no longer gets a false −60.

### Signal weight review (user request 2026-10-24, with a CCleaner warning page as example)
- Example: `https://bits.avcdn.net/productfamily_CCLEANER7/…` (no extension, ccsetup.exe), referrer
  www.ccleaner.com → −50 "Probably Suspicious". Replayed: ONE signal decided it (Obfuscation UNKNOWN_REVEALED
  −50); ReferrerMismatch −12 is weaker than CombinationScoring.CONFIG.STACK_MIN_SIGNAL (−15), so it never
  stacks. Several weights date from before combination scoring (v2.9.0, "worst single signal wins").
- Method: scratch replay of fp-corpus (56 knownGood, 24 stagingSynthetic) plus hand-made attack cases, each
  also as "extension hidden at start", "plain HTTP" and "VT unknown" at FP level Low/None.
- Changed (SCORING_CONFIG; each stays ≤ STACK_MIN_SIGNAL, so it still stacks):
  | Signal | Was | Now | Evidence |
  |---|---|---|---|
  | OBFUSCATION_UNKNOWN_SCORE | −50 | −20 | hidden variant: 54/54 knownGood ≥ Suspicious (11 Malicious) → 0 Malicious, 11 Suspicious (10 install scripts + 7-Zip on SourceForge) |
  | HTTP_PENALTY | −40 | −25 | HTTP variant: 54/54 ≥ Suspicious → 12, none Malicious |
  | MIME_MISMATCH_SCORE (new; was a −60 literal in MimeCheck.js) | −60 | −45 | see MIME table gaps below |
  | LOOKALIKE_SITE_SCORE | −45 | −35 | ~1% Bloom-filter false matches; curated brand stays −65 |
  - SIZE_EXCEEDS_VT_SCORE (−20) also moved from a MimeCheck.js literal into SCORING_CONFIG, value unchanged.
- Attack cases after the change: hidden .exe on a DuckDNS host −91 → −76 Malicious; invoice.pdf as an
  executable −78 → −63 Malicious; hidden .exe on a 5-day-old domain −75 → −50 Suspicious; bare IP + HTTP + .exe
  −65 → −52 Suspicious; invoice.pdf.exe −50 unchanged. CCleaner: −20 Inconclusive (Low −30, None −40).
- Kept: double extension, RLO/padded, URL credentials, HTTPS→HTTP downgrade, IP host, script, launcher, staging
  formats, list scores, RDAP ages, combination rules and floor, FP-level multipliers (user's own choice).
- MIME table (util/DangerousMimes.js): 9 official/common types gave a FALSE −60 mismatch — added
  application/vnd.debian.binary-package (deb — Docker's own .deb was frozen as "Suspicious" in the fp
  baseline), application/x-redhat-package-manager (rpm), application/vnd.android.package-archive (apk),
  application/x-xpinstall (xpi), application/x-chrome-extension (crx), application/x-shellscript (sh, bash),
  application/x-cd-image (iso), application/vnd.appimage, application/x-ole-storage (msi/msp + doc/xls/ppt/msg),
  bat under application/x-msdos-program. New `AMBIGUOUS_CONTAINER_MIMES` (x-ole-storage) is excluded from the
  derived EXECUTABLE_MIMES — otherwise every legacy .doc served as an OLE container would open a warning page.
  application/x-shellscript now counts as an executable MIME (like application/x-sh).
- Removed `APP.OBFUSCATION_UNKNOWN_SCORE` (−40) / `APP.OBFUSCATION_CATEGORY_CHANGE_SCORE` (−20): unused copies
  that disagreed with SCORING_CONFIG.
- Tests that pinned old numbers now derive them from the constants (MimeCheck.test.js; ScoringEngineV2.test.js
  "SKIPPED slot" test — intent "only the HTTP signal counts, no hard rule" kept).

### Tools — false-positive sweep is now a hard gate (#17 in complete-check)
- tools/fp-sweep.mjs was never run by complete-check (its header called it a hard gate — C38).
- New gates: (1) absolute — an as-is knownGood entry at Probably Suspicious or worse FAILS unless it carries
  `acceptedRisk` + `acceptedReason`; (2) variants — every knownGood entry is also scored with the extension
  hidden at start (`FilenameAnalysis.getObfuscationSignal(null, ext)`) and over plain HTTP; Malicious FAILS,
  Suspicious is listed for review. Verified: with the pre-review weights the sweep fails (11 variant scores at
  Malicious); with the new weights it passes. (3) R1/R4 inputs passed like checkHostReputation().
- `cdn.jsdelivr.net/npm/vue@3.5.12/dist/vue.global.js` (ScriptFormat −25 + DomainList −24 = −37) marked
  `acceptedRisk` — owner decided (2026-10-24): keep warning, jsdelivr stays on SuspiciousDomains.
- Baseline refreshed (`--update`) after the review.

### Tools — MV3 compliance check (tools/check-mv3.mjs, new; hard gate #16 in complete-check)
- Manifest: M1 manifest_version 3; M2 service-worker-only background; M3 no browser_action/page_action;
  M4 no webRequestBlocking, host patterns only in host_permissions; M5 CSP object form, extension_pages script
  sources limited to 'self'/'none'/'wasm-unsafe-eval'/localhost; M6 web_accessible_resources object form;
  M7 DNR rule_resources fields + file exists + JSON array.
- Code (espree AST, not regex): C1 eval / Function / string timers; C2 remote code (import, import(),
  importScripts, re-exports, HTML `<script src>` to http(s):// or //); C3 MV2-only APIs (extension.getURL,
  tabs.executeScript, browserAction, …); C4 DOM-only globals (window, document, localStorage, …) in the service
  worker and every module it statically imports (eslint-scope free references; `typeof x` allowed);
  C5 a file that cannot be parsed is a finding, never silently skipped.
- Same file for 3P Matrix: `--ext <folder>`; `--json`; exit 0/1/2 (2 = could not run → FAIL in complete-check).
- `npm run mv3`; devDependencies `espree ^9.6.1`, `eslint-scope ^7.2.2` (already installed via ESLint 8, now
  declared); knip entry added for the tool so they don't show as unused.
- tests/CheckMv3.test.js builds a broken MV2-style extension in a temp folder (released in afterEach) and
  asserts every rule id fires; a clean MV3 one passes. DS 3.4.0 and 3P Matrix 4.3.7 are both compliant.

### Also
- package-lock.json was still at 3.3.0 in the 3.3.1 zip (complete-check FAIL on the baseline) — now 3.4.0.
- Tests: tests/DownloadShapeHeuristics.test.js (29 cases incl. the Discord URL end-to-end with the network
  stubbed), tests/CheckMv3.test.js (7). Suite 442 → 478, all pass; fp-sweep: no knownGood regressions.

### Known limitations / not done
- `IANA RDAP bootstrap registry` not refreshed: minor bump policy (`updateOn: minor`), but this environment
  cannot reach data.iana.org. Run `node tools/update-domain-age-lists.mjs --fetch` before publishing.
- R1 is bypassed by any made-up extension (`payload.dat`); only the magic-bytes check (R3, deliberately out of
  scope) would catch that.
- A GitHub Linux release binary (`tool-linux-amd64`) now always warns — by decision (warn, never block).
- Residual review items from the sweep (Suspicious, not failing): install scripts from an extensionless link or
  over HTTP (script −25 stacks), 7-Zip from SourceForge with a hidden extension (RiskyHosting −25 stacks).

---

## 3.3.1 — DNS4EU + CleanBrowsing as DNS checks 4 and 5; France defaults; optional host permissions

Source worked from: DownloadSentinel 3.3.0 extension + tools (uploaded 2026-10-24).
Trigger (user, 2026-10-24): Quad9 refuses the Paris court's blocking order (beIN/Canal+, WTA streams; beIN seeks
up to €10,000 per domain per day, ~€580k/day for 58 domains) and says it may leave France — not left as of
2026-10-24. Asked: a fourth malware-blocking DNS, and France default = Control D first, Cloudflare 1.1.1.2 second.

### Providers (util/AppConstants.js — single source of truth)
- New enum `DNS_BLOCK_STYLE` (declared above `APP`, exposed as `APP.DNS_BLOCK_STYLE`): NXDOMAIN_NO_AUTHORITY,
  ZERO_IP, BLOCKPAGE_IP, RPZ_SOA. Providers and DnsThreatProtection compare against it, no raw strings.
- `dns4eu` — DNS4EU Protective (EU-funded, run by Whalebone), `https://protective.joindns4.eu/dns-query`,
  BLOCKPAGE_IP, `blockPageIps: ["51.15.69.11"]`. Verified live 2026-10-24 against 86.54.11.1 (same profile, via
  digwebinterface.com): malware.wicar.org → A 51.15.69.11; thisdoesnotexist-12345.com → NXDOMAIN with the "com."
  registry SOA; malware.testcategory.com → real A records. DNS4EU applies court orders on every profile.
- `cleanbrowsing` — CleanBrowsing Security Filter, `https://doh.cleanbrowsing.org/doh/security-filter/`,
  RPZ_SOA, `rpzSoaMnameSuffix: "rpz.noc.org"`. Verified live 2026-10-24 against 185.228.168.9:
  malware.wicar.org → no answer + SOA `malware.wicar.org. SOA cleanbrowsing.rpz.noc.org. accesspolicy.rpz.noc.org.`;
  thisdoesnotexist-12345.com → `com. SOA a.gtld-servers.net.`; example.com → real A records. A block and a
  non-existent name are both answerless; only the Authority SOA's MNAME tells them apart.
- Considered and not taken: Mullvad base / AdGuard (also block ads → harmless ad domains would score as malware);
  OpenDNS (left France in 2024); dns0.eu (closed 2025).

### Detection (protection/DnsThreatProtection.js)
- parseDnsResponse now also reads the Authority section and returns `authoritySoas: [{ owner, mname }]`
  (lower-case, no trailing dot; SOA = type 6, `DNS.TYPE_SOA`). Guard: the section is supplementary — a
  truncated/malformed Authority section stops collection (collectAuthoritySoas in try/catch) without discarding
  the answers/rcode already parsed; an unreadable section can never yield BLOCKED.
- RPZ_SOA: BLOCKED when there is no usable answer and an SOA MNAME equals or ends on a label boundary with
  `rpzSoaMnameSuffix` (so "evilrpz.noc.org" does not match); else NXDOMAIN → UNKNOWN/NXDOMAIN. Missing/empty
  suffix → never BLOCKED (fail open).
- BLOCKPAGE_IP: BLOCKED when an answer is in `blockPageIps` or is 0.0.0.0 / ::. Other styles ignore both lists.
- If a provider moves its block page / policy zone, blocks fall through as ALLOWED (neutral), never a false
  "Confirmed malicious" — update the constant.

### Region defaults (util/DnsDefaults.js, new)
- `APP.DNS_REGION_DEFAULTS`: rule FR → first `controld`, second `cloudflare`; time zones Europe/Paris + overseas
  (Cayenne, Guadeloupe, Martinique, Marigot, St_Barthelemy, Miquelon, Reunion, Mayotte, Kerguelen, Tahiti,
  Marquesas, Gambier, Noumea, Wallis). Europe/Monaco deliberately excluded.
- DnsDefaults.get() detects the IANA zone offline (Intl; no network, no permission), caches a frozen
  { first, second, region }; reset() clears the cache; resolveForTimeZone(tz) is pure. Every failure (Intl
  throwing, unknown zone, a rule naming a removed provider or an optional-permission provider) → the global
  APP.DEFAULT_DNS_FIRST / _SECOND (quad9 / controld, unchanged).
- All former direct reads of APP.DEFAULT_DNS_* now go through DnsDefaults: Settings.js defaultSettings,
  background.js buildSettingsSnapshot (validDnsProviderId fallback), BrowserProtection.checkHostReputation,
  OptionsPage.js (load + Save All guard).
- Known limitation: Settings.set persists the full merged object, so a user who ever saved any setting has the
  old defaults stored and keeps Quad9 — no migration (offered to the user, not requested).

### Optional host permissions (util/DnsPermissions.js, new)
- Providers with `optionalPermission: true` (dns4eu, cleanbrowsing) are in manifest `optional_host_permissions`,
  not `host_permissions`, so the 3.3.0 → 3.3.1 update triggers no Chrome re-approval (a new required host would
  disable the extension until approved).
- Lifecycle: OptionsPage requests the origin synchronously in the dropdown's change handler (user gesture kept;
  declined → dropdown reverts to its previous value, message in #dnsStatus); after each save,
  releaseUnused([first, second]) removes grants no slot uses. On Options load, a selected provider without its
  grant shows a notice.
- DnsThreatProtection.check: optional provider without grant → no fetch, UNKNOWN with new reason code
  `PERMISSION_MISSING`; WarningPage DNS_UNKNOWN_TEXT: "not checked — permission not granted (allow it in Options)".
- Every DnsPermissions function guards a missing chrome.permissions and never throws (failure = not granted).

### UI
- OptionsPage.html DNS section shortened (user: text too long): heading "Threat-intel DNS — two of five"; one-line
  intro; "Pick two you do not already use as your own DNS — that one already blocks bad sites."; NextDNS
  "Block Bypass Methods" hint reduced to one sentence + "check unavailable, never as safe". No France note in
  the UI (the default simply applies). Dropdown entries come from APP.DNS_PROVIDERS as before.

### Manifest / versions
- manifest.json 3.3.0 → 3.3.1; optional_host_permissions: protective.joindns4.eu, doh.cleanbrowsing.org.
- TOOLS package.json 3.3.0 → 3.3.1.

### Tests (TOOLS)
- 410 → 442, all passing (also with TZ=Europe/Paris). New: tests/DnsDefaults.test.js (regions, fallbacks, cache,
  manifest ↔ provider consistency, no optional provider as a region default), tests/DnsPermissions.test.js.
  DnsThreatProtection.test.js: dns4eu and cleanbrowsing suites from the live-observed records, truncated
  Authority section, look-alike MNAME, permission guard. Fixture builder takes real Authority SOA records.
- helpers/chromeMock.js: chrome.permissions mock (contains/request/remove) with init/clear/release
  + setGrantedOrigins().
- eslint clean; check-magic-numbers unchanged vs 3.3.0 (38 lines, all pre-existing); no circular imports;
  knip: only the pre-existing AGE_NA.

### Not verified here
- The Chrome permission prompt itself (no real Chrome in the build environment).
- DoH endpoints directly (build environment cannot reach DNS servers); verification used the same profiles'
  plain-DNS addresses. Check once in the browser: a download from malware.wicar.org.

### For 3P Matrix
- When 3P Matrix moves to DS 3.3.1: SPEC_levels_and_protections.md lists three DNS providers (lines ~134–136) —
  add DNS4EU and CleanBrowsing with their block styles; its own core/online-checks.js DNS code (two
  implementations kept, 4.3.4 item 21) needs the same RPZ_SOA / BLOCKPAGE_IP handling and the France default
  if it should match.
