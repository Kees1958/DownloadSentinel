"use strict";

/**
 * UrlShorteners.default.js — GENERATED FILE. Do not hand-edit; run
 * `node tools/gen-data-defaults.mjs` to regenerate from the single source
 * of truth, EXTENSION/data/UrlShorteners.json.
 *
 * This is the bundled/offline default: compiled into the reviewed CWS
 * package so UrlShorteners always has a safe starting value even before
 * util/FilterDataLoader.js ever attempts a remote fetch, and whenever that
 * fetch fails, is unavailable, or returns malformed data.
 *
 * Generated: 2026-10-09T10:51:23.235Z
 */
export const UrlShortenersDefault = [
    "bit.ly",
    "tinyurl.com",
    "t.co",
    "goo.gl",
    "ow.ly",
    "is.gd",
    "buff.ly",
    "rebrand.ly",
    "cutt.ly",
    "shorturl.at",
    "tiny.cc",
    "rb.gy",
    "bl.ink",
    "lnkd.in",
    "shorte.st",
    "v.gd",
    "qr.ae",
    "soo.gd",
    "s.id",
    "clck.ru"
];
