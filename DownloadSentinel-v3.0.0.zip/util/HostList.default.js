"use strict";

/**
 * HostList.default.js — GENERATED FILE. Do not hand-edit; run
 * `node tools/gen-data-defaults.mjs` to regenerate from the single source
 * of truth, EXTENSION/data/HostList.json.
 *
 * This is the bundled/offline default: compiled into the reviewed CWS
 * package so HostList always has a safe starting value even before
 * util/FilterDataLoader.js ever attempts a remote fetch, and whenever that
 * fetch fails, is unavailable, or returns malformed data.
 *
 * Generated: 2026-10-09T10:51:23.227Z
 */
export const HostListDefault = {
    "000.pe": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "0000000000000000000000.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "000a.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "000free.us": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "000webapp.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "000webhost.fr": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "000webhost.info": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "000webhostapp.com": {
        "score": 65,
        "source": "HaGeZi-Hoster+Kees-Suspicious"
    },
    "000webhotapp.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "000worldwide.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "00author.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "00go.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "00it.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "00m.in": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "012webpages.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "028426.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "07080900.xyz": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "078.me": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "0bs.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "0fees.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "0hna.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "0pi.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "0rg.us": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "0x.no": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "1.vg": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "10001mb.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "100mountain.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "10dv.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "10gbfreehost.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "10h.us": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "10x.es": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "110.vg": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "114.at": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "115.at": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "120v.ac": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "123freehost.co.uk": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "128-199-7-137.cprapid.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "12n.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "131.at": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "1337.cx": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "135.it": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "13e.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "16-b.it": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "178.at": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "17p.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "193.at": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "1a.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "1asphost.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "1cooldns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "1dumb.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "1freewebspace.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "1hwy.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "1ll.us": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "1pt.co": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "1shop.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "1sweethost.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "1tt.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "1w3.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "1x.biz": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "1x.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "1x.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "1x7.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "2.je": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "204.at": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "22web.org": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "24-7.ro": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "24.co.at": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "24.eu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "24.gg": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "24.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "24.je": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "24.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "24.mu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "24.nl": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "24.org.es": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "24.tl": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "258.at": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "25u.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "270.at": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "2all.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "2bd.net": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "2fh.co": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "2fine.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "2h.ae": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "2itb.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "2kool4u.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "2mydns.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "2no.co": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "2p.fm": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "2waky.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "3-89-181-9.cprapid.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "3-a.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "310.at": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "32-b.it": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "3322.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "350.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "351.at": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "360digit.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "36f.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "3blogger.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "3dxtras.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "3n.cc": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "3trust.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "3utilities.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "3ya.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "4.je": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "404.mn": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "4040.idv.tw": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "42t.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "433.at": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "4cloud.click": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "4dq.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "4everland.app": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "4khdcamera.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "4kp.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "4mydomain.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "4pu.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "4twenty.us": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "4u2.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "4x.si": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "530.at": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "5mp.eu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "5on.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "5oo.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "5v.pl": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "64-b.it": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "66ghz.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "688.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "741.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "766.at": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "77uam.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "8.je": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "81x.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "85d.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "88zkt.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "89q.sk": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "8c8.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "9.je": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "989.at": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "9down.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "9gb.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "9k.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "a-loch.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "a.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "a3n.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "aa.am": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "aa6.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "aa8.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "aa9.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "aba.ae": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "abatek.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "abbremsen.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "abfertigen.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "abgeblasen.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "abgebogen.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "abgefahrenes.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "abgefeilt.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "abhacken.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "abhalten.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "abhauen.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "abklappern.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "abmetalmecanica.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "about.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "abrdns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "absichern.eu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "absorbiert.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "abstellen.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "abuser.eu": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "abwechslungsreiches.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ac6.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "access.ly": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "accesscam.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "acmetoy.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "adagio.tw": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "adlinkfly.mightyscripts.xyz": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "admarketlocation.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "aeza.network": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "afraid.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ag.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ag0rcgwjv5.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "agropeople.ru": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "aintno.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "airlinemeals.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "airset.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "al6.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "alavps.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "albertn.ru": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "all.co.uk": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "all.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "allemal.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "allez.la": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "allisons.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "allowed.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "almostmy.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "als-geschenk.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "am-geilsten.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "am-strand.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "amarillozoo.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "americanunfinished.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "amz.run": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "an-erster-stelle.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "anal-slavery.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "anastasion.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "and-friends.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "and-you.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "aneisa.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "anfliegen.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "angelcamddns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "annaffiare.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "anondns.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "anschauen.in": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "anschiessen.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "antongorbunov.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "any64.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "anyhub.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "anyitsolution.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "api64.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "appbitly.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "apptechservices.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ar.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "arcadepages.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "arenaceballos.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "arquivirtual.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "arrangiert.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "as14627.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "as19557.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "as29997.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "asenov.ru": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "asia.cm": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "asia.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "asiamariage.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "asianfreshproduce.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ask2ask.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "astrabus.ru": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "asuscomm.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "at-band-camp.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "at.cr": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "at.st": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "atamanco.eu": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "ath.cx": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "atholdinginc.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "atlantatruckdrivingschool.us": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "atsnx.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "atw.hu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "atwebpages.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "au.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "aufbauend.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "auraria.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ausposaunen.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "australia.ai": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "authorizeddns.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "authorizeddns.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "authorizeddns.us": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "auto.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "autoipset.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "avandns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "aw3.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "awi.za.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "awiki.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "ax.lt": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "axifile.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "az.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "azl.one": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "azurestaticapps.net": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "azurewebsites.net": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "b.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "b0tnet.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "b2b.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "b33r.us": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "bad.mn": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "baden.ru": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "bagus.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "baikabibai.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "bakli.ru": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "bakoweb.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ballern.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "barbaforte.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "barrel-of-knowledge.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "barrell-of-knowledge.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "baselinux.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "bayipazar.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "bb.vg": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "be.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "beerprojects.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "beget.tech": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "begins.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "benjamin.it": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "beplaced.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "berlin.tl": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "bestsharing.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "betrunken.org": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "better-than.tv": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "bg.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "bgdsupport.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "bget.ru": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "bhms.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "bigbluezoo.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "bigheadhosting.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "bigmoney.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "bilder.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "billblett.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "bine.me": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "birdriver.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "bitly.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "bityl.co": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "bitzli.ch": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "biz.ps": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "biz.st": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "biz.tm": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "blacknapkins.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "blatnet.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blink.hirebiz.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blinklab.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "blizzie.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "blltly.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blog-online.eu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blog.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogcheese.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogdns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "blogdns.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "blogdns.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "bloggt.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogmonster.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogsite.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "blogspot.ae": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.al": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.am": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.ba": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.be": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.bg": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.ca": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.ch": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.cl": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.co.at": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.co.id": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.co.il": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.co.ke": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.co.nz": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.co.uk": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.co.za": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.com.ar": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.com.au": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.com.br": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.com.by": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.com.co": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.com.cy": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.com.ee": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.com.eg": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.com.es": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.com.mt": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.com.ng": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.com.tr": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.com.uy": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.cz": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.dk": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.fi": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.fr": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.gr": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.hk": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.hr": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.hu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.ie": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.in": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.is": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.it": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.jp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.kr": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.li": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.lt": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.lu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.md": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.mk": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.mx": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.my": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.nl": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.no": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.org": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.pe": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.pl": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.pt": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.qa": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.ro": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.rs": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.ru": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.se": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.sg": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.si": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.sk": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.sn": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.tw": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogspot.ug": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "blogsyte.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "bloodforthebloodgod.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "bloom.us": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "bmvl.ru": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "bo.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "boblove.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "boldlygoingnowhere.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "bot.nu": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "bounceme.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "boxathome.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "boxmode.io": {
        "score": 65,
        "source": "HaGeZi-Hoster+Kees-Suspicious"
    },
    "br.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "brajkovic.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "brasilia.me": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "brawlcustommusic.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "briansagar.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "broke-it.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "brweb.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "bugs3.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "builderall.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "builtfree.org": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "bulkurlshortener.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "bumbleshrimp.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "burlingtondrywall.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "business-minagne.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "buyshouses.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "bx5.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "byethost11.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "byethost13.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "byethost14.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "byethost18.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "byethost4.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "byethost5.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "byethost6.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "byethost7.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "byethost9.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "byte4byte.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "byto.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "bz.tc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "c.pl": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ca.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "cable-modem.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "cableonline.com.mx": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "camdvr.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "casacam.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "cashit.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "cbkgardens.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "cbopelousas.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "cbu.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ccwu.cc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "cebol.me": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "cechire.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "celebsplay.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "celltrak.mobi": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "center.tl": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "centserver.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "cf.gs": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ch.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ch.kg": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ch.st": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ch2.eu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "chamberecommerce.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "changeip.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "changeip.co": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "changeip.co.uk": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "changeip.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "changeip.me": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "changeip.name": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "changeip.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "changeip.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "changeip.us": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "charihoproducts.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "charter.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "chat.dj": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "chat3.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "chavo.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "checkor.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "chickenkiller.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "chrismac.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ciscofreak.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "city.tl": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "citybios.sa.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "cixx6.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ciy.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "cjtooling.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "cl.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "cl4n.org": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "clan-24.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "clan-base.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "clan.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "clan.mn": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "clandomain.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "clandomain.org": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "clawmap.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "cleansite.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "cleansite.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "cleansite.us": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "cli.re": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "clickip.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "clienturl.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "clipser.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "cloud-ip.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "cloudns.asia": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "cloudns.be": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "cloudns.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "cloudns.cc": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "cloudns.ch": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "cloudns.cl": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "cloudns.cx": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "cloudns.in": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "cloudns.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "cloudns.nz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "cloudns.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "cloudns.ph": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "cloudns.pro": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "cloudwatch.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "cloudwaysapps.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "cloudxns.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "club-area.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "club.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "clumsy.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "cn.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "cnstefancelmare.ro": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "co.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "coalnet.ru": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "codns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "colegiotorrevilano.es": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "collegefan.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "com-portal.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "com0.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "com24.at": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "come.ac": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "community.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "community24.eu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "company.site": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "compress.to": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "compuinter.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "computersforpeace.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "compy.ca": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "comxa.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "con-ip.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "conditsis.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "conohawing.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "contepsa.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "cool.hn": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "cool.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "coolfreepages.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "coolpage.biz": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "coplien.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "corbina.ru": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "coreytech.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "corolain.ru": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "couchpotatofries.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "counterlight.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "cpanel.site": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "cpct.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "cprapid.com": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "cpsnet.cz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "crabdance.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "crackedsidewalks.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "crafting.xyz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "craftum.io": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "crazedns.ru": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "created.app": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "creatorlink.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "crypto-market-world.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "cryptonight.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "cs-clan.org": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "csproject.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "cstu.io": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ct.ws": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ctempurl.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ctx.cl": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "cuesinc.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "cupddns.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "custom-gaming.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "cut.vin": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "cutedrive.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "cw03.ru": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "cwqso.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "cyberbree.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "cyberfight.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "cybertv.tv": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "cz.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "d-n-s.name": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "d-n-s.org.uk": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "d.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "d2g.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "d3l.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "da.cx": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "daftpage.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "dagz.ru": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "damnserver.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dardarkom.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "dark-byte.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "darksair.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "davidsagar.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ddl2.pl": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ddns-ip.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ddns.cam": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ddns.com.br": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ddns.com.co": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ddns.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "ddns.me.uk": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ddns.mobi": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "ddns.ms": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ddns.name": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ddns.us": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ddns5.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ddnsapp.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ddnsfree.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "ddnsgeek.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "ddnsguru.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "ddnsking.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ddnslive.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ddnss.ch": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ddnss.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ddnss.eu": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ddnss.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ddnssec.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "de-2.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "de-a.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "de-info.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "de.cm": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "de.gd": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "de.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "de.ht": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "de.im": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "de.ki": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "de.mg": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "de.pl": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "dearabba.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dedyn.io": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "demosoftonline.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "demoteam.ch": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "design.tl": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "dh3.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dhcp.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dhis.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dhs.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "digikabel.hu": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "digitalgroupe.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "digitalzones.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "dik.si": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "dimsolo.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "diowebhost.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "dip.jp": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "diskstation.eu": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "diskstation.me": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "diskstation.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ditchyourip.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dive2.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "divx.se": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "diyplans.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dlinkddns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dmtr.ru": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dn3.co": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dnet.hu": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dnmcoffman.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dns-auth.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dns-auth.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dns-cloud.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dns-dns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dns-dynamic.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dns-report.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dns-stuff.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dns.army": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dns.navy": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dns04.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dns05.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dns1.us": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dns2.us": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dns2go.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dns64.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dnsabr.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dnsalias.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dnsalias.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dnsalias.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dnsdojo.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dnsdojo.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dnsdojo.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dnsdyn.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dnsdynamic.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dnset.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dnsexit.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dnsfailover.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dnsfor.me": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dnsget.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dnshome.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dnshome.icu": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dnsiskinky.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dnsking.ch": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dnslive.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dnsmax.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dnsname.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dnsnew.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dnsomatic.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dnspod.cn": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dnsrd.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dnsup.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dnyp.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dob.jp": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "does-it.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "doesntexist.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "doesntexist.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "domain.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "donhoo.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "donkeyhot.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dontexist.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dontexist.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dontexist.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "doomdns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "doomdns.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dot.tk": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "dougtreadwell.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "douploads.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "downfall.shop": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "download.ac": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "download.sh": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "downloaden24.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "dox4.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "doyleandprendergast.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dp76.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dpcube.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dray-dns.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "drayddns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dreht-auf.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "dropfiles.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "drunkensailor.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dscloud.me": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dscloud.mobi": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dsmtp.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dsmynas.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dsmynas.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dsmynas.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dtdns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dtdns.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dtdns.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dubya.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dubya.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dubya.us": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "duia.eu": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "duia.ro": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "duia.us": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "duiadns.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dumb1.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dvd.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "dvr-ddns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dvrcam.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dvrdns.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dweb.link": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "dyn-access.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dyn-access.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dyn-access.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dyn-access.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dyn-access.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dyn-access.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dyn-ip24.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dyn-o-saur.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dyn-vpn.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dyn.addr.tools": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dyn.ch": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dyn.columbia.edu": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dyn.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dyn.mk": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dynalias.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dynalias.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dynalias.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dynamai.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dynamic-dns.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dynamic-dns.us": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dynamic-m.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dynamic-site.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dynamic.domains": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dynamicdns.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dynamicdns.co": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dynamicdns.co.uk": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dynamicdns.com.co": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dynamicdns.me.uk": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dynamicdns.org.uk": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dynamisches-dns.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dynamix.run": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dynathome.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dyndns-at-home.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dyndns-at-work.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dyndns-blog.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dyndns-free.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dyndns-home.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dyndns-ip.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dyndns-ip.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dyndns-mail.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dyndns-office.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dyndns-pics.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dyndns-remote.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dyndns-server.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dyndns-web.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dyndns-wiki.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dyndns-work.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dyndns.berlin": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dyndns.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dyndns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dyndns.dk": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dyndns.icu": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dyndns.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dyndns.it": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dyndns.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dyndns.pro": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dyndns.tv": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dyndns.ws": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dyndns.za.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dyndns64.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dyndnss.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dyndnssec.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dyndnsservices.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dynect.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dynet.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dynip.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dynip.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dynipv6.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dynme.ovh": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dynnamn.ru": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dynns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dyns.be": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dyns.cx": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dyns.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dynserv.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dynssl.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dynu.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dynu.systems": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dynuddns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dynuddns.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "dynup.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dynv4.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dynv6.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dynv6.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dynvpn.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "dyyndns.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "e-docssig.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "e-m-a-i-l.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "e-romagnoli.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "e.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "easydns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "easydns.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "easydns.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "easydns.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "eating-organic.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "eatuo.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "eb2a.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ec.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ecardalert.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "echoparklake.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ecomplanet.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "edgeone.app": {
        "score": 65,
        "source": "HaGeZi-Hoster+Kees-Suspicious"
    },
    "edgeone.dev": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "edns.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "edoctransfer.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "edu.eu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "educatorpage.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "educatorpages.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "efacturas.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "effers.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "eg.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ehaitao.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "eiresol.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "elchemi.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "electronicfiles.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "elitter.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "embeddedonline.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "emochila.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "empresastaylor.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "emyspot.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "encurtador.com.br": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "endlessmovie.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "endofinternet.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "endofinternet.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "endoftheinternet.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "enemykitchen.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "enemyterritory.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "english.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "entekpartners.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "enterprisedeliveries.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "enterprisemx.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "entrydns.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "entrydns.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "envy.nu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "eo3.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "eolicatalinay.cl": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "epac.to": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "epicgamer.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "epicmilk.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "epizy.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "eptechguys.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "erlegen.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "es.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "esel.in": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "eshop-ya.life": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "esmtp.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "essentialventure.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "essexregional.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "est-a-la-maison.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "est-a-la-masion.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "est-le-patron.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "est-mon-blogueur.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "eth64.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "etitrans.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "eu.cm": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "eu.cr": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "eu.gg": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "eu.gl": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "eu.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "eu.nu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "eu3.biz": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "eu5.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "eur.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "euro.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "europa.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "eurotank.ro": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ev.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "eva.hk": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "events-games.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "everton.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "evils.in": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ewp.live": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "exactpages.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "expired-dns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ez-dns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ez-ip.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ezua.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "ezxdev.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ezyro.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "f-parts.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "f11.us": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "f3322.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "f3322.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "facebookid.live": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "faceboook-app.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "facepl.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "fairuse.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "falcongreen.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "familyds.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "familyds.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "familyds.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "familylobby.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "fanclub.rocks": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "fantasyleague.cc": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "faqserv.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "farted.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "fartit.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "fast-page.org": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "fastshare.org": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "fat-fly.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "fatdiary.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "fb-business.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "fdns.uk": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "fearpenguins.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ferreracademy.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "feste-ip.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "fileave.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "filebin.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "filecache.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "filedropper.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "filelu.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "files.bz": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "fileurls.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "filme.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "fin-tech.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "financecryptoworld.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "financial-offer.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "fintech-llc.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "firm.nu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "fivepals.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "flashbuilder.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "flashhub.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "flat4free.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "flazio.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "flazio.site": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "flazzard.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "fleek.co": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "fleek.cool": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "flf.li": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "fli.so": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "flick2.me": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "flick2.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "flirten.info": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "flnet.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "flow.page": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "flowergardendaycare.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "flu.cc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "flyjasper.ca": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "flyme2.me": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "flyme2.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "flywheelsites.com": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "for-better.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "for-ladys.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "for-more.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "for-our.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "for-some.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "for-the.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "forgot.his.name": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "formbuddy.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "foroemprende.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "forss.to": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "fortiddns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "forum.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "forum7.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "forumil.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "forumz.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "fotos.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "fr.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "fragmentary.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "framer.app": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "freakshare.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "free-ddns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "free.bizhat.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "free.cr": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "free.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "free.nf": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "freeasphost.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "freeblog.biz": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "freecities.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "freeddns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "freeddns.me": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "freeddns.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "freeddns.tokyo": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "freeddns.uk": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "freeddns.us": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "freedns.tech": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "freedynamicdns.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "freedynamicdns.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "freehomepage.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "freehost.ag": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "freehoster.ch": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "freehosting.cc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "freehostingcloud.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "freehostingking.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "freehostyou.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "freemyip.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "freesa.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "freesite.org": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "freetcp.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "freeweb.me": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "freewebhosting4u.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "freewebhostmost.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "freewebpages.org": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "freewebportal.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "freewww.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "freewww.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "freightinternationalservices.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "freshdns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "friendcircles.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "from-ak.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-al.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-ar.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-az.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-ca.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-co.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-ct.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-dc.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-de.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-fl.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-ga.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-hi.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-ia.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-id.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-il.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-in.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-ks.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-ky.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-la.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-ma.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-md.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-me.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-mi.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-mn.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-mo.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-ms.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-mt.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-nc.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-nd.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-ne.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-nh.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-nj.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-nm.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-nv.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-ny.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-oh.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-ok.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-or.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-pa.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-pr.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-ri.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-sc.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-sd.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-tn.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-tx.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-ut.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-va.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-vt.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-wa.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-wi.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-wv.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "from-wy.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "ftp.sh": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "ftp.totallyanonymous.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ftp1.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ftpaccess.cc": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "ftpserver.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "fuer-alle.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "fuer-profis.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "fuettertdasnetz.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "fukt.link": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "fun.gg": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "fun.pe": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "fun5.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "fw.bz": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "fwh.is": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "fxnxs.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "g2url.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "gally.jp": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "game-host.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "game-server.cc": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "game.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "gamer.gd": {
        "score": 65,
        "source": "HaGeZi-Hoster+Kees-Suspicious"
    },
    "gaming.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "garmanage.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "garypatel.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "gastright.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "geekgalaxy.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "genblogger.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "geobattery.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "gerastar.ru": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "getmyip.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "getresponsesite.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "gets-it.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "gettrails.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "gettrials.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "gg123.vip": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ghostnation.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "gicp.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "gigaportal.pl": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "giize.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "gilde.in": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "gildenseite.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "glddns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "gleeze.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "glide.page": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "global-instr.us": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "gluebank.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "go.dyndns.org": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "go2host.co": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "godaddysites.com": {
        "score": 65,
        "source": "HaGeZi-Hoster+Kees-Suspicious"
    },
    "gofreeserve.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "golaud.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "goldcrestcc.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "golffan.us": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "googletagmanagers.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "got-game.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "gotdns.ch": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "gotdns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "gotdns.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "govt.hu": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "gr-site.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "gr.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "gr.kg": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "gr8domain.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "gr8name.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "grabify.org": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "grandmasgossip.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "gratis.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "great-site.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "greatnow.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "green-heroes.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "groks-the.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "groks-this.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "grupoimpulsora.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "grupompr.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "gslb.me": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "gt.tc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "gteksecurity.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "gtk.cl": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "guardz.ru": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "guest.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "guide.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "guild-site.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "gurcanozturk.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "gurdit.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "guthriecontainers.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "guzhibo.cn": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "gw.lt": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "gw1.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "h-o-s-t.name": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "h.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "h0stname.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "h1x.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "h4ck.me": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "hackquest.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "hackx.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ham-radio-op.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "ham.gd": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "hamshack.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "han.gl": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "hanefra7bikiemta.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "happyforever.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "hase.in": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "hatenboer.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "hbmc.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "health-carereform.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "healthyemployee.me": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "her.name": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "here-for-more.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "herodias.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "heroinewarrior.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "hexe.in": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "hicam.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "hiddencorner.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "hijaxdesigns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "hilfe24h.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "hin.tw": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "hiprinter.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "his.name": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "hitremixes.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "hldns.ru": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "hmail.us": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "hmao.pro": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "hobby-site.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "hobby-site.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "hokum-smack.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "home-webserver.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "home.dyndns.org": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "home.kg": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "home.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "home64.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "homedns.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "homeftp.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "homeftp.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "homeip.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "homelinux.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "homelinux.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "homelinux.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "homelinuxserver.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "homemarker.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "homenode.ca": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "homepage.cx": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "homepage.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "homepc.it": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "homeplex.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "homesecuritymac.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "homesecuritypc.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "homeunix.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "homeunix.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "homeunix.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "homingbeacon.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "hop.ru": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "hopto.me": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "host2.me": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "host2go.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "hostdns.me": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "hostedforfree.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "hostfree.pw": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "hosthampster.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "hostingersite.com": {
        "score": 65,
        "source": "HaGeZi-Hoster+Kees-Suspicious"
    },
    "hostingsiteforfree.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "hotfile.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "hotshare.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "hp.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "hpc.tw": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "hr-organization.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "hr-rewards.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "hs.vc": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "hst5.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "hstn.me": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "html-5.me": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "htmlcomponentservice.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "htmlpasta.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "https443.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "https443.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "hu.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "hu.kg": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "hulichicken.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "humorvisite.eu": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "hund.in": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "hunnur.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "hyderabadadda.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "hyip.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "hyperphp.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "i.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "i234.me": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "i8.ae": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "iamallama.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "ibiz.cc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "iblogger.org": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "iceiy.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ics.tw": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "id.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ideasciviles.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "idigo.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "idiot24.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "idleplay.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ieserver.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ignorelist.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "iiiii.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "ij2.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ikwb.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "ilink-to.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ilovecollege.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "im-internet.eu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "imagengratis.org": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "imagetemplate.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "imagetemplate.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "imexsac.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "imprendum.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "in-the-band.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "in.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "in.run": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "in24.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "inbox24.eu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "inbox24.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "inbox24.org": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "independentonline.ro": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "indevs.in": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "infinityfree.me": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "infinityfreeapp.com": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "inflict.us": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "info-com.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "info-home.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "info.cm": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "info.gf": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "info.nu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "info.tm": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "info24h.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "info4.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "infos.cx": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "infos.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "infy.uk": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "inkcat.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "innograph.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "instantfreesite.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "instanthq.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "int.ps": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "internetsite.eu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "intoupload.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "invitee.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "invoicenotices.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "inx.lv": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ionexusa.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "iot64.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "iownyour.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "iownyour.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "ip-ddns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ip-dynamic.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ip-dynamic.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "iplogger.cn": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "iplogger.co": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ipnodns.ru": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ipq.co": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "iprowave.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ipupdater.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ipv64.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ipv64.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ir.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "is-a-anarchist.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-blogger.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-bookkeeper.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-bruinsfan.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-bulls-fan.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-candidate.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-caterer.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-celticsfan.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-chef.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-chef.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-chef.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-conservative.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-cpa.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-cubicle-slave.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-democrat.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-designer.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-doctor.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-financialadvisor.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-geek.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-geek.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-geek.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-green.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-guru.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-hard-worker.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-hunter.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-knight.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-landscaper.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-lawyer.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-liberal.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-libertarian.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-linux-user.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-llama.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-musician.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-nascarfan.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-nurse.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-painter.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-patsfan.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-personaltrainer.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-photographer.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-player.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-republican.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-rockstar.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-socialist.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-soxfan.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-student.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-teacher.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-techie.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-a-therapist.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-alive.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "is-an-accountant.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-an-actor.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-an-actress.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-an-anarchist.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-an-artist.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-an-engineer.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-an-entertainer.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-best.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "is-by.us": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-certified.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-found.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-gone.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-great.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "is-great.org": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "is-into-anime.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-into-cars.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-into-cartoons.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-into-games.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-leet.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-lost.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-not-certified.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-saved.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-slick.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-uberleet.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-very-bad.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-very-evil.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-very-good.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-very-nice.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-very-sweet.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "is-with-theband.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "isa-geek.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "isa-geek.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "isa-geek.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "isa-hockeynut.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "isageek.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "isamotherfucking.ninja": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "isasecret.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "ishg.za.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ismoke.hk": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ispot.cc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "issmarterthanyou.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "ist-ok.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "isteingeek.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "istmein.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "it-security-group.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "it-share.ro": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "it-support-group.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "it.cx": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "it.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "itekgroup.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "itemdb.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "itheidiot.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "itpatches.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "itsafetyteam.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "itsaol.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "itsecuritymessage.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "iu4ever.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "iugaming.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ivc.cc": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ix.tc": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ixeo.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "iz.rs": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "j55.eu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ja.cat": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "jade-hamburg.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "jake.eu": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "janhost.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "javafaq.nu": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "jcmemoryscan.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "jcor.ca": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "jdfinancialserver.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "jedimasters.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "jesus.si": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "jetos.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "jixx.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "jixx.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "jkub.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "jo3.org": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "job.ec": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "joe.dj": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "joinbox.today": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "jomblo.asia": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "jonward.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "jp.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ju.mp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "jump2me.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "jumpingcrab.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "jundy.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "jungleheart.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "justdied.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "jvogt.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "jwork.ru": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "k.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "k.vu": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "k1.cx": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "k22.su": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "kanda.ru": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "kann-helfen.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "kaohsiung.tv": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "kck-saratov.ru": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "keenetic.link": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "keenetic.name": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "keenetic.pro": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "keepo.bio": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "keine-panik.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "kellserve.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "kesug.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "kicks-ass.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "kicks-ass.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "kilu.at": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "kilu.biz": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "kilu.info": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "kilu.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "kilu.org": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "kiluweb.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "klammert.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "klapa.eu": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "knabrub.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "knowsitall.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "kompaniet.nu": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "kortlink.dk": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "kozow.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "kr.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "kraftonevent.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ksk-saratov.ru": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "kurzschliessen.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "kyrgyzstan.kg": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "kz.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "l.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "l4n.org": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "l5.ca": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "l8n5kafm6l.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "labradapr.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "laden.biz": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "laketahoesue.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "lan64.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "lanas.cl": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "land-4-sale.us": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "landomain.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "larzzons.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "launchaco.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ldtp.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "lebtimnetz.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "lee.mx": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "leechall.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "leetleech.org": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "legitdns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "leitud.ee": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "leitungsen.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "leivo.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "lernt.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "lessmiths.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "letsgo2.me": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "level3.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "lflink.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "lflinkup.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "lflinkup.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "lflinkup.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "lhosting.info": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "liebe.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "lihi1.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "lihi3.cc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "likes-pie.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "likescandy.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "limit.org.uk": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "line.pm": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "link.ac": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "linkcyb.org": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "linkfast.me": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "linkin.tw": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "linkpc.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "links.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "linux-site.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "linuxd1.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "linuxdigital.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "list-mgmt.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "litecsys.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "littlebyte.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "live-stream.eu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "live-website.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "live2.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "liveblog365.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "livewave.ru": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ljack.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "llink.to": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "lmy.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "lnk.do": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "lnkz.at": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "localghost.org": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "locumm.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "loginto.me": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "logisoft-cy.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "logomebel.ru": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "logular.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "longmusic.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "look.in": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "loophole.site": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "loseyourip.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "lospenitentes.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "lostgumball.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "lovable.app": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "lovelocals.us": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "loveslife.biz": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "lovestoblog.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "lovethosetrains.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "lowrihouston.pro": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "lozan.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "lu.kg": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "lundellnet.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "luzzati.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "lyli.fi": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "m-pages.com": {
        "score": 65,
        "source": "HaGeZi-Hoster+Kees-Suspicious"
    },
    "m.vu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ma.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "macao.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "macrofox.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "maddsites.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "madhacker.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "mail.ht": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "majesticbank.at": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "majesticbank.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "maminforum.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "mao.fi": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "marieblazek.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mashstaffing.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "maurinfor.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mcsoft.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mcwrite.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mdbgo.io": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "me-page.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "me.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "me.ly": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "me2.kr": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "medbury.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "medianewsonline.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "medittech.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mefound.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "mega-debrid.eu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "meicosoft.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mein-vigor.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "melakaboy.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "members.domaindlx.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "merseine.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "merseine.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "metadns.cx": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mett.ru": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mexsipel.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mgipr.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mh-it.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "microsoftaistories.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "microsoftfiles.live": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "midjava.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mightyurl.mightyscripts.xyz": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "migibts.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "migly.in": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "mihanblog.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "mikata.ru": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mikecartwright.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mil.nf": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mindhackers.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mine.bz": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "mine.nu": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "minecraft.pe": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "minecraftnoob.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "minecraftpotato.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "minecraftr.us": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "mirolnet.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mirorii.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "misconfused.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "misecure.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "mistermousepotato.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mit-wenig-geld.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "mithrandir.us": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mixturecloud.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "mlbfan.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mmafan.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mmm.page": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "mnode.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mobi.ps": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "mobile.web.tr": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "mobinteg.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "moneyash.top": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "moneyhome.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "monitorip.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "monopolepower.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "moonangel.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mooo.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "morganisageek.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mp3.cr": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "mrbasic.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "mrbonus.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "mrface.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "mrnorris.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mrslove.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "msof.us": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mtrstore.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mudchute.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "muf.mobi": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "musik.cx": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "musik.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "musterihizmetleri.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mwop.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mx.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "my-board.org": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "my-free.website": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "my-place.us": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "my-style.in": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "my-vigor.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "my-wan.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "my.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "my.to": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "my03.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "my3gb.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "my5353.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "myactivedirectory.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "myaddr.dev": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "myaddr.io": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "myaddr.tools": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mybb.pw": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "myblogvoice.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "mybluehost.me": {
        "score": 65,
        "source": "HaGeZi-Hoster+Kees-Suspicious"
    },
    "mybluehostin.me": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "myclickfunnels.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "mycompany.tv": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mycpanel.rs": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "mydad.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "myddns.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "myddns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "myddns.me": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "myddns.rocks": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mydiscussion.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "mydissent.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mydns.bz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mydns.jp": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "myds.me": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "myeffect.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "myeweb.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "myfoolmoon.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "myfreesites.net": {
        "score": 65,
        "source": "HaGeZi-Hoster+Kees-Suspicious"
    },
    "myftp.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "myftp.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "myftp.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "myftpupload.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "myfunnelish.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "myhome-server.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "myhomedns.net": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "myhouse.tv": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "myip.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "myiphost.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "myjino.ru": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mylftv.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "mylinkinb.io": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "mylogisoft.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mymediapc.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mymom.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "mynetav.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "mynetav.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "mynetav.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mynetgear.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mynumber.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "myonlineportal.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "myonlineportal.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mypcanywhere.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mypets.ws": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "myphotos.cc": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "mypi.co": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mypicture.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "mypop3.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "mypop3.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "myportfolio.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "mypressonline.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "mypsx.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "myq-see.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mysaol.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mysecondarydns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "mysecuritycamera.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mysecuritycamera.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mysecuritycamera.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "myserver.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mystrikingly.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "mysynology.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "mytempdir.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "mywebworld.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "mywww.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "myxop.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "myz.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "n-e-t.name": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "n-e.kr": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "n.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "n0p.at": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "n4t.co": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "name.ac": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "name.vg": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "nard.ca": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "nas64.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "nat-ddns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "nathanaeldan.pro": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "natrofa.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ndcg.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "neat-url.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "neocities.org": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "nerdcamp.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "nerdpol.ovh": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "net-freaks.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "net2me.me": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "netcabo.pt": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "netcraze.pro": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "netdorm.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "netea.me": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "netfast.org": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "nethouse.ru": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "netlord.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "netmask.ca": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "netten.ru": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "networkguru.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "networkoutpost.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "netz.tl": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "newmail.ru": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "nexmicrosystems.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "nflfan.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ngrok-free.app": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "ngrok.io": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "nhlfan.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "nicepage.io": {
        "score": 65,
        "source": "HaGeZi-Hoster+Kees-Suspicious"
    },
    "ninth.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "nl.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "nl.kg": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "no-domain.name": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "no-ip.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "no-ip.ca": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "no-ip.co.uk": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "no-ip.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "no-ip.fr": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "no-ip.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "no-ip.me": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "no-ip.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "no-ip.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "noads.biz": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "nodns.ca": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "nofeeshost.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "noip.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "noip.me": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "noip.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "noip.pl": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "noip.us": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "noipdns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "noipdns.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "noipfreedns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "noiptos.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "notici.as": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "novamov.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "novgaz-rzn.ru": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "now-dns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "now-dns.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "now-dns.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "now.im": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "now.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "nowddns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "npx.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ns.hn": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ns01.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ns01.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "ns01.us": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ns02.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ns02.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "ns02.us": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ns1.name": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "ns2.name": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "ns3.name": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "nsfera.pl": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "nsupdate.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ntdll.top": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "nufszone.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "nut.cc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "nx.tc": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "nya.pub": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "o-f.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "o.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ocry.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "ods.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "oemdns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "of-love.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "office-on-the.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "officialsitebuilder.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ohbah.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "ohw.tf": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "okzk.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "olavsen.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "omas.in": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "omicronceti3.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "on-air.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "on-fleek.app": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "on-the-web.tv": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "on.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "on.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "one4u.0lx.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "onedumb.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "onepage.website": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "onionsallyear.mobi": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "online-net.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "online.cm": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "online.cr": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "online.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "online.ly": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "online.tc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "only4u.eu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "onmbl.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "onmypc.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "onmypc.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "onmypc.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "onmypc.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "onmypc.us": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "onthewifi.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ooguy.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "oops.wtf": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "opent2.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "opior.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "oray.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "organiccrap.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "orgsites.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "orskkino.ru": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "otzo.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "ourhobby.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "own-free-website.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ownip.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "oyn.at": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ozq.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "p.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "packeting.eu": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "page.gd": {
        "score": 65,
        "source": "HaGeZi-Hoster+Kees-Suspicious"
    },
    "page.tl": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "page4.me": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "pagedemo.co": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "pakasak.com": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "pancake.run": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "parikh.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "parknhost.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "party.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "partycenteronline.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "patelmortgage.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "paulkelly.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "pc.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "pdns.cz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "pe.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "peachyweb.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "pedie.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "pendulumaudio.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "peregrineair.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "perfektionieren.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "pgafan.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ph.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "phenixs.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "photo-cult.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "photo-frame.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "photos.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "php-dev.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "pics.mu": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "picvalley.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "pii.at": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "piroge.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "pixelfucker.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "pixelt.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "pizzakeep.shop": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "pk.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "pl.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "pl.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "planet.tl": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "planetdns.ca": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "planetdns.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "play.ai": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "plu.sh": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "plwgroup.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "pntl.tl": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "podzone.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "podzone.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "point2this.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "pointto.us": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "port0.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "port25.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "portal.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "portfwd.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "portmap.host": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "portrelay.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "possessed.us": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "prettyweak.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "preview-domain.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "priamaakcia.sk": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "pride.moe": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "primetap.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "privat.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "privatedns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "privatedns.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "privateimport.jp": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "privatizehealthinsurance.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "pro.ac": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "pro.vg": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "pro3.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "profis.info": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "progr.am": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "project.li": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "project.zone": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "prostore.ru": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "prout.be": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "proxydns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "prvcy.page": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "psce.pw": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "psee.io": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "psend.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "psybnc.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "pt.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "pt.kg": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ptchat.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "publicvm.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "pudim.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "punked.us": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "pxlme.me": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "q.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "q77.eu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "qc.to": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "qhigh.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "qipim.ru": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ql4h.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "qlbv.vn": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "qpoe.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "qptr.ru": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "qr.nikastic.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "qrcodedynamic.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "qrcodeveloper.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "qrsu.io": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "qry.kr": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "qthome.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "qu.am": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "quackerscomic.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "quicksytes.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "quiztionnaire.uk": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "r-e.kr": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "r-o-o-t.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "r.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "radiogirl.fm": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "radiola.club": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "railway.app": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "rapidshare.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "rapidshare.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "rapidshare.se": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "raspberryip.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "rayplee.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "re2.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "read-books.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "readmyblog.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "rebatesrule.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "reco.ws": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "recruitment7.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "recyclesolutionsllc.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "redirme.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "reijn.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "remotecam.nu": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "reodev.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "repl.co": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "replit.dev": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "replug.link": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "resolve.bar": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "rf.gd": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "risu.io": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ro.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ro.lt": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "robinhud.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "robot-armies.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "rockingwranchinc.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ron.si": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "root.sx": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "root64.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "roth.ca": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "route64.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "routemehome.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "roxa.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "royal-host.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "rplg.co": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "rpz.su": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "rtam.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ru.cm": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ru.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ru.nu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "rum.si": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "rumahweb.org": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "run.app": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "run.place": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "rundis.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ruok.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "rwbcode.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ryointernational.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "s.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "sa.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "sandmeiers.ch": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "sannon-stamm.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "saves-the-whales.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "sc.link": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "scay.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "schmust.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "schoolrack.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "scottlewisonline.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "scottstreit.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "scrapitsoftware.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "scrapper-site.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "scrapping.cc": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "sdp-mos.ru": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "se.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "seahorsenet.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "search.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "sebipay.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "seburn.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "securebankinggroup.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "securebankinggroup.org": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "secureonline.store": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "securityexploits.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "securitytactics.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "seite.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "seite.info": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "seite.ru": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "seite24.eu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "seite77.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "selfip.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "selfip.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "selfip.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "selfip.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "selfip.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "sells-for-less.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "sells-for-u.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "sells-it.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "sellsyourhome.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "semelcgmf.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "sendsmtp.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "sequoiapartners.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "serendipityshores.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "serv00.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "servebbs.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "servebbs.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "servebbs.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "servebeer.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "serveblog.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "servecounterstrike.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "serveexchange.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "serveftp.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "serveftp.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "servegame.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "servegame.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "servehalflife.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "servehumour.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "serveirc.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "serveminecraft.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "servemp3.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "serveo.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "servep2p.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "servepics.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "servequake.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "server.gg": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "server.tl": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "server2.eu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "server3.eu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "servernux.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "serverpit.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "serverthuis.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "servesarcasm.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "serveuser.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "serveusers.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "service.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "sexidude.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "sexmistrz.pl": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "sexxxy.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "shacknet.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "shacknet.us": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "shadir.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "share.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "sharkltd.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "sharkserve.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "sheatfish.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "sheepindonesia.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "shekinahphotography.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "shen.cl": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "shit.vc": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "shogun.ca": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "shop.fm": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "shop.tm": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "shop2.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "shopping.cr": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "shopping.hn": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "shortcm.li": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "shorten.so": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "shorter.me": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "shortest.link": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "shortu.be": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "shorturl.ae": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "showmyhomes.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "sieraddns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "silksky.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "simple-url.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "simplecharity.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "sino.tw": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "sitebeat.crazydomains.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "sitelutions.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "sitepalace.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "sitey.me": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "skc.su": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "skies.tw": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "skipurl.me": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "skipurl.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "skul.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "slasdot.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "sleepless.hk": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "slide2.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "sline.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "slwatch.co": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "sly.io": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "slyip.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "smelly.cc": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "sms.cr": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "smsu.io": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "snap2.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "sne.jp": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "social-networking.me": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "socialadhesion.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "socialsmp.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "softether.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "solfa.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "solidmation.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "solidwebhost.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "sonnish.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "soon.it": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "sophiashantidaniel.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "soundcast.me": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "space-to-rent.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "space.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "spacetechnology.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "spdns.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "spdns.eu": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "spdns.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "spdyn.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "spectrumnet.bg": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "spelar.se": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "sport-pro.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "sportsontheweb.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "spottt.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "spr.io": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "spruz.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "sql01.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "sqlconcepts.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "squirly.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "srv1.org": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "srv64.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "srvdns.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ssitech.bg": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ssl443.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "sslip.io": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ssmailer.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "ssur.cc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "star.is": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "start.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "start.page": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "staticrun.app": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "stemmetje.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "stes.fi": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "stfu-kthx.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "stocktester.ru": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "stormpages.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "stoupin.ru": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "strangled.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "stuff-4-sale.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "stuff-4-sale.us": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "stufftoread.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "stughead.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "stuns.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "suchtis.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "sumibi.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "sundby.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "supload.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "surfblocked.co.cc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "surfnet.ca": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "surl.lt": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "suroot.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "sv.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "sviluppo.host": {
        "score": 65,
        "source": "HaGeZi-Hoster+Kees-Suspicious"
    },
    "swoop2.me": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "swtest.ru": {
        "score": 65,
        "source": "HaGeZi-DynDNS+HaGeZi-Hoster"
    },
    "sxx.in": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "sylu.cc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "sylu.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "synergize.co": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "syno-ds.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "synology-diskstation.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "synology-ds.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "synoserver.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "syntereo.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "sysadminetworks.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "system-ns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "systes.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "t.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "tallison.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "tamaragibson.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "tantrum.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "tbns.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "tcp4.me": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "tcp64.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "tdkare.ru": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "te4m.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "teaches-yoga.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "team.cx": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "team.tl": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "teamzonesports.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "technopagans.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "techproddns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "tedfullwood.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "tehno-politen.ru": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "tekkennetwork.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "teleporthq.app": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "tempisite.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "temporary-demo.site": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "temporary.site": {
        "score": 65,
        "source": "HaGeZi-Hoster+Kees-Suspicious"
    },
    "tentbuildingservices.eu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "test.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "testingnow.me": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "texasdollies.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "tftpd.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "th.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "thaieasydns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "thamboli.co.za": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "thatip.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "thddns.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "the-button.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "the-finance-world.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "theblacklist.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "thehomeserver.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "themcmillans.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "thenest.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "thenme.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "thesemmels.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "theworkpc.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "thingsnewandused.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "thruhere.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "tiiny.host": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "tiiny.io": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "tinylink.in": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "tinyrealm.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "tinyurl.ph": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "tld.cc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "tlsn.io": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "tmpfiles.org": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "to.lk": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "tobuy.us": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "toh.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "top.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "top.tc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "top8.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "topdns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "topsddns.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "topurl.cc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "toshibanetcam.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "totalh.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "toutbox.fr": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "toythieves.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "tpddns.cn": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "tr.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "trackfinanceworld.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "traeumtgerade.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "trailsendlodge.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "trend.in": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "trickip.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "trickip.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "trieditmyself.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "trim.one": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "tru.io": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "truthvid.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "trycloudflare.com": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "tscng.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "tth.cl": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "tunnelbroker.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "turbo.site": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "turkish.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "tvlinux.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "tw.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "tw1.ru": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "twilight.ws": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "twilightparadox.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "twodns.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "typedream.app": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "tzo.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "u.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ua.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ubpages.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ucoz.ru": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ucvradio.cl": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "udp64.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ufcfan.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ufodns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "ugo.si": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "uk.cr": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "uk.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "uk.ms": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "uk.nu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "uk.st": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "uk.to": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ukit.me": {
        "score": 65,
        "source": "HaGeZi-Hoster+Kees-Suspicious"
    },
    "ultimatefreehost.in": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ultrashare.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "umbler.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ume.la": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "unaux.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "undo.it": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "unesa.me": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "unibutton.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "unitedhardwood.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "unusualperson.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "uploadbox.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "uploadbuzz.cc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "uploader.eu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "uploadev.org": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "uploading.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "uploadjar.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "upsara.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "urest.org": {
        "score": 65,
        "source": "HaGeZi-Hoster+Kees-Suspicious"
    },
    "url.usacomment.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "url1.io": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "urlaub.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "urle.me": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "urlyte.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "urown.cloud": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "us.nf": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "us.st": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "us.to": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "usa.cc": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "usa.gg": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "usafreespace.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "usclargo.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "user.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "uz.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "uzhi.ru": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "v.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "v0id.nl": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "v0r.org": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "v13clan.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "v6.army": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "v6.navy": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "v6.rocks": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "vankin.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "vantechddns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "vantechdns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "vastserve.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "vav.li": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "vctel.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "vdxh.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ve.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ve3.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "venez.fr": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "venez.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "verifypass.pw": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "verkniffen.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "verymad.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "viamisoftware.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "vicinanza.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "vicp.cc": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "vicp.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "vidcloud.co": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "vietnamddns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "viewdns.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "viiic.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "vinaddns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "vincomlimited.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "virtue.nu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "virus.in": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "vitalwerks.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "vizvaz.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "vn.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "vn.run": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "voellig-daneben.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "voles35.ru": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "vollidiot.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "vollsten.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "voten.in": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "voyez.ca": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "vpn.net.br": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "vpn64.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "vpndns.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "vpntraki.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "vpnx.nl": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "vr.lt": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "vuzelia.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "vxe6.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "vz.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "w3spaces.com": {
        "score": 65,
        "source": "HaGeZi-Hoster+Kees-Suspicious"
    },
    "wakingmoon.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "wan64.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "wanip.ch": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "wapka.club": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "wapka.site": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "wapka.store": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "wapka.top": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "wapka.website": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "warp9computers.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "web-chat.eu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "web-clan.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "web.gg": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "web.pe": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "web1337.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "webaccess-alert.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "webaccess-email.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "webador.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "webblog24.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "webboss.site": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "webcindario.com": {
        "score": 65,
        "source": "HaGeZi-Hoster+Kees-Suspicious"
    },
    "webflow.io": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "webhop.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "webhop.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "webhop.me": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "webhop.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "webhop.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "webn.cc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "webnode.com.pt": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "webobo.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "webok.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "webpages.one": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "webredirect.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "webs.vc": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "webservis.ru": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "website-home.ws": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "website.at": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "website.yandexcloud.net": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "webspawner.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "webstarterz.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "webwave.dev": {
        "score": 65,
        "source": "HaGeZi-Hoster+Kees-Suspicious"
    },
    "webydo.com": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "weebly.com": {
        "score": 65,
        "source": "HaGeZi-Hoster+Kees-Suspicious"
    },
    "weeblysite.com": {
        "score": 65,
        "source": "HaGeZi-Hoster+Kees-Suspicious"
    },
    "welt.tl": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "westblade.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "whyboner.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "wifizone.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "wikaba.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "wiki.gd": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "wiki.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "wikiupload.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "wild1.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "wildsurf.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "will-dich.eu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "williambest.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "winco.com.br": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "winconnection.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "windmillstravel.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "winnity.ro": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "wixsite.com": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "wixstudio.com": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "wmhelp.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "wolmerica.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "womenclothingtoday.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "work.gd": {
        "score": 65,
        "source": "HaGeZi-DynDNS+HaGeZi-Hoster+Kees-Suspicious"
    },
    "workisboring.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "world-blog.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "world-store.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "world.mu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "worldsoffinance.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "worse-than.tv": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "wpenginepowered.com": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "writes.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "writesthisblog.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "wstd.io": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "wtcsites.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "wuaze.com": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "www1.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "www4.me": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "wwwhost.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "wwwhost.us": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "wy5532.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "x.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "x24hr.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "x443.pw": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "x9.eu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "x90x.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "xaper.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "xblog.in": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "xddns.de": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "xl.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "xml.in": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "xname.org": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "xo.je": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "xpresit.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "xsl.tel": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "xsph.ru": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "xtreemhost.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "xurl.app": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "xurl.es": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "xx.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "xxl.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "xxuz.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "xxxxx.tw": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "xxxy.biz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "xxxy.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "y.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "y55.eu": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "yahoosites.com": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "yao.cl": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ydns.eu": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ydns.io": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ygrrvlvvgf.top": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ygto.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "yiannamarie.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "yiff.fi": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "yip.su": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "yj.ae": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "ykm.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "yngling.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "yolasite.com": {
        "score": 50,
        "source": "Kees-Suspicious"
    },
    "you.lc": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "youdontcare.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "youpc.ro": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "yourspecialtee.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "yourtrap.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "yu3.io": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "yuichi.shop": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "z.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "z0d.eu": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "z86.ru": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "za.gp": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "zabc.net": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "zaibar.ro": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "zalil.ru": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "zanity.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "zapier.app": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "zapto.xyz": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "zeabur.app": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "zeitr.ch": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "zelslonik.info": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "ziddu.com": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "zneth.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "zoneedit.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "zsh.jp": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "zustimmen.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "zverovich.net": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "zx9.de": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "zya.me": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    },
    "zyix.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS"
    },
    "zyns.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "zzux.com": {
        "score": 60,
        "source": "HaGeZi-DynDNS+Kees-Suspicious"
    },
    "zzz.com.ua": {
        "score": 65,
        "source": "HaGeZi-Hoster"
    }
};
