"use strict";

/**
 * SuspiciousTlds.js
 * Risk scores (0–100) for TLDs frequently abused in phishing, spam, and
 * malware delivery. Higher score = stronger indicator of risk.
 *
 * DOCS/ARCHITECTURE.md, "Filter-data remote-update mechanism" — the raw
 * TABLE data now lives in EXTENSION/data/SuspiciousTlds.json (single source
 * of truth); this module only holds the lookup LOGIC. See
 * SuspiciousDomains.js's header for the full rationale — this module follows
 * the identical pattern.
 */
import { SuspiciousTldsDefault } from "./SuspiciousTlds.default.js";

export const SuspiciousTlds = (function () {

    let TABLE = SuspiciousTldsDefault;

    /**
     * Look up a TLD in the table.
     * @param {string} tld - Just the last label, e.g. "xyz"
     * @returns {{ score: number, tld: string } | null}
     */
    function lookup(tld) {
        if (!tld) return null;
        const t = tld.toLowerCase();
        if (TABLE[t] !== undefined) {
            return { score: TABLE[t], tld: t };
        }
        return null;
    }

    function setData(newTable) {
        TABLE = newTable;
    }

    function resetToDefault() {
        TABLE = SuspiciousTldsDefault;
    }

    return { lookup, setData, resetToDefault };
})();
