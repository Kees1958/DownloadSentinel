"use strict";

/**
 * SuspiciousTlds.default.js — GENERATED FILE. Do not hand-edit; run
 * `node tools/gen-data-defaults.mjs` to regenerate from the single source
 * of truth, EXTENSION/data/SuspiciousTlds.json.
 *
 * This is the bundled/offline default: compiled into the reviewed CWS
 * package so SuspiciousTlds always has a safe starting value even before
 * util/FilterDataLoader.js ever attempts a remote fetch, and whenever that
 * fetch fails, is unavailable, or returns malformed data.
 *
 * Generated: 2026-10-09T10:51:23.221Z
 */
export const SuspiciousTldsDefault = {
    "zip": 100,
    "click": 85,
    "cfd": 85,
    "rest": 80,
    "surf": 80,
    "top": 75,
    "icu": 70,
    "shop": 68,
    "xyz": 65,
    "online": 65,
    "site": 65,
    "mov": 62,
    "review": 60,
    "download": 58,
    "monster": 55,
    "buzz": 52,
    "fun": 50,
    "live": 50,
    "sbs": 45,
    "store": 42,
    "space": 42,
    "website": 42,
    "digital": 40,
    "solutions": 40,
    "agency": 38,
    "email": 38,
    "info": 30
};
