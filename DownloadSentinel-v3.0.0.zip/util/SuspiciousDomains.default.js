"use strict";

/**
 * SuspiciousDomains.default.js — GENERATED FILE. Do not hand-edit; run
 * `node tools/gen-data-defaults.mjs` to regenerate from the single source
 * of truth, EXTENSION/data/SuspiciousDomains.json.
 *
 * This is the bundled/offline default: compiled into the reviewed CWS
 * package so SuspiciousDomains always has a safe starting value even before
 * util/FilterDataLoader.js ever attempts a remote fetch, and whenever that
 * fetch fails, is unavailable, or returns malformed data.
 *
 * Generated: 2026-10-09T10:51:23.213Z
 */
export const SuspiciousDomainsDefault = {
    "duckdns.org": 95,
    "3322.org": 95,
    "ddns.net": 90,
    "hopto.org": 90,
    "zapto.org": 90,
    "servehttp.com": 90,
    "serveftp.com": 90,
    "sytes.net": 90,
    "myvnc.com": 90,
    "mywire.org": 90,
    "mooo.com": 90,
    "dynu.net": 85,
    "freedns.afraid.org": 85,
    "redirectme.net": 85,
    "ddns.me": 80,
    "workers.dev": 85,
    "pages.dev": 85,
    "github.io": 75,
    "netlify.app": 75,
    "vercel.app": 75,
    "onrender.com": 75,
    "fly.dev": 70,
    "firebaseapp.com": 70,
    "web.app": 65,
    "glitch.me": 65,
    "surge.sh": 65,
    "gist.githubusercontent.com": 80,
    "catbox.moe": 80,
    "pixeldrain.com": 75,
    "file.io": 70,
    "drive.google.com": 35,
    "docs.google.com": 30,
    "is.gd": 70,
    "tinyurl.com": 65,
    "bit.ly": 60,
    "cutt.ly": 60,
    "rebrand.ly": 55,
    "shorturl.at": 55,
    "tiny.cc": 55,
    "rb.gy": 50,
    "t.ly": 50,
    "ow.ly": 40,
    "s.id": 40,
    "discord.com": 60,
    "t.me": 55,
    "telegram.org": 40,
    "raw.githack.com": 75,
    "jsdelivr.net": 35
};
