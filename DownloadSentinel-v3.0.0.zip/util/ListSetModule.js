"use strict";

/**
 * ListSetModule.js — Shared factory for the two extracted data modules whose
 * shape is "a flat list of strings, exposed as both .list and .set"
 * (BrandDomains.js, UrlShorteners.js). Both used to hand-roll an identical
 * IIFE around their own default (jscpd flagged the duplication once the
 * EXTENSION/data/ split landed — see DOCS/CHANGELOG.md's v2.10.0 entry) —
 * this is the single implementation both now call into.
 *
 * Not itself one of the six extracted data modules util/FilterDataLoader.js
 * knows by name — it has no data and no default of its own. It only exists
 * to remove duplication between the two that share this exact shape.
 */
export function createListSetModule(defaultList) {
    let list = defaultList;
    let set = new Set(list);

    function setData(newList) {
        list = newList;
        set = new Set(list);
    }

    function resetToDefault() {
        list = defaultList;
        set = new Set(list);
    }

    return {
        get list() { return list; },
        get set() { return set; },
        setData,
        resetToDefault,
    };
}
