"use strict";

/**
 * FilterDataLoader.js — Remote-refresh mechanism for the extracted,
 * pure-data lists (heuristics-plan data split, v2.10.0 restructure).
 *
 * See DOCS/ARCHITECTURE.md for the full design and the CWS-policy rationale.
 * In short: Chrome Web Store review covers the reviewed EXTENSION package
 * (manifest + code). Remotely-fetched PURE JSON DATA — no executable code,
 * no eval/new Function, no injected scripts — can be fetched at runtime and
 * change the extension's live behavior without triggering a new review,
 * *as long as* the fetching/parsing/applying code itself doesn't change.
 * This module is that already-reviewed fetch/parse/apply code; the data it
 * fetches is what's allowed to change between reviews.
 *
 * For each of the six extracted data modules (SuspiciousDomains,
 * SuspiciousTlds, RiskyHostingSites, HostList, BrandDomains, UrlShorteners)
 * this module:
 *   (a) ships no default of its own — each module already carries its own
 *       compiled-in bundled default (generated from EXTENSION/data/*.json;
 *       see each module's *.default.js) and uses it until/unless this loader
 *       successfully applies something else;
 *   (b) on init()/alarm, attempts to fetch that module's live JSON from
 *       REMOTE_BASE_URL + "/<Name>.json";
 *   (c) caches a successfully-fetched-and-validated copy in
 *       chrome.storage.local under FILTER_DATA_STORAGE_PREFIX + name, with a
 *       fetchedAt timestamp;
 *   (d) falls back to the last-known-good cached copy, or the bundled
 *       default if there is none, whenever a fetch fails, chrome.storage is
 *       empty, or the fetched JSON fails validateShape() for that module's
 *       declared shape — never lets malformed remote JSON reach a lookup()
 *       call or throw.
 *
 * Idempotent init()/clear() guard pattern (per project convention — a clear
 * init that's safe to call more than once, an explicit in-memory state that
 * can be released, no dangling timers/listeners):
 *   - init() checks an internal `initialized` flag before doing anything;
 *     calling it again is a no-op (returns the same in-flight/aleady-settled
 *     promise) until clear() is called.
 *   - the periodic refresh alarm is created idempotently: chrome.alarms.get()
 *     is checked before chrome.alarms.create() so re-running init() (e.g.
 *     after a service-worker restart, which Chrome does routinely for MV3)
 *     never creates a second alarm.
 *   - clear() removes the alarm listener and alarm, resets `initialized`,
 *     and drops the in-memory "currently applied" bookkeeping — used by
 *     tests so one test's state can never leak into the next.
 *
 * REMOTE_BASE_URL points at this project's own published repo
 * (raw.githubusercontent.com/Kees1958/uBol-stripped), matching the host now
 * added to manifest.json's host_permissions. If the data files are ever
 * published from a different path within that repo (or a different repo
 * entirely), update both this constant and that host_permissions entry
 * together — a host_permissions change is itself a reviewable manifest
 * change, so it is never done silently by this loader. Until the data
 * files actually exist at that published path, every fetch fails closed
 * (404 / network error) and every list simply keeps using its bundled
 * default — this is intentional and safe, the same "deliberately
 * conservative" posture the rest of this codebase's defensive style uses
 * elsewhere (e.g. StagingCheck.js's evasion handling).
 */
import { SuspiciousDomains } from "./SuspiciousDomains.js";
import { SuspiciousTlds } from "./SuspiciousTlds.js";
import { RiskyHostingSites } from "./RiskyHostingSites.js";
import { HostList } from "./HostList.js";
import { BrandDomains } from "./BrandDomains.js";
import { UrlShorteners } from "./UrlShorteners.js";

export const FilterDataLoader = (function () {

    // ── Configuration ───────────────────────────────────────────────────────
    //
    // This project's own repo, published on GitHub. manifest.json's
    // host_permissions includes this exact host. The data/*.json files must
    // live at this path in the repo for fetches to succeed; until they are
    // published there, fetches 404 and every list falls back to its bundled
    // default (safe by design — see module header comment).
    const REMOTE_BASE_URL = "https://raw.githubusercontent.com/Kees1958/uBol-stripped/main/EXTENSION/data";

    const ALARM_NAME = "filterDataRefresh";
    const REFRESH_PERIOD_MINUTES = 12 * 60; // twice a day — list data changes slowly
    const STORAGE_PREFIX = "filterData:";
    const FETCH_TIMEOUT_MS = 8000;

    // One entry per extracted module: how to validate its shape and how to
    // apply a validated result. `validate` never throws — it returns a
    // boolean, so a shape failure is just "don't apply this", not a crash.
    const SOURCES = [
        {
            name: "SuspiciousDomains",
            module: SuspiciousDomains,
            validate: validateObjectOfNumbers,
        },
        {
            name: "SuspiciousTlds",
            module: SuspiciousTlds,
            validate: validateObjectOfNumbers,
        },
        {
            name: "RiskyHostingSites",
            module: RiskyHostingSites,
            validate: validateRiskyHostingSitesShape,
        },
        {
            name: "HostList",
            module: HostList,
            validate: validateHostListShape,
        },
        {
            name: "BrandDomains",
            module: BrandDomains,
            validate: validateArrayOfStrings,
        },
        {
            name: "UrlShorteners",
            module: UrlShorteners,
            validate: validateArrayOfStrings,
        },
    ];

    // ── In-memory state (released by clear()) ──────────────────────────────
    let initialized = false;
    let initPromise = null;
    let alarmListener = null;

    // ── Shape validators — defensive, never throw ───────────────────────────
    function validateArrayOfStrings(data) {
        return Array.isArray(data) && data.length > 0 &&
            data.every((entry) => typeof entry === "string" && entry.length > 0);
    }

    function validateObjectOfNumbers(data) {
        if (!data || typeof data !== "object" || Array.isArray(data)) return false;
        const keys = Object.keys(data);
        if (keys.length === 0) return false;
        return keys.every((k) => typeof data[k] === "number");
    }

    function validateRiskyHostingSitesShape(data) {
        return Array.isArray(data) && data.length > 0 &&
            data.every((entry) =>
                entry && typeof entry.host === "string" &&
                typeof entry.score === "number" &&
                typeof entry.exact === "boolean");
    }

    function validateHostListShape(data) {
        if (!data || typeof data !== "object" || Array.isArray(data)) return false;
        const keys = Object.keys(data);
        if (keys.length === 0) return false;
        return keys.every((k) => {
            const v = data[k];
            return v && typeof v.score === "number" && typeof v.source === "string";
        });
    }

    // ── chrome.storage.local cache helpers ──────────────────────────────────
    async function readCache(name) {
        try {
            if (!chrome?.storage?.local) return null;
            const key = STORAGE_PREFIX + name;
            const result = await chrome.storage.local.get(key);
            return result?.[key] || null;
        } catch {
            return null; // defensive — storage API unavailable or threw
        }
    }

    async function writeCache(name, data) {
        try {
            if (!chrome?.storage?.local) return;
            const key = STORAGE_PREFIX + name;
            await chrome.storage.local.set({
                [key]: { data, fetchedAt: Date.now() },
            });
        } catch {
            // Defensive — a failed cache write never blocks applying the
            // freshly-fetched data to the in-memory table this run.
        }
    }

    // ── Fetch one source's live JSON, bounded by a timeout ──────────────────
    async function fetchRemote(name) {
        if (typeof fetch !== "function") return null;
        const controller = typeof AbortController === "function" ? new AbortController() : null;
        const timer = controller ? setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS) : null;
        try {
            const response = await fetch(`${REMOTE_BASE_URL}/${name}.json`, {
                signal: controller?.signal,
                cache: "no-store",
            });
            if (!response.ok) return null;
            return await response.json();
        } catch {
            return null; // network error, abort, CORS, not in host_permissions, bad JSON, etc.
        } finally {
            if (timer) clearTimeout(timer);
        }
    }

    // ── Refresh a single source: fetch -> validate -> cache -> apply ───────
    // Falls back, in order: freshly-fetched-and-valid > last-known-good
    // cache > the module's own compiled-in default (already active, so "do
    // nothing" is the correct fallback there).
    async function refreshOne(source) {
        const remote = await fetchRemote(source.name);
        if (remote !== null && source.validate(remote)) {
            source.module.setData(remote);
            await writeCache(source.name, remote);
            return "remote";
        }

        const cached = await readCache(source.name);
        if (cached && source.validate(cached.data)) {
            source.module.setData(cached.data);
            return "cached";
        }

        // Neither a fresh fetch nor a cached copy validated — leave whatever
        // is already loaded (the bundled default, on first run) in place.
        return "default";
    }

    async function refreshAll() {
        const results = {};
        for (const source of SOURCES) {
            try {
                results[source.name] = await refreshOne(source);
            } catch {
                // Belt-and-braces: refreshOne() shouldn't throw (every step
                // inside it is already wrapped), but a single source's
                // failure must never stop the others from refreshing.
                results[source.name] = "error";
            }
        }
        return results;
    }

    // ── Alarm wiring — idempotent ────────────────────────────────────────────
    async function ensureAlarm() {
        if (!chrome?.alarms) return; // alarms permission/API unavailable (e.g. under test)
        const existing = await chrome.alarms.get(ALARM_NAME);
        if (!existing) {
            chrome.alarms.create(ALARM_NAME, { periodInMinutes: REFRESH_PERIOD_MINUTES });
        }
        if (!alarmListener) {
            alarmListener = (alarm) => {
                if (alarm.name === ALARM_NAME) refreshAll();
            };
            chrome.alarms.onAlarm.addListener(alarmListener);
        }
    }

    // ── Public API ───────────────────────────────────────────────────────────

    /**
     * Idempotent. First call kicks off an initial refresh (cached copy
     * applied synchronously-ish via the returned promise; a live fetch is
     * attempted alongside) and sets up the periodic alarm. Any call while
     * already initialized returns the same settled/in-flight promise rather
     * than doing any of this again — safe to call from every background.js
     * startup path (onInstalled, onStartup, a stray re-import) without
     * double-fetching or double-creating the alarm.
     */
    function init() {
        if (initPromise) return initPromise;
        initialized = true;
        initPromise = (async () => {
            await ensureAlarm();
            return refreshAll();
        })();
        return initPromise;
    }

    /**
     * Releases all in-memory state: the alarm listener (and the alarm
     * itself, best-effort), the cached init promise, and resets every
     * extracted module back to its bundled default. Intended for tests —
     * production code has no reason to call this.
     */
    function clear() {
        if (chrome?.alarms?.onAlarm && alarmListener) {
            chrome.alarms.onAlarm.removeListener(alarmListener);
        }
        if (chrome?.alarms?.clear) {
            try { chrome.alarms.clear(ALARM_NAME); } catch { /* best-effort */ }
        }
        alarmListener = null;
        initialized = false;
        initPromise = null;
        for (const source of SOURCES) source.module.resetToDefault();
    }

    function isInitialized() {
        return initialized;
    }

    return {
        init,
        clear,
        isInitialized,
        refreshAll,
        // Exposed for FilterDataLoader.test.js — pure, no chrome.* access.
        _validators: {
            validateArrayOfStrings,
            validateObjectOfNumbers,
            validateRiskyHostingSitesShape,
            validateHostListShape,
        },
        _SOURCES: SOURCES.map((s) => s.name),
        _REMOTE_BASE_URL: REMOTE_BASE_URL,
    };
})();
