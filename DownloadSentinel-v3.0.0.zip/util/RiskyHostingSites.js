"use strict";

/**
 * RiskyHostingSites.js
 *
 * Identifies download URLs hosted on platforms where the main domain is
 * reputable but content is user-uploaded and unvetted, OR platforms with
 * a high historical malware distribution rate.
 *
 * Match modes:
 *   exact: true  — only the specified hostname matches
 *   exact: false — hostname OR any subdomain matches (suffix match)
 *
 * Score guidance:
 *   -15  Reputable platform, accountable users (Dropbox, OneDrive direct)
 *   -10  Accountable platform, auditable content (GitHub CDN subdomains)
 *   -15  Accountable platform, less mainstream (GitLab, Bitbucket, Codeberg)
 *   -20  Requires account, content unvetted (Discord CDN)
 *   -35  Mixed reputation, some moderation (SourceForge, NexusMods, paste sites)
 *   -45  High abuse rate, some anonymous uploads (MEGA, MediaFire, ROM sites)
 *   -55  Primarily used for piracy/cracks (getintopc, softonic-type)
 *   -65  Designed for anonymous uploads (AnonFiles variants)
 *   -70  Cheat/hack forums, game exploit sites
 *   -75  Crack/warez/nulled software sites
 *   -80  Roblox/child-targeted exploit sites (extremely high risk)
 *
 * DOCS/ARCHITECTURE.md, "Filter-data remote-update mechanism" — the raw
 * SITES list now lives in EXTENSION/data/RiskyHostingSites.json (single
 * source of truth); this module only holds the lookup LOGIC. See
 * SuspiciousDomains.js's header for the full rationale.
 */
import { RiskyHostingSitesDefault } from "./RiskyHostingSites.default.js";

export const RiskyHostingSites = (function () {

    let SITES = RiskyHostingSitesDefault;

    /**
     * Look up a hostname against the risky hosting sites list.
     *
     * @param {string} hostname  - lowercased hostname from the download URL
     * @returns {{ host: string, score: number, label: string } | null}
     */
    function lookup(hostname) {
        if (!hostname) return null;
        const host = hostname.toLowerCase();

        for (const site of SITES) {
            if (site.exact) {
                if (host === site.host) {
                    return { host: site.host, score: site.score,
                             label: `Download hosted on risky file sharing platform (${site.host})` };
                }
            } else {
                // Suffix match — catches the domain itself and all subdomains
                if (host === site.host || host.endsWith("." + site.host)) {
                    // Show the matched entry host, not the full subdomain
                    return { host: site.host, score: site.score,
                             label: `Download hosted on risky file sharing platform (${host})` };
                }
            }
        }
        return null;
    }

    function setData(newSites) {
        SITES = newSites;
    }

    function resetToDefault() {
        SITES = RiskyHostingSitesDefault;
    }

    return { lookup, setData, resetToDefault };

})();
