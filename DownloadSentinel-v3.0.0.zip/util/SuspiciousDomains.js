"use strict";

/**
 * SuspiciousDomains.js
 * Risk scores (0–100) for domains that are frequently used in malware delivery.
 * Higher score = stronger indicator of risk.
 *
 * Lookup is done against the full hostname AND the registered domain (last two labels),
 * so "raw.githubusercontent.com" is matched even if the download comes from a subdomain.
 *
 * DOCS/ARCHITECTURE.md, "Filter-data remote-update mechanism" — the raw TABLE
 * data used to live inline in this file. It now lives in
 * EXTENSION/data/SuspiciousDomains.json (the single source of truth) and this
 * module only holds the lookup LOGIC. The compiled-in default below is
 * generated from that JSON (see SuspiciousDomains.default.js's own header);
 * util/FilterDataLoader.js may replace it at runtime with a freshly-fetched
 * copy via setData() — lookup() itself stays synchronous either way, reading
 * whatever TABLE currently holds.
 */
import { SuspiciousDomainsDefault } from "./SuspiciousDomains.default.js";

export const SuspiciousDomains = (function () {

    let TABLE = SuspiciousDomainsDefault;

    /**
     * Look up a hostname in the table.
     * Checks the full hostname first, then the registered domain (last two labels).
     * Returns { score, matchedDomain } or null if not found.
     */
    function lookup(hostname) {
        if (!hostname) return null;
        const h = hostname.toLowerCase();

        // Full hostname match (e.g. "raw.githubusercontent.com")
        if (TABLE[h] !== undefined) {
            return { score: TABLE[h], matchedDomain: h };
        }

        // Registered-domain match (last two labels)
        const parts = h.split(".");
        if (parts.length >= 2) {
            const reg = parts.slice(-2).join(".");
            if (TABLE[reg] !== undefined) {
                return { score: TABLE[reg], matchedDomain: reg };
            }
        }

        return null;
    }

    /**
     * Replace the in-memory table — called only by util/FilterDataLoader.js
     * after it has fetched and shape-validated a remote update, or to reset
     * back to the bundled default (e.g. in tests). Never called with
     * unvalidated data — see FilterDataLoader.js's validateObjectOfNumbers().
     */
    function setData(newTable) {
        TABLE = newTable;
    }

    function resetToDefault() {
        TABLE = SuspiciousDomainsDefault;
    }

    return { lookup, setData, resetToDefault };
})();
