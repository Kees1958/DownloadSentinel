"use strict";

/**
 * BrandDomains.default.js — GENERATED FILE. Do not hand-edit; run
 * `node tools/gen-data-defaults.mjs` to regenerate from the single source
 * of truth, EXTENSION/data/BrandDomains.json.
 *
 * This is the bundled/offline default: compiled into the reviewed CWS
 * package so BrandDomains always has a safe starting value even before
 * util/FilterDataLoader.js ever attempts a remote fetch, and whenever that
 * fetch fails, is unavailable, or returns malformed data.
 *
 * Generated: 2026-10-09T10:51:23.232Z
 */
export const BrandDomainsDefault = [
    "amazon.com",
    "google.com",
    "microsoft.com",
    "apple.com",
    "paypal.com",
    "facebook.com",
    "instagram.com",
    "netflix.com",
    "chase.com",
    "wellsfargo.com",
    "bankofamerica.com",
    "ebay.com",
    "linkedin.com",
    "dropbox.com",
    "adobe.com",
    "citibank.com",
    "americanexpress.com",
    "coinbase.com",
    "binance.com",
    "steampowered.com",
    "docusign.com",
    "outlook.com"
];
