"use strict";

/**
 * BrandDomains.js — Commonly-impersonated brand domains, for the bigram
 * homoglyph typosquat check (heuristics plan "Later steps", v2.11.0).
 *
 * This is a small, curated top-N list (not an exhaustive brand database):
 * widely-phished shopping/tech/social/financial brands whose names are
 * short enough and common enough as download/phishing lures that a
 * character-substitution typosquat ("arnazon.com" for "amazon.com") is a
 * realistic attack, not a theoretical one.
 *
 * Each entry is the brand's own registered domain (eTLD+1, lowercase, no
 * "www." / scheme) — this is the string `FilenameUrlHeuristics.checkBrand
 * Homoglyph()` compares a candidate's registered domain against, both
 * exactly (real-domain exemption) and after bigram normalisation (the
 * actual typosquat detection).
 *
 * DOCS/ARCHITECTURE.md, "Filter-data remote-update mechanism" — the list now
 * lives in EXTENSION/data/BrandDomains.json (single source of truth; "to add
 * a brand: add its domain there only"); this module only holds the small
 * `.set` convenience derivation (shared with UrlShorteners.js via
 * ListSetModule.js — same shape, same factory). See SuspiciousDomains.js's
 * header for the full rationale behind the default/remote split.
 */
import { BrandDomainsDefault } from "./BrandDomains.default.js";
import { createListSetModule } from "./ListSetModule.js";

export const BrandDomains = createListSetModule(BrandDomainsDefault);
