"use strict";

/**
 * MimeCheck.js
 *
 * Checks whether a file's extension is consistent with its declared MIME type,
 * and whether the file size exceeds VirusTotal's maximum upload limit.
 *
 * MIME consistency:
 *   - "application/octet-stream" and "text/plain" are both treated as
 *     neutral for every extension (too common, server laziness — this
 *     includes script extensions as of v2.9.0; see that CHANGELOG entry for
 *     why the previous script-specific -20 penalty here was a bug)
 *   - A genuine mismatch (e.g. .exe served as image/jpeg) scores -60
 *   - A match scores 0 (reported as informational)
 *
 * File size:
 *   - Exceeds 650 MB → -20 (VT will skip scanning; antivirus evasion technique)
 */
import { DangerousMimes } from "../util/DangerousMimes.js";

export const MimeCheck = (function () {

    const VT_MAX_BYTES = 650 * 1024 * 1024; // 650 MB

    // DS-H008: MIME_TO_EXTS is no longer defined here — single source of
    // truth is now util/DangerousMimes.js, shared with background.js's
    // EXECUTABLE_MIMES gate so the two can never drift apart again.
    const MIME_TO_EXTS = DangerousMimes.MIME_TO_EXTS;

    // Build reverse map: ext → set of allowed MIME types
    const EXT_TO_MIMES = {};
    for (const [mime, exts] of Object.entries(MIME_TO_EXTS)) {
        for (const ext of exts) {
            if (!EXT_TO_MIMES[ext]) EXT_TO_MIMES[ext] = new Set();
            EXT_TO_MIMES[ext].add(mime);
        }
    }

    /**
     * Check MIME type consistency with the file extension.
     *
     * @param {string} ext       - file extension without dot, lowercase (e.g. "exe")
     * @param {string} mimeType  - MIME type from Content-Type header (e.g. "image/jpeg")
     * @returns {{ consistent: boolean|null, neutral: boolean, label: string, score: number }}
     */
    function checkMime(ext, mimeType) {
        if (!ext || !mimeType) {
            return { consistent: null, neutral: true,
                     label: "MIME type unavailable", score: 0 };
        }

        // Normalise — strip parameters like "; charset=utf-8"
        const mime = DangerousMimes.normalize(mimeType);

        // application/octet-stream and text/plain are common lazy server defaults —
        // both treated as neutral (too common, server laziness) for every
        // extension, scripts included.
        //
        // v2.9.0 bug fix: scripts used to get a special -20 "possible
        // misconfiguration" penalty here instead of the neutral treatment
        // every other extension gets for the exact same MIME type. In
        // practice "text/plain" is the single most common Content-Type raw
        // script hosting actually uses — raw.githubusercontent.com and
        // virtually every install-one-liner CDN serve .sh/.py/.ps1 etc. this
        // way as a matter of course, not as a misconfiguration. Under the
        // pre-v2.9.0 "worst signal wins" model this penalty was invisible
        // (ScriptFormat's -25 always dominated it); Step 3's combination
        // logic let it stack with ScriptFormat and push ordinary install
        // scripts (nvm, rustup, oh-my-zsh, docker, …) into a worse warning
        // tier than they deserve — caught by the fp-sweep known-good gate,
        // fixed here rather than worked around. See CHANGELOG.
        if (mime === "application/octet-stream" || mime === "binary/octet-stream" || mime === "text/plain") {
            return { consistent: null, neutral: true,
                     label: `MIME type is generic (${mime}) — server default, not evaluated`, score: 0 };
        }

        const allowedMimes = EXT_TO_MIMES[ext];

        // Extension not in our map — can't evaluate
        if (!allowedMimes) {
            return { consistent: null, neutral: true,
                     label: `MIME type not evaluated for .${ext}`, score: 0 };
        }

        if (allowedMimes.has(mime)) {
            return { consistent: true, neutral: false,
                     label: `File extension ".${ext}" is consistent with MIME type "${mime}"`,
                     score: 0 };
        }

        // True mismatch
        return { consistent: false, neutral: false,
                 ext, mime,
                 label: `File extension ".${ext}" does not match MIME type "${mime}"`,
                 score: -60 };
    }

    /**
     * Check whether file size exceeds VirusTotal's maximum upload size (650 MB).
     *
     * @param {number|null} totalBytes
     * @returns {{ exceeds: boolean, label: string, score: number }}
     */
    function checkSize(totalBytes) {
        if (!totalBytes || totalBytes <= 0) {
            return { exceeds: false, label: "File size unknown", score: 0 };
        }
        if (totalBytes > VT_MAX_BYTES) {
            const mb = (totalBytes / (1024 * 1024)).toFixed(1);
            return { exceeds: true,
                     label: `File size ${mb} MB exceeds VirusTotal maximum (650 MB) — antivirus scan may be skipped`,
                     score: -20 };
        }
        return { exceeds: false, label: `File size within VirusTotal limit`, score: 0 };
    }

    return { checkMime, checkSize, VT_MAX_BYTES };

})();
