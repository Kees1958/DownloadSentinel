# Changelog History — DownloadSentinel

Full technical record of releases: what changed, why, how, known limitations and the source worked from.
The brief user-facing summary is CHANGELOG.md.

---

## 3.3.1 — DNS4EU + CleanBrowsing as DNS checks 4 and 5; France defaults; optional host permissions

Source worked from: DownloadSentinel 3.3.0 extension + tools (uploaded 2026-10-24).
Trigger (user, 2026-10-24): Quad9 refuses the Paris court's blocking order (beIN/Canal+, WTA streams; beIN seeks
up to €10,000 per domain per day, ~€580k/day for 58 domains) and says it may leave France — not left as of
2026-10-24. Asked: a fourth malware-blocking DNS, and France default = Control D first, Cloudflare 1.1.1.2 second.

### Providers (util/AppConstants.js — single source of truth)
- New enum `DNS_BLOCK_STYLE` (declared above `APP`, exposed as `APP.DNS_BLOCK_STYLE`): NXDOMAIN_NO_AUTHORITY,
  ZERO_IP, BLOCKPAGE_IP, RPZ_SOA. Providers and DnsThreatProtection compare against it, no raw strings.
- `dns4eu` — DNS4EU Protective (EU-funded, run by Whalebone), `https://protective.joindns4.eu/dns-query`,
  BLOCKPAGE_IP, `blockPageIps: ["51.15.69.11"]`. Verified live 2026-10-24 against 86.54.11.1 (same profile, via
  digwebinterface.com): malware.wicar.org → A 51.15.69.11; thisdoesnotexist-12345.com → NXDOMAIN with the "com."
  registry SOA; malware.testcategory.com → real A records. DNS4EU applies court orders on every profile.
- `cleanbrowsing` — CleanBrowsing Security Filter, `https://doh.cleanbrowsing.org/doh/security-filter/`,
  RPZ_SOA, `rpzSoaMnameSuffix: "rpz.noc.org"`. Verified live 2026-10-24 against 185.228.168.9:
  malware.wicar.org → no answer + SOA `malware.wicar.org. SOA cleanbrowsing.rpz.noc.org. accesspolicy.rpz.noc.org.`;
  thisdoesnotexist-12345.com → `com. SOA a.gtld-servers.net.`; example.com → real A records. A block and a
  non-existent name are both answerless; only the Authority SOA's MNAME tells them apart.
- Considered and not taken: Mullvad base / AdGuard (also block ads → harmless ad domains would score as malware);
  OpenDNS (left France in 2024); dns0.eu (closed 2025).

### Detection (protection/DnsThreatProtection.js)
- parseDnsResponse now also reads the Authority section and returns `authoritySoas: [{ owner, mname }]`
  (lower-case, no trailing dot; SOA = type 6, `DNS.TYPE_SOA`). Guard: the section is supplementary — a
  truncated/malformed Authority section stops collection (collectAuthoritySoas in try/catch) without discarding
  the answers/rcode already parsed; an unreadable section can never yield BLOCKED.
- RPZ_SOA: BLOCKED when there is no usable answer and an SOA MNAME equals or ends on a label boundary with
  `rpzSoaMnameSuffix` (so "evilrpz.noc.org" does not match); else NXDOMAIN → UNKNOWN/NXDOMAIN. Missing/empty
  suffix → never BLOCKED (fail open).
- BLOCKPAGE_IP: BLOCKED when an answer is in `blockPageIps` or is 0.0.0.0 / ::. Other styles ignore both lists.
- If a provider moves its block page / policy zone, blocks fall through as ALLOWED (neutral), never a false
  "Confirmed malicious" — update the constant.

### Region defaults (util/DnsDefaults.js, new)
- `APP.DNS_REGION_DEFAULTS`: rule FR → first `controld`, second `cloudflare`; time zones Europe/Paris + overseas
  (Cayenne, Guadeloupe, Martinique, Marigot, St_Barthelemy, Miquelon, Reunion, Mayotte, Kerguelen, Tahiti,
  Marquesas, Gambier, Noumea, Wallis). Europe/Monaco deliberately excluded.
- DnsDefaults.get() detects the IANA zone offline (Intl; no network, no permission), caches a frozen
  { first, second, region }; reset() clears the cache; resolveForTimeZone(tz) is pure. Every failure (Intl
  throwing, unknown zone, a rule naming a removed provider or an optional-permission provider) → the global
  APP.DEFAULT_DNS_FIRST / _SECOND (quad9 / controld, unchanged).
- All former direct reads of APP.DEFAULT_DNS_* now go through DnsDefaults: Settings.js defaultSettings,
  background.js buildSettingsSnapshot (validDnsProviderId fallback), BrowserProtection.checkHostReputation,
  OptionsPage.js (load + Save All guard).
- Known limitation: Settings.set persists the full merged object, so a user who ever saved any setting has the
  old defaults stored and keeps Quad9 — no migration (offered to the user, not requested).

### Optional host permissions (util/DnsPermissions.js, new)
- Providers with `optionalPermission: true` (dns4eu, cleanbrowsing) are in manifest `optional_host_permissions`,
  not `host_permissions`, so the 3.3.0 → 3.3.1 update triggers no Chrome re-approval (a new required host would
  disable the extension until approved).
- Lifecycle: OptionsPage requests the origin synchronously in the dropdown's change handler (user gesture kept;
  declined → dropdown reverts to its previous value, message in #dnsStatus); after each save,
  releaseUnused([first, second]) removes grants no slot uses. On Options load, a selected provider without its
  grant shows a notice.
- DnsThreatProtection.check: optional provider without grant → no fetch, UNKNOWN with new reason code
  `PERMISSION_MISSING`; WarningPage DNS_UNKNOWN_TEXT: "not checked — permission not granted (allow it in Options)".
- Every DnsPermissions function guards a missing chrome.permissions and never throws (failure = not granted).

### UI
- OptionsPage.html DNS section shortened (user: text too long): heading "Threat-intel DNS — two of five"; one-line
  intro; "Pick two you do not already use as your own DNS — that one already blocks bad sites."; NextDNS
  "Block Bypass Methods" hint reduced to one sentence + "check unavailable, never as safe". No France note in
  the UI (the default simply applies). Dropdown entries come from APP.DNS_PROVIDERS as before.

### Manifest / versions
- manifest.json 3.3.0 → 3.3.1; optional_host_permissions: protective.joindns4.eu, doh.cleanbrowsing.org.
- TOOLS package.json 3.3.0 → 3.3.1.

### Tests (TOOLS)
- 410 → 442, all passing (also with TZ=Europe/Paris). New: tests/DnsDefaults.test.js (regions, fallbacks, cache,
  manifest ↔ provider consistency, no optional provider as a region default), tests/DnsPermissions.test.js.
  DnsThreatProtection.test.js: dns4eu and cleanbrowsing suites from the live-observed records, truncated
  Authority section, look-alike MNAME, permission guard. Fixture builder takes real Authority SOA records.
- helpers/chromeMock.js: chrome.permissions mock (contains/request/remove) with init/clear/release
  + setGrantedOrigins().
- eslint clean; check-magic-numbers unchanged vs 3.3.0 (38 lines, all pre-existing); no circular imports;
  knip: only the pre-existing AGE_NA.

### Not verified here
- The Chrome permission prompt itself (no real Chrome in the build environment).
- DoH endpoints directly (build environment cannot reach DNS servers); verification used the same profiles'
  plain-DNS addresses. Check once in the browser: a download from malware.wicar.org.

### For 3P Matrix
- When 3P Matrix moves to DS 3.3.1: SPEC_levels_and_protections.md lists three DNS providers (lines ~134–136) —
  add DNS4EU and CleanBrowsing with their block styles; its own core/online-checks.js DNS code (two
  implementations kept, 4.3.4 item 21) needs the same RPZ_SOA / BLOCKPAGE_IP handling and the France default
  if it should match.
