# Changelog — DownloadSentinel

Short, per-release summary of what changed. The full technical account is CHANGELOG_HISTORY.md.

## 3.3.1
- **Two new DNS checks: DNS4EU Protective and CleanBrowsing Security** (both free, malware and phishing only).
  The DNS checks now offer **two of five**: Quad9, Cloudflare Security, Control D, DNS4EU, CleanBrowsing.
- **In France the default is now Control D + Cloudflare Security (1.1.1.2)** instead of Quad9 + Control D.
  A DNS choice you saved is never changed.
- Options: shorter DNS text.
- DNS4EU and CleanBrowsing **ask for permission only when you pick them** — updating needs no new approval.
  The permission is dropped again when neither DNS check uses them. If it is missing, the warning page says
  "not checked — permission not granted", never "safe".
- Note: DNS4EU also applies court-ordered blocks (e.g. piracy sites); such a site can show as blocked too.
