"use strict";

/**
 * GovSuffixes.default.js — GENERATED FILE. Do not hand-edit; run
 * `node tools/gen-data-defaults.mjs` to regenerate from the single source
 * of truth, EXTENSION/data/GovSuffixes.json.
 *
 * This is the bundled/offline default: compiled into the reviewed CWS
 * package so GovSuffixes always has a safe starting value even before
 * util/FilterDataLoader.js ever attempts a remote fetch, and whenever that
 * fetch fails, is unavailable, or returns malformed data.
 *
 * Generated: 2026-10-20T12:31:24.720Z
 */
export const GovSuffixesDefault = [
    "gob.mx",
    "gov.br",
    "gov.gr",
    "gov.kr",
    "gov.pl",
    "gov.uk"
];
