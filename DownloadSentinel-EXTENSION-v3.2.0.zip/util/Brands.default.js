"use strict";

/**
 * Brands.default.js — GENERATED FILE. Do not hand-edit; run
 * `node tools/gen-data-defaults.mjs` to regenerate from the single source
 * of truth, EXTENSION/data/Brands.json.
 *
 * This is the bundled/offline default: compiled into the reviewed CWS
 * package so Brands always has a safe starting value even before
 * util/FilterDataLoader.js ever attempts a remote fetch, and whenever that
 * fetch fails, is unavailable, or returns malformed data.
 *
 * Generated: 2026-10-20T12:31:24.719Z
 */
export const BrandsDefault = [
    {
        "keyword": "7eleven",
        "domains": [
            "7-eleven.com"
        ]
    },
    {
        "keyword": "abnamro",
        "domains": [
            "abnamro.nl"
        ]
    },
    {
        "keyword": "adidas",
        "domains": [
            "adidas.com"
        ]
    },
    {
        "keyword": "adobe",
        "domains": [
            "adobe.com"
        ]
    },
    {
        "keyword": "aeon",
        "domains": [
            "aeon.co.jp"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "afterpay",
        "domains": [
            "afterpay.com"
        ]
    },
    {
        "keyword": "agenciatributaria",
        "domains": [
            "agenciatributaria.gob.es"
        ]
    },
    {
        "keyword": "agenziaentrate",
        "domains": [
            "agenziaentrate.gov.it"
        ]
    },
    {
        "keyword": "ah",
        "domains": [
            "ah.nl"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "aib",
        "domains": [
            "aib.ie"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "airbnb",
        "domains": [
            "airbnb.com"
        ]
    },
    {
        "keyword": "albertsons",
        "domains": [
            "albertsons.com"
        ]
    },
    {
        "keyword": "aldi",
        "domains": [
            "aldi.co.uk",
            "aldi.com",
            "aldi.com.au",
            "aldi.nl",
            "aldi.us"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "aldinord",
        "domains": [
            "aldi-nord.de"
        ]
    },
    {
        "keyword": "aldisued",
        "domains": [
            "aldi-sued.de"
        ]
    },
    {
        "keyword": "allegro",
        "domains": [
            "allegro.pl"
        ]
    },
    {
        "keyword": "alpha",
        "domains": [
            "alpha.gr"
        ]
    },
    {
        "keyword": "amazon",
        "domains": [
            "amazon.com"
        ]
    },
    {
        "keyword": "amd",
        "domains": [
            "amd.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "ameli",
        "domains": [
            "ameli.fr"
        ]
    },
    {
        "keyword": "americaneagle",
        "domains": [
            "ae.com"
        ]
    },
    {
        "keyword": "americanexpress",
        "domains": [
            "americanexpress.com"
        ]
    },
    {
        "keyword": "anaf",
        "domains": [
            "anaf.ro"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "anpost",
        "domains": [
            "anpost.com"
        ]
    },
    {
        "keyword": "ants",
        "domains": [
            "ants.gouv.fr"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "anz",
        "domains": [
            "anz.co.nz",
            "anz.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "apple",
        "domains": [
            "apple.com"
        ]
    },
    {
        "keyword": "arca",
        "domains": [
            "arca.gob.ar"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "argenta",
        "domains": [
            "argenta.be"
        ]
    },
    {
        "keyword": "arionbanki",
        "domains": [
            "arionbanki.is"
        ]
    },
    {
        "keyword": "asb",
        "domains": [
            "asb.co.nz"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "asda",
        "domains": [
            "asda.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "asnbank",
        "domains": [
            "asnbank.nl"
        ]
    },
    {
        "keyword": "assai",
        "domains": [
            "assai.com.br"
        ]
    },
    {
        "keyword": "atacadao",
        "domains": [
            "atacadao.com.br"
        ]
    },
    {
        "keyword": "ato",
        "domains": [
            "ato.gov.au"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "att",
        "domains": [
            "att.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "au",
        "domains": [
            "au.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "audi",
        "domains": [
            "audi.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "auspost",
        "domains": [
            "auspost.com.au"
        ]
    },
    {
        "keyword": "banamex",
        "domains": [
            "banamex.com"
        ]
    },
    {
        "keyword": "bancatransilvania",
        "domains": [
            "bancatransilvania.ro"
        ]
    },
    {
        "keyword": "bancoagricola",
        "domains": [
            "bancoagricola.com"
        ]
    },
    {
        "keyword": "bancobcr",
        "domains": [
            "bancobcr.com"
        ]
    },
    {
        "keyword": "bancobpm",
        "domains": [
            "bancobpm.it"
        ]
    },
    {
        "keyword": "bancochile",
        "domains": [
            "bancochile.cl"
        ]
    },
    {
        "keyword": "bancodevenezuela",
        "domains": [
            "bancodevenezuela.com"
        ]
    },
    {
        "keyword": "bancoestado",
        "domains": [
            "bancoestado.cl"
        ]
    },
    {
        "keyword": "bancogalicia",
        "domains": [
            "bancogalicia.com.ar"
        ]
    },
    {
        "keyword": "bancointer",
        "domains": [
            "bancointer.com.br"
        ]
    },
    {
        "keyword": "bancolombia",
        "domains": [
            "bancolombia.com"
        ]
    },
    {
        "keyword": "bancosantander",
        "domains": [
            "bancosantander.es"
        ]
    },
    {
        "keyword": "bancsabadell",
        "domains": [
            "bancsabadell.com"
        ]
    },
    {
        "keyword": "banistmo",
        "domains": [
            "banistmo.com"
        ]
    },
    {
        "keyword": "bankid",
        "domains": [
            "bankid.com"
        ]
    },
    {
        "keyword": "bankinter",
        "domains": [
            "bankinter.com"
        ]
    },
    {
        "keyword": "bankofamerica",
        "domains": [
            "bankofamerica.com"
        ]
    },
    {
        "keyword": "bankofcyprus",
        "domains": [
            "bankofcyprus.com"
        ]
    },
    {
        "keyword": "bankofireland",
        "domains": [
            "bankofireland.com"
        ]
    },
    {
        "keyword": "banorte",
        "domains": [
            "banorte.com"
        ]
    },
    {
        "keyword": "banreservas",
        "domains": [
            "banreservas.com"
        ]
    },
    {
        "keyword": "banrural",
        "domains": [
            "banrural.com.gt"
        ]
    },
    {
        "keyword": "barclays",
        "domains": [
            "barclays.co.uk"
        ]
    },
    {
        "keyword": "baskinrobbins",
        "domains": [
            "baskinrobbins.com"
        ]
    },
    {
        "keyword": "bathandbodyworks",
        "domains": [
            "bathandbodyworks.com"
        ]
    },
    {
        "keyword": "bawag",
        "domains": [
            "bawag.at"
        ]
    },
    {
        "keyword": "bb",
        "domains": [
            "bb.com.br"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "bbva",
        "domains": [
            "bbva.com.ar",
            "bbva.es",
            "bbva.mx",
            "bbva.pe"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "bcr",
        "domains": [
            "bcr.ro"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "belastingdienst",
        "domains": [
            "belastingdienst.nl"
        ]
    },
    {
        "keyword": "belfius",
        "domains": [
            "belfius.be"
        ]
    },
    {
        "keyword": "bell",
        "domains": [
            "bell.ca"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "bestbuy",
        "domains": [
            "bestbuy.com"
        ]
    },
    {
        "keyword": "bgeneral",
        "domains": [
            "bgeneral.com"
        ]
    },
    {
        "keyword": "bi",
        "domains": [
            "bi.com.gt"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "biedronka",
        "domains": [
            "biedronka.pl"
        ]
    },
    {
        "keyword": "bil",
        "domains": [
            "bil.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "billa",
        "domains": [
            "billa.at"
        ]
    },
    {
        "keyword": "binance",
        "domains": [
            "binance.com"
        ]
    },
    {
        "keyword": "bk",
        "domains": [
            "bk.mufg.jp"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "blackrock",
        "domains": [
            "blackrock.com"
        ]
    },
    {
        "keyword": "bmf",
        "domains": [
            "bmf.gv.at"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "bmo",
        "domains": [
            "bmo.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "bmw",
        "domains": [
            "bmw.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "bna",
        "domains": [
            "bna.com.ar"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "bncr",
        "domains": [
            "bncr.fi.cr"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "bnpparibas",
        "domains": [
            "bnpparibas"
        ]
    },
    {
        "keyword": "bnpparibasfortis",
        "domains": [
            "bnpparibasfortis.be"
        ]
    },
    {
        "keyword": "bnz",
        "domains": [
            "bnz.co.nz"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "bol",
        "domains": [
            "bol.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "booking.com",
        "domains": [
            "booking.com"
        ]
    },
    {
        "keyword": "borger",
        "domains": [
            "borger.dk"
        ]
    },
    {
        "keyword": "bose",
        "domains": [
            "bose.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "boursobank",
        "domains": [
            "boursobank.com"
        ]
    },
    {
        "keyword": "bouyguestelecom",
        "domains": [
            "bouyguestelecom.fr"
        ]
    },
    {
        "keyword": "bov",
        "domains": [
            "bov.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "bpost",
        "domains": [
            "bpost.be"
        ]
    },
    {
        "keyword": "bradesco",
        "domains": [
            "bradesco.com.br"
        ]
    },
    {
        "keyword": "brou",
        "domains": [
            "brou.com.uy"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "bt",
        "domains": [
            "bt.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "budbee",
        "domains": [
            "budbee.com"
        ]
    },
    {
        "keyword": "bungie",
        "domains": [
            "bungie.net"
        ]
    },
    {
        "keyword": "bunq",
        "domains": [
            "bunq.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "byd",
        "domains": [
            "byd.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "caisseepargne",
        "domains": [
            "caisse-epargne.fr"
        ]
    },
    {
        "keyword": "caixa",
        "domains": [
            "caixa.gov.br"
        ]
    },
    {
        "keyword": "caixabank",
        "domains": [
            "caixabank.es"
        ]
    },
    {
        "keyword": "calottery",
        "domains": [
            "calottery.com"
        ]
    },
    {
        "keyword": "canada",
        "domains": [
            "canada.ca"
        ]
    },
    {
        "keyword": "canadapostpostescanada",
        "domains": [
            "canadapost-postescanada.ca"
        ]
    },
    {
        "keyword": "capitalone",
        "domains": [
            "capitalone.com"
        ]
    },
    {
        "keyword": "carrefour",
        "domains": [
            "carrefour.com",
            "carrefour.com.br",
            "carrefour.es",
            "carrefour.fr",
            "carrefour.it"
        ]
    },
    {
        "keyword": "cash",
        "domains": [
            "cash.app"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "cdiscount",
        "domains": [
            "cdiscount.com"
        ]
    },
    {
        "keyword": "ceskaposta",
        "domains": [
            "ceskaposta.cz"
        ]
    },
    {
        "keyword": "cgd",
        "domains": [
            "cgd.pt"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "chanel",
        "domains": [
            "chanel.com"
        ]
    },
    {
        "keyword": "chase",
        "domains": [
            "chase.com"
        ]
    },
    {
        "keyword": "chedraui",
        "domains": [
            "chedraui.com.mx"
        ]
    },
    {
        "keyword": "chickfila",
        "domains": [
            "chick-fil-a.com"
        ]
    },
    {
        "keyword": "chipotle",
        "domains": [
            "chipotle.com"
        ]
    },
    {
        "keyword": "chronopost",
        "domains": [
            "chronopost.fr"
        ]
    },
    {
        "keyword": "cibc",
        "domains": [
            "cibc.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "cisco",
        "domains": [
            "cisco.com"
        ]
    },
    {
        "keyword": "citibank",
        "domains": [
            "citibank.com"
        ]
    },
    {
        "keyword": "cjib",
        "domains": [
            "cjib.nl"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "cjlogistics",
        "domains": [
            "cjlogistics.com"
        ]
    },
    {
        "keyword": "cocacola",
        "domains": [
            "coca-cola.com"
        ]
    },
    {
        "keyword": "coinbase",
        "domains": [
            "coinbase.com"
        ]
    },
    {
        "keyword": "coles",
        "domains": [
            "coles.com.au"
        ]
    },
    {
        "keyword": "colgate",
        "domains": [
            "colgate.com"
        ]
    },
    {
        "keyword": "colruyt",
        "domains": [
            "colruyt.be"
        ]
    },
    {
        "keyword": "comdirect",
        "domains": [
            "comdirect.de"
        ]
    },
    {
        "keyword": "commbank",
        "domains": [
            "commbank.com.au"
        ]
    },
    {
        "keyword": "commerzbank",
        "domains": [
            "commerzbank.de"
        ]
    },
    {
        "keyword": "conad",
        "domains": [
            "conad.it"
        ]
    },
    {
        "keyword": "continente",
        "domains": [
            "continente.pt"
        ]
    },
    {
        "keyword": "coolblue",
        "domains": [
            "coolblue.nl"
        ]
    },
    {
        "keyword": "coop",
        "domains": [
            "coop.ch",
            "coop.co.uk",
            "coop.it"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "correios",
        "domains": [
            "correios.com.br"
        ]
    },
    {
        "keyword": "correos",
        "domains": [
            "correos.es",
            "correos.go.cr"
        ]
    },
    {
        "keyword": "costco",
        "domains": [
            "costco.ca",
            "costco.com"
        ]
    },
    {
        "keyword": "coto",
        "domains": [
            "coto.com.ar"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "coupang",
        "domains": [
            "coupang.com"
        ]
    },
    {
        "keyword": "creditagricole",
        "domains": [
            "credit-agricole.fr"
        ]
    },
    {
        "keyword": "crocs",
        "domains": [
            "crocs.com"
        ]
    },
    {
        "keyword": "csas",
        "domains": [
            "csas.cz"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "csob",
        "domains": [
            "csob.cz"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "ctt",
        "domains": [
            "ctt.pt"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "danskebank",
        "domains": [
            "danskebank.dk"
        ]
    },
    {
        "keyword": "davivienda",
        "domains": [
            "davivienda.com"
        ]
    },
    {
        "keyword": "delhaize",
        "domains": [
            "delhaize.be"
        ]
    },
    {
        "keyword": "desjardins",
        "domains": [
            "desjardins.com"
        ]
    },
    {
        "keyword": "deutschebank",
        "domains": [
            "deutsche-bank.de"
        ]
    },
    {
        "keyword": "deutschepost",
        "domains": [
            "deutschepost.de"
        ]
    },
    {
        "keyword": "dhl",
        "domains": [
            "dhl.com",
            "dhl.de"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "dhlottery",
        "domains": [
            "dhlottery.co.kr"
        ]
    },
    {
        "keyword": "dia",
        "domains": [
            "dia.es"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "dian",
        "domains": [
            "dian.gov.co"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "diaonline",
        "domains": [
            "diaonline.supermercadosdia.com.ar"
        ]
    },
    {
        "keyword": "digid",
        "domains": [
            "digid.nl"
        ]
    },
    {
        "keyword": "diia",
        "domains": [
            "diia.gov.ua"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "dior",
        "domains": [
            "dior.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "dirk",
        "domains": [
            "dirk.nl"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "discover",
        "domains": [
            "discover.com"
        ]
    },
    {
        "keyword": "dkb",
        "domains": [
            "dkb.de"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "dnb",
        "domains": [
            "dnb.no"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "docomo",
        "domains": [
            "docomo.ne.jp"
        ]
    },
    {
        "keyword": "docusign",
        "domains": [
            "docusign.com"
        ]
    },
    {
        "keyword": "dpd",
        "domains": [
            "dpd.com",
            "dpd.de"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "dropbox",
        "domains": [
            "dropbox.com"
        ]
    },
    {
        "keyword": "dskbank",
        "domains": [
            "dskbank.bg"
        ]
    },
    {
        "keyword": "dunkin",
        "domains": [
            "dunkin.com"
        ]
    },
    {
        "keyword": "dunnesstores",
        "domains": [
            "dunnesstores.com"
        ]
    },
    {
        "keyword": "duo",
        "domains": [
            "duo.nl"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "ebay",
        "domains": [
            "ebay.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "econt",
        "domains": [
            "econt.com"
        ]
    },
    {
        "keyword": "edeka",
        "domains": [
            "edeka.de"
        ]
    },
    {
        "keyword": "ee",
        "domains": [
            "ee.co.uk"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "eesti",
        "domains": [
            "eesti.ee"
        ]
    },
    {
        "keyword": "elcorteingles",
        "domains": [
            "elcorteingles.es"
        ]
    },
    {
        "keyword": "elster",
        "domains": [
            "elster.de"
        ]
    },
    {
        "keyword": "elta",
        "domains": [
            "elta.gr"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "emag",
        "domains": [
            "emag.ro"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "eneco",
        "domains": [
            "eneco.nl"
        ]
    },
    {
        "keyword": "epost",
        "domains": [
            "epost.go.kr"
        ]
    },
    {
        "keyword": "erste",
        "domains": [
            "erste.pl"
        ]
    },
    {
        "keyword": "esselunga",
        "domains": [
            "esselunga.it"
        ]
    },
    {
        "keyword": "essent",
        "domains": [
            "essent.nl"
        ]
    },
    {
        "keyword": "etcmeisai",
        "domains": [
            "etc-meisai.jp"
        ]
    },
    {
        "keyword": "eurobank",
        "domains": [
            "eurobank.gr"
        ]
    },
    {
        "keyword": "euromillions",
        "domains": [
            "euro-millions.com"
        ]
    },
    {
        "keyword": "evri",
        "domains": [
            "evri.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "exito",
        "domains": [
            "exito.com"
        ]
    },
    {
        "keyword": "facebook",
        "domains": [
            "facebook.com"
        ]
    },
    {
        "keyword": "fdj",
        "domains": [
            "fdj.fr"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "fedex",
        "domains": [
            "fedex.com"
        ]
    },
    {
        "keyword": "ferrari",
        "domains": [
            "ferrari.com"
        ]
    },
    {
        "keyword": "ficohsa",
        "domains": [
            "ficohsa.com"
        ]
    },
    {
        "keyword": "finecobank",
        "domains": [
            "finecobank.com"
        ]
    },
    {
        "keyword": "fnac",
        "domains": [
            "fnac.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "foodlion",
        "domains": [
            "foodlion.com"
        ]
    },
    {
        "keyword": "footlocker",
        "domains": [
            "footlocker.com"
        ]
    },
    {
        "keyword": "franceconnect",
        "domains": [
            "franceconnect.gouv.fr"
        ]
    },
    {
        "keyword": "free",
        "domains": [
            "free.fr"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "geaerospace",
        "domains": [
            "geaerospace.com"
        ]
    },
    {
        "keyword": "glossier",
        "domains": [
            "glossier.com"
        ]
    },
    {
        "keyword": "glsgroup",
        "domains": [
            "gls-group.com"
        ]
    },
    {
        "keyword": "glsinfo",
        "domains": [
            "gls-info.nl"
        ]
    },
    {
        "keyword": "gmail",
        "domains": [
            "gmail.com"
        ]
    },
    {
        "keyword": "google",
        "domains": [
            "google.com"
        ]
    },
    {
        "keyword": "googledrive",
        "domains": [
            "drive.google.com"
        ]
    },
    {
        "keyword": "gucci",
        "domains": [
            "gucci.com"
        ]
    },
    {
        "keyword": "halifax",
        "domains": [
            "halifax.co.uk"
        ]
    },
    {
        "keyword": "hanabank",
        "domains": [
            "hanabank.com"
        ]
    },
    {
        "keyword": "handelsbanken",
        "domains": [
            "handelsbanken.se"
        ]
    },
    {
        "keyword": "headspace",
        "domains": [
            "headspace.com"
        ]
    },
    {
        "keyword": "heb",
        "domains": [
            "heb.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "hermes",
        "domains": [
            "hermes.com"
        ]
    },
    {
        "keyword": "hermesworld",
        "domains": [
            "hermesworld.com"
        ]
    },
    {
        "keyword": "hersheys",
        "domains": [
            "hersheys.com"
        ]
    },
    {
        "keyword": "hilton",
        "domains": [
            "hilton.com"
        ]
    },
    {
        "keyword": "homedepot",
        "domains": [
            "homedepot.com"
        ]
    },
    {
        "keyword": "hometax",
        "domains": [
            "hometax.go.kr"
        ]
    },
    {
        "keyword": "honda",
        "domains": [
            "honda.com"
        ]
    },
    {
        "keyword": "hsbc",
        "domains": [
            "hsbc.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "ica",
        "domains": [
            "ica.se"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "iceland",
        "domains": [
            "iceland.co.uk"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "icloud",
        "domains": [
            "icloud.com"
        ]
    },
    {
        "keyword": "ideal",
        "domains": [
            "ideal.nl"
        ]
    },
    {
        "keyword": "impots",
        "domains": [
            "impots.gouv.fr"
        ]
    },
    {
        "keyword": "ing",
        "domains": [
            "ing.be",
            "ing.de",
            "ing.nl",
            "ing.pl"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "innoutburger",
        "domains": [
            "in-n-out.com"
        ]
    },
    {
        "keyword": "inpost",
        "domains": [
            "inpost.pl"
        ]
    },
    {
        "keyword": "inps",
        "domains": [
            "inps.it"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "instacart",
        "domains": [
            "instacart.com"
        ]
    },
    {
        "keyword": "instagram",
        "domains": [
            "instagram.com"
        ]
    },
    {
        "keyword": "interac",
        "domains": [
            "interac.ca"
        ]
    },
    {
        "keyword": "interbank",
        "domains": [
            "interbank.pe"
        ]
    },
    {
        "keyword": "intesasanpaolo",
        "domains": [
            "intesasanpaolo.com"
        ]
    },
    {
        "keyword": "ird",
        "domains": [
            "ird.govt.nz"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "irs",
        "domains": [
            "irs.gov"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "island",
        "domains": [
            "island.is"
        ]
    },
    {
        "keyword": "islandsbanki",
        "domains": [
            "islandsbanki.is"
        ]
    },
    {
        "keyword": "itau",
        "domains": [
            "itau.com.br",
            "itau.com.py"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "itsmeid",
        "domains": [
            "itsme-id.com"
        ]
    },
    {
        "keyword": "japanpost",
        "domains": [
            "japanpost.jp"
        ]
    },
    {
        "keyword": "jcb",
        "domains": [
            "jcb.co.jp"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "johndeere",
        "domains": [
            "johndeere.com"
        ]
    },
    {
        "keyword": "johnsonjohnson",
        "domains": [
            "jnj.com"
        ]
    },
    {
        "keyword": "jpbank",
        "domains": [
            "jp-bank.japanpost.jp"
        ]
    },
    {
        "keyword": "jpmorganchase",
        "domains": [
            "jpmorganchase.com"
        ]
    },
    {
        "keyword": "jumbo",
        "domains": [
            "jumbo.cl",
            "jumbo.com"
        ]
    },
    {
        "keyword": "kakao",
        "domains": [
            "kakao.com"
        ]
    },
    {
        "keyword": "kakaobank",
        "domains": [
            "kakaobank.com"
        ]
    },
    {
        "keyword": "kaufland",
        "domains": [
            "kaufland.de"
        ]
    },
    {
        "keyword": "kb",
        "domains": [
            "kb.cz"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "kbc",
        "domains": [
            "kbc.be"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "kbstar",
        "domains": [
            "kbstar.com"
        ]
    },
    {
        "keyword": "kiwibank",
        "domains": [
            "kiwibank.co.nz"
        ]
    },
    {
        "keyword": "klarna",
        "domains": [
            "klarna.com"
        ]
    },
    {
        "keyword": "knab",
        "domains": [
            "knab.nl"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "kpn",
        "domains": [
            "kpn.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "kroger",
        "domains": [
            "kroger.com"
        ]
    },
    {
        "keyword": "kruoka",
        "domains": [
            "k-ruoka.fi"
        ]
    },
    {
        "keyword": "kt",
        "domains": [
            "kt.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "kuronekoyamato",
        "domains": [
            "kuronekoyamato.co.jp"
        ]
    },
    {
        "keyword": "labanquepostale",
        "domains": [
            "labanquepostale.fr"
        ]
    },
    {
        "keyword": "laposte",
        "domains": [
            "laposte.fr"
        ]
    },
    {
        "keyword": "latvija",
        "domains": [
            "latvija.gov.lv"
        ]
    },
    {
        "keyword": "lcl",
        "domains": [
            "lcl.fr"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "leboncoin",
        "domains": [
            "leboncoin.fr"
        ]
    },
    {
        "keyword": "leclerc",
        "domains": [
            "leclerc"
        ]
    },
    {
        "keyword": "lego",
        "domains": [
            "lego.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "lguplus",
        "domains": [
            "lguplus.com"
        ]
    },
    {
        "keyword": "lhv",
        "domains": [
            "lhv.ee"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "lider",
        "domains": [
            "lider.cl"
        ]
    },
    {
        "keyword": "lidl",
        "domains": [
            "lidl.co.uk",
            "lidl.com",
            "lidl.de",
            "lidl.nl"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "linkedin",
        "domains": [
            "linkedin.com"
        ]
    },
    {
        "keyword": "linkt",
        "domains": [
            "linkt.com.au"
        ]
    },
    {
        "keyword": "lloydsbank",
        "domains": [
            "lloydsbank.com"
        ]
    },
    {
        "keyword": "loblaws",
        "domains": [
            "loblaws.ca"
        ]
    },
    {
        "keyword": "logitech",
        "domains": [
            "logitech.com"
        ]
    },
    {
        "keyword": "loterias",
        "domains": [
            "loterias.caixa.gov.br"
        ]
    },
    {
        "keyword": "loteriasyapuestas",
        "domains": [
            "loteriasyapuestas.es"
        ]
    },
    {
        "keyword": "lotteon",
        "domains": [
            "lotteon.com"
        ]
    },
    {
        "keyword": "lotto",
        "domains": [
            "lotto.de"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "lottomatica",
        "domains": [
            "lottomatica.it"
        ]
    },
    {
        "keyword": "louisvuitton",
        "domains": [
            "louisvuitton.com"
        ]
    },
    {
        "keyword": "lvmh",
        "domains": [
            "lvmh.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "maccosmetics",
        "domains": [
            "maccosmetics.com"
        ]
    },
    {
        "keyword": "magazineluiza",
        "domains": [
            "magazineluiza.com.br"
        ]
    },
    {
        "keyword": "maltapost",
        "domains": [
            "maltapost.com"
        ]
    },
    {
        "keyword": "marktplaats",
        "domains": [
            "marktplaats.nl"
        ]
    },
    {
        "keyword": "marriott",
        "domains": [
            "marriott.com"
        ]
    },
    {
        "keyword": "mastercard",
        "domains": [
            "mastercard.com"
        ]
    },
    {
        "keyword": "mbank",
        "domains": [
            "mbank.pl"
        ]
    },
    {
        "keyword": "mbway",
        "domains": [
            "mbway.pt"
        ]
    },
    {
        "keyword": "mcdonalds",
        "domains": [
            "mcdonalds.com"
        ]
    },
    {
        "keyword": "megamillions",
        "domains": [
            "megamillions.com"
        ]
    },
    {
        "keyword": "meijer",
        "domains": [
            "meijer.com"
        ]
    },
    {
        "keyword": "mercadolibre",
        "domains": [
            "mercadolibre.com.mx"
        ]
    },
    {
        "keyword": "mercadolivre",
        "domains": [
            "mercadolivre.com.br"
        ]
    },
    {
        "keyword": "mercadona",
        "domains": [
            "mercadona.es"
        ]
    },
    {
        "keyword": "mercadopago",
        "domains": [
            "mercadopago.com.ar"
        ]
    },
    {
        "keyword": "mercari",
        "domains": [
            "mercari.com"
        ]
    },
    {
        "keyword": "mercedes",
        "domains": [
            "mercedes-benz.com"
        ]
    },
    {
        "keyword": "meta",
        "domains": [
            "meta.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "metro",
        "domains": [
            "metro.ca"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "microsoft",
        "domains": [
            "microsoft.com"
        ]
    },
    {
        "keyword": "migros",
        "domains": [
            "migros.ch"
        ]
    },
    {
        "keyword": "millenniumbcp",
        "domains": [
            "millenniumbcp.pt"
        ]
    },
    {
        "keyword": "mitid",
        "domains": [
            "mitid.dk"
        ]
    },
    {
        "keyword": "mizuhobank",
        "domains": [
            "mizuhobank.co.jp"
        ]
    },
    {
        "keyword": "mobilepay",
        "domains": [
            "mobilepay.dk"
        ]
    },
    {
        "keyword": "monobank",
        "domains": [
            "monobank.ua"
        ]
    },
    {
        "keyword": "monsterenergy",
        "domains": [
            "monsterenergy.com"
        ]
    },
    {
        "keyword": "monzo",
        "domains": [
            "monzo.com"
        ]
    },
    {
        "keyword": "morrisons",
        "domains": [
            "morrisons.com"
        ]
    },
    {
        "keyword": "movistar",
        "domains": [
            "movistar.es"
        ]
    },
    {
        "keyword": "my",
        "domains": [
            "my.gov.au"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "myhermes",
        "domains": [
            "myhermes.de"
        ]
    },
    {
        "keyword": "mylotto",
        "domains": [
            "mylotto.co.nz"
        ]
    },
    {
        "keyword": "n26",
        "domains": [
            "n26.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "nab",
        "domains": [
            "nab.com.au"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "nasdaq",
        "domains": [
            "nasdaq.com"
        ]
    },
    {
        "keyword": "nationalgeographic",
        "domains": [
            "nationalgeographic.com"
        ]
    },
    {
        "keyword": "nationallottery",
        "domains": [
            "national-lottery.co.uk"
        ]
    },
    {
        "keyword": "nationwide",
        "domains": [
            "nationwide.co.uk"
        ]
    },
    {
        "keyword": "natwest",
        "domains": [
            "natwest.com"
        ]
    },
    {
        "keyword": "naver",
        "domains": [
            "naver.com"
        ]
    },
    {
        "keyword": "nbg",
        "domains": [
            "nbg.gr"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "nederlandseloterij",
        "domains": [
            "nederlandseloterij.nl"
        ]
    },
    {
        "keyword": "nequi",
        "domains": [
            "nequi.com.co"
        ]
    },
    {
        "keyword": "netflix",
        "domains": [
            "netflix.com"
        ]
    },
    {
        "keyword": "netto",
        "domains": [
            "netto.dk"
        ]
    },
    {
        "keyword": "newworld",
        "domains": [
            "newworld.co.nz"
        ]
    },
    {
        "keyword": "nintendo",
        "domains": [
            "nintendo.com"
        ]
    },
    {
        "keyword": "nlb",
        "domains": [
            "nlb.si"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "nofrills",
        "domains": [
            "nofrills.ca"
        ]
    },
    {
        "keyword": "nonghyup",
        "domains": [
            "nonghyup.com"
        ]
    },
    {
        "keyword": "nordea",
        "domains": [
            "nordea.fi",
            "nordea.se"
        ]
    },
    {
        "keyword": "nordstrom",
        "domains": [
            "nordstrom.com"
        ]
    },
    {
        "keyword": "novaposhta",
        "domains": [
            "novaposhta.ua"
        ]
    },
    {
        "keyword": "novobanco",
        "domains": [
            "novobanco.pt"
        ]
    },
    {
        "keyword": "ns",
        "domains": [
            "ns.nl"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "nta",
        "domains": [
            "nta.go.jp"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "nubank",
        "domains": [
            "nubank.com.br"
        ]
    },
    {
        "keyword": "nvidia",
        "domains": [
            "nvidia.com"
        ]
    },
    {
        "keyword": "nzpost",
        "domains": [
            "nzpost.co.nz"
        ]
    },
    {
        "keyword": "nzta",
        "domains": [
            "nzta.govt.nz"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "o2online",
        "domains": [
            "o2online.de"
        ]
    },
    {
        "keyword": "ocado",
        "domains": [
            "ocado.com"
        ]
    },
    {
        "keyword": "odido",
        "domains": [
            "odido.nl"
        ]
    },
    {
        "keyword": "oesterreich",
        "domains": [
            "oesterreich.gv.at"
        ]
    },
    {
        "keyword": "office",
        "domains": [
            "office.com"
        ]
    },
    {
        "keyword": "omniva",
        "domains": [
            "omniva.ee"
        ]
    },
    {
        "keyword": "one",
        "domains": [
            "one.nz"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "onedrive",
        "domains": [
            "onedrive.com"
        ]
    },
    {
        "keyword": "op",
        "domains": [
            "op.fi"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "optus",
        "domains": [
            "optus.com.au"
        ]
    },
    {
        "keyword": "orange",
        "domains": [
            "orange.fr"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "otpbank",
        "domains": [
            "otpbank.hu"
        ]
    },
    {
        "keyword": "otto",
        "domains": [
            "otto.de"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "outlook",
        "domains": [
            "outlook.com"
        ]
    },
    {
        "keyword": "overheid",
        "domains": [
            "overheid.nl"
        ]
    },
    {
        "keyword": "oxxo",
        "domains": [
            "oxxo.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "paknsave",
        "domains": [
            "paknsave.co.nz"
        ]
    },
    {
        "keyword": "paodeacucar",
        "domains": [
            "paodeacucar.com"
        ]
    },
    {
        "keyword": "paypal",
        "domains": [
            "paypal.com"
        ]
    },
    {
        "keyword": "paypay",
        "domains": [
            "paypay.ne.jp"
        ]
    },
    {
        "keyword": "pbz",
        "domains": [
            "pbz.hr"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "pcoptimum",
        "domains": [
            "pcoptimum.ca"
        ]
    },
    {
        "keyword": "pekao",
        "domains": [
            "pekao.com.pl"
        ]
    },
    {
        "keyword": "peloton",
        "domains": [
            "onepeloton.com"
        ]
    },
    {
        "keyword": "philips",
        "domains": [
            "philips.com"
        ]
    },
    {
        "keyword": "pichincha",
        "domains": [
            "pichincha.com"
        ]
    },
    {
        "keyword": "picnic",
        "domains": [
            "picnic.app"
        ]
    },
    {
        "keyword": "picpay",
        "domains": [
            "picpay.com"
        ]
    },
    {
        "keyword": "pingodoce",
        "domains": [
            "pingodoce.pt"
        ]
    },
    {
        "keyword": "pinterest",
        "domains": [
            "pinterest.com"
        ]
    },
    {
        "keyword": "piraeusbank",
        "domains": [
            "piraeusbank.gr"
        ]
    },
    {
        "keyword": "pkobp",
        "domains": [
            "pkobp.pl"
        ]
    },
    {
        "keyword": "playstation",
        "domains": [
            "playstation.com"
        ]
    },
    {
        "keyword": "plazavea",
        "domains": [
            "plazavea.com.pe"
        ]
    },
    {
        "keyword": "plus",
        "domains": [
            "plus.nl"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "pnc",
        "domains": [
            "pnc.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "pocztapolska",
        "domains": [
            "poczta-polska.pl"
        ]
    },
    {
        "keyword": "popularenlinea",
        "domains": [
            "popularenlinea.com"
        ]
    },
    {
        "keyword": "porsche",
        "domains": [
            "porsche.com"
        ]
    },
    {
        "keyword": "portaldasfinancas",
        "domains": [
            "portaldasfinancas.gov.pt"
        ]
    },
    {
        "keyword": "post",
        "domains": [
            "post.at",
            "post.ch",
            "post.lu"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "posta",
        "domains": [
            "posta.hr",
            "posta.hu",
            "posta.rs",
            "posta.si",
            "posta.sk"
        ]
    },
    {
        "keyword": "postaromana",
        "domains": [
            "posta-romana.ro"
        ]
    },
    {
        "keyword": "postbank",
        "domains": [
            "postbank.de"
        ]
    },
    {
        "keyword": "postcodeloterij",
        "domains": [
            "postcodeloterij.nl"
        ]
    },
    {
        "keyword": "poste",
        "domains": [
            "poste.it"
        ]
    },
    {
        "keyword": "posten",
        "domains": [
            "posten.no"
        ]
    },
    {
        "keyword": "postfinance",
        "domains": [
            "postfinance.ch"
        ]
    },
    {
        "keyword": "posti",
        "domains": [
            "posti.fi"
        ]
    },
    {
        "keyword": "postnl",
        "domains": [
            "postnl.nl"
        ]
    },
    {
        "keyword": "postnord",
        "domains": [
            "postnord.dk",
            "postnord.se"
        ]
    },
    {
        "keyword": "powerball",
        "domains": [
            "powerball.com"
        ]
    },
    {
        "keyword": "privatbank",
        "domains": [
            "privatbank.ua"
        ]
    },
    {
        "keyword": "proctergamble",
        "domains": [
            "pg.com"
        ]
    },
    {
        "keyword": "proximus",
        "domains": [
            "proximus.be"
        ]
    },
    {
        "keyword": "ptsb",
        "domains": [
            "ptsb.ie"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "publix",
        "domains": [
            "publix.com"
        ]
    },
    {
        "keyword": "puma",
        "domains": [
            "puma.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "qualcomm",
        "domains": [
            "qualcomm.com"
        ]
    },
    {
        "keyword": "rabobank",
        "domains": [
            "rabobank.nl"
        ]
    },
    {
        "keyword": "raiffeisen",
        "domains": [
            "raiffeisen.at",
            "raiffeisen.ch"
        ]
    },
    {
        "keyword": "rakuten",
        "domains": [
            "rakuten.co.jp"
        ]
    },
    {
        "keyword": "rakutencard",
        "domains": [
            "rakuten-card.co.jp"
        ]
    },
    {
        "keyword": "rbc",
        "domains": [
            "rbc.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "rdw",
        "domains": [
            "rdw.nl"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "realcanadiansuperstore",
        "domains": [
            "realcanadiansuperstore.ca"
        ]
    },
    {
        "keyword": "redbull",
        "domains": [
            "redbull.com"
        ]
    },
    {
        "keyword": "regiobank",
        "domains": [
            "regiobank.nl"
        ]
    },
    {
        "keyword": "rema",
        "domains": [
            "rema.no"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "revenue",
        "domains": [
            "revenue.ie"
        ]
    },
    {
        "keyword": "revolut",
        "domains": [
            "revolut.com"
        ]
    },
    {
        "keyword": "rewe",
        "domains": [
            "rewe.de"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "riotgames",
        "domains": [
            "riotgames.com"
        ]
    },
    {
        "keyword": "ritzcarlton",
        "domains": [
            "ritzcarlton.com"
        ]
    },
    {
        "keyword": "roblox",
        "domains": [
            "roblox.com"
        ]
    },
    {
        "keyword": "rogers",
        "domains": [
            "rogers.com"
        ]
    },
    {
        "keyword": "royalmail",
        "domains": [
            "royalmail.com"
        ]
    },
    {
        "keyword": "safeway",
        "domains": [
            "safeway.com"
        ]
    },
    {
        "keyword": "sagawaexp",
        "domains": [
            "sagawa-exp.co.jp"
        ]
    },
    {
        "keyword": "sainsburys",
        "domains": [
            "sainsburys.co.uk"
        ]
    },
    {
        "keyword": "saisoncard",
        "domains": [
            "saisoncard.co.jp"
        ]
    },
    {
        "keyword": "salling",
        "domains": [
            "salling.dk"
        ]
    },
    {
        "keyword": "santander",
        "domains": [
            "santander.cl",
            "santander.co.uk",
            "santander.com.ar",
            "santander.com.br",
            "santander.com.mx"
        ]
    },
    {
        "keyword": "sat",
        "domains": [
            "sat.gob.mx"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "satispay",
        "domains": [
            "satispay.com"
        ]
    },
    {
        "keyword": "schneiderelectric",
        "domains": [
            "se.com"
        ]
    },
    {
        "keyword": "scotiabank",
        "domains": [
            "scotiabank.com"
        ]
    },
    {
        "keyword": "seb",
        "domains": [
            "seb.lt",
            "seb.se"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "segsocial",
        "domains": [
            "seg-social.es"
        ]
    },
    {
        "keyword": "selae",
        "domains": [
            "selae.es"
        ]
    },
    {
        "keyword": "sephora",
        "domains": [
            "sephora.com"
        ]
    },
    {
        "keyword": "servicesaustralia",
        "domains": [
            "servicesaustralia.gov.au"
        ]
    },
    {
        "keyword": "sfr",
        "domains": [
            "sfr.fr"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "shinhan",
        "domains": [
            "shinhan.com"
        ]
    },
    {
        "keyword": "shopify",
        "domains": [
            "shopify.com"
        ]
    },
    {
        "keyword": "sii",
        "domains": [
            "sii.cl"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "skat",
        "domains": [
            "skat.dk"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "skatteetaten",
        "domains": [
            "skatteetaten.no"
        ]
    },
    {
        "keyword": "skatteverket",
        "domains": [
            "skatteverket.se"
        ]
    },
    {
        "keyword": "skaupat",
        "domains": [
            "s-kaupat.fi"
        ]
    },
    {
        "keyword": "slack",
        "domains": [
            "slack.com"
        ]
    },
    {
        "keyword": "slsp",
        "domains": [
            "slsp.sk"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "smbc",
        "domains": [
            "smbc.co.jp"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "snsbank",
        "domains": [
            "snsbank.nl"
        ]
    },
    {
        "keyword": "sobeys",
        "domains": [
            "sobeys.com"
        ]
    },
    {
        "keyword": "societegenerale",
        "domains": [
            "societegenerale.fr"
        ]
    },
    {
        "keyword": "softbank",
        "domains": [
            "softbank.jp"
        ]
    },
    {
        "keyword": "soriana",
        "domains": [
            "soriana.com"
        ]
    },
    {
        "keyword": "spar",
        "domains": [
            "spar.at"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "spark",
        "domains": [
            "spark.co.nz"
        ]
    },
    {
        "keyword": "sparkasse",
        "domains": [
            "sparkasse.at",
            "sparkasse.de"
        ]
    },
    {
        "keyword": "speedy",
        "domains": [
            "speedy.bg"
        ]
    },
    {
        "keyword": "spotify",
        "domains": [
            "spotify.com"
        ]
    },
    {
        "keyword": "spuerkeess",
        "domains": [
            "spuerkeess.lu"
        ]
    },
    {
        "keyword": "ssa",
        "domains": [
            "ssa.gov"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "ssg",
        "domains": [
            "ssg.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "starbucks",
        "domains": [
            "starbucks.com"
        ]
    },
    {
        "keyword": "steampowered",
        "domains": [
            "steampowered.com"
        ]
    },
    {
        "keyword": "sunat",
        "domains": [
            "sunat.gob.pe"
        ]
    },
    {
        "keyword": "suomi",
        "domains": [
            "suomi.fi"
        ]
    },
    {
        "keyword": "supervalu",
        "domains": [
            "supervalu.ie"
        ]
    },
    {
        "keyword": "svb",
        "domains": [
            "svb.nl"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "swedbank",
        "domains": [
            "swedbank.ee",
            "swedbank.lt",
            "swedbank.lv",
            "swedbank.se"
        ]
    },
    {
        "keyword": "target",
        "domains": [
            "target.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "tatrabanka",
        "domains": [
            "tatrabanka.sk"
        ]
    },
    {
        "keyword": "td",
        "domains": [
            "td.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "teams",
        "domains": [
            "teams.microsoft.com"
        ]
    },
    {
        "keyword": "telcel",
        "domains": [
            "telcel.com"
        ]
    },
    {
        "keyword": "telekom",
        "domains": [
            "telekom.de"
        ]
    },
    {
        "keyword": "telstra",
        "domains": [
            "telstra.com.au"
        ]
    },
    {
        "keyword": "tesco",
        "domains": [
            "tesco.com"
        ]
    },
    {
        "keyword": "tesla",
        "domains": [
            "tesla.com"
        ]
    },
    {
        "keyword": "thelott",
        "domains": [
            "thelott.com"
        ]
    },
    {
        "keyword": "thuisbezorgd",
        "domains": [
            "thuisbezorgd.nl"
        ]
    },
    {
        "keyword": "tiffany",
        "domains": [
            "tiffany.com"
        ]
    },
    {
        "keyword": "tikkie",
        "domains": [
            "tikkie.me"
        ]
    },
    {
        "keyword": "tim",
        "domains": [
            "tim.it"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "tmobile",
        "domains": [
            "t-mobile.com"
        ]
    },
    {
        "keyword": "toeslagen",
        "domains": [
            "toeslagen.nl"
        ]
    },
    {
        "keyword": "toss",
        "domains": [
            "toss.im"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "toyota",
        "domains": [
            "toyota.com"
        ]
    },
    {
        "keyword": "traderjoes",
        "domains": [
            "traderjoes.com"
        ]
    },
    {
        "keyword": "triodos",
        "domains": [
            "triodos.nl"
        ]
    },
    {
        "keyword": "truist",
        "domains": [
            "truist.com"
        ]
    },
    {
        "keyword": "twint",
        "domains": [
            "twint.ch"
        ]
    },
    {
        "keyword": "tworld",
        "domains": [
            "tworld.co.kr"
        ]
    },
    {
        "keyword": "ubisoft",
        "domains": [
            "ubisoft.com"
        ]
    },
    {
        "keyword": "ubs",
        "domains": [
            "ubs.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "ukrposhta",
        "domains": [
            "ukrposhta.ua"
        ]
    },
    {
        "keyword": "unicredit",
        "domains": [
            "unicredit.it"
        ]
    },
    {
        "keyword": "unilever",
        "domains": [
            "unilever.com"
        ]
    },
    {
        "keyword": "uniqlo",
        "domains": [
            "uniqlo.com"
        ]
    },
    {
        "keyword": "ups",
        "domains": [
            "ups.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "usaa",
        "domains": [
            "usaa.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "usbank",
        "domains": [
            "usbank.com"
        ]
    },
    {
        "keyword": "usps",
        "domains": [
            "usps.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "uwv",
        "domains": [
            "uwv.nl"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "vans",
        "domains": [
            "vans.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "vattenfall",
        "domains": [
            "vattenfall.nl"
        ]
    },
    {
        "keyword": "venmo",
        "domains": [
            "venmo.com"
        ]
    },
    {
        "keyword": "verizon",
        "domains": [
            "verizon.com"
        ]
    },
    {
        "keyword": "vero",
        "domains": [
            "vero.fi"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "versace",
        "domains": [
            "versace.com"
        ]
    },
    {
        "keyword": "viabcp",
        "domains": [
            "viabcp.com"
        ]
    },
    {
        "keyword": "vinted",
        "domains": [
            "vinted.com"
        ]
    },
    {
        "keyword": "vipps",
        "domains": [
            "vipps.no"
        ]
    },
    {
        "keyword": "visa",
        "domains": [
            "visa.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "vodafone",
        "domains": [
            "vodafone.de",
            "vodafone.it"
        ]
    },
    {
        "keyword": "vr",
        "domains": [
            "vr.de"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "vriendenloterij",
        "domains": [
            "vriendenloterij.nl"
        ]
    },
    {
        "keyword": "waitrose",
        "domains": [
            "waitrose.com"
        ]
    },
    {
        "keyword": "walmart",
        "domains": [
            "walmart.ca",
            "walmart.com",
            "walmart.com.mx"
        ]
    },
    {
        "keyword": "wegmans",
        "domains": [
            "wegmans.com"
        ]
    },
    {
        "keyword": "wellsfargo",
        "domains": [
            "wellsfargo.com"
        ]
    },
    {
        "keyword": "westpac",
        "domains": [
            "westpac.co.nz",
            "westpac.com.au"
        ]
    },
    {
        "keyword": "wholefoodsmarket",
        "domains": [
            "wholefoodsmarket.com"
        ]
    },
    {
        "keyword": "wise",
        "domains": [
            "wise.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "woolworths",
        "domains": [
            "woolworths.co.nz",
            "woolworths.com.au"
        ]
    },
    {
        "keyword": "wooribank",
        "domains": [
            "wooribank.com"
        ]
    },
    {
        "keyword": "xfinity",
        "domains": [
            "xfinity.com"
        ]
    },
    {
        "keyword": "youtube",
        "domains": [
            "youtube.com"
        ]
    },
    {
        "keyword": "zaba",
        "domains": [
            "zaba.hr"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "zabka",
        "domains": [
            "zabka.pl"
        ]
    },
    {
        "keyword": "zalando",
        "domains": [
            "zalando.com"
        ]
    },
    {
        "keyword": "zellepay",
        "domains": [
            "zellepay.com"
        ]
    },
    {
        "keyword": "ziggo",
        "domains": [
            "ziggo.nl"
        ]
    },
    {
        "keyword": "zoom",
        "domains": [
            "zoom.us"
        ],
        "exceptions": [
            "zoominfo.com"
        ],
        "wholeNameOnly": true
    },
    {
        "keyword": "zoominfo",
        "domains": [
            "zoominfo.com"
        ]
    }
];
