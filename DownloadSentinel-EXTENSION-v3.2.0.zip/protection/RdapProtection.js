"use strict";

/**
 * RdapProtection.js
 * Checks the registration age of a domain via RDAP.
 * Only called when Quad9 resolves the domain (status ALLOWED).
 *
 * Age scoring rules (mirrors VT's first-seen age logic but uses 30 days
 * as the primary cut-point instead of 7 days, since registration date
 * is a slower-moving signal than "first seen by VT"):
 *
 *   < 30 days old   →  −30  (very new domain, strong signal)
 *   30–90 days old  →  −10  (moderately new)
 *   > 90 days old   →    0  (neutral; established domain)
 *   age not determined → −10 (v3.2.0, 3P Matrix alignment §4 — treated the
 *       same as 31–90 days, for BOTH ways "not determined" happens: a real
 *       RDAP response with no registration date published (e.g. DENIC/.de,
 *       and some ccTLD registries have no RDAP service at all), AND the
 *       RDAP lookup itself failing/timing out (rdap.org unreachable, a slow
 *       registry, a non-2xx response) — the two were scored differently
 *       before this version (the latter was neutral, 0), which is wrong:
 *       "we can't tell" is not evidence of an established domain either
 *       way, and a flaky/unreachable lookup is if anything the WEAKER case
 *       of the two to treat as reassuring. Both now flow through the same
 *       scoreAge(null) call below. "DNS didn't resolve at all" is a
 *       separate, earlier gate (see ScoringEngineV2's `dnsResolved` guard)
 *       and is unaffected by this.
 *
 * Adapted from CallRDAP.js for use as an ES module.
 */
import { APP } from "../util/AppConstants.js";

export const RdapProtection = (function () {

    const RDAP_URL   = "https://rdap.org/domain";
    const TIMEOUT_MS = APP.RDAP_TIMEOUT_MS; // defined in AppConstants.js

    /**
     * Fetch registration date for a domain via RDAP.
     * @param {string} domain  - Registered domain (e.g. "example.com")
     * @param {AbortSignal} signal
     */
    async function fetchAge(domain, signal) {
        const response = await fetch(
            `${RDAP_URL}/${encodeURIComponent(domain)}`,
            { signal }
        );

        if (!response.ok) {
            return { status: "UNKNOWN", reason: `RDAP lookup failed (${response.status})` };
        }

        const rdap = await response.json();

        const regEvent = rdap.events?.find(
            e => e.eventAction === "registration" || e.eventAction === "registered"
        );

        if (!regEvent?.eventDate) {
            // A real RDAP response came back, it just has no registration
            // date in it — distinct from the lookup itself failing above.
            // Scored via scoreAge(null) rather than treated as neutral —
            // see this file's header, v3.2.0.
            return { status: "NO_DATE", reason: "Registration date not published by the registry" };
        }

        const registeredDate = new Date(regEvent.eventDate);
        const ageDays = Math.floor((Date.now() - registeredDate.getTime()) / 86400000);

        return {
            status: ageDays < 30 ? "YOUNG_DOMAIN" : "ESTABLISHED_DOMAIN",
            registered: regEvent.eventDate,
            ageDays
        };
    }

    /**
     * Score registration age using the 30-day cut-point scheme.
     *
     * @param {number|null} ageDays
     * @returns {{ score: number, label: string }}
     */
    function scoreAge(ageDays) {
        if (ageDays === null || ageDays === undefined) {
            // v3.2.0 (3P Matrix alignment §4) — no published date is treated
            // like 31-90 days old, not as neutral. See this file's header.
            return { score: -10, label: "registration age not published — treated as recent" };
        }

        const days = Math.max(0, Math.floor(ageDays));

        if (ageDays > 90) return { score:   0, label: `${days} days old (established)` };
        if (ageDays > 30) return { score: -10, label: `${days} days old (moderately new)` };
        return               { score: -30, label: `${days} days old (very new domain)` };
    }

    /**
     * Public API: look up registration age for a domain with a hard timeout.
     *
     * Returns:
     *   { status, score, label, registered?, ageDays? }
     */
    async function check(domain) {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort("timeout"), TIMEOUT_MS);

        try {
            const result = await fetchAge(domain, controller.signal);
            clearTimeout(timer);

            if (result.status === "UNKNOWN") {
                // v3.2.0 (3P Matrix alignment §4) — a failed/unreachable RDAP
                // lookup is scored exactly like NO_DATE below (scoreAge(null),
                // -10), not neutral (0) as before this version — see this
                // file's header. `status` stays "UNKNOWN" so the distinct
                // reason (fetch failure vs. a real no-date response) is still
                // visible in the label/diagnostics; only the SCORE is unified.
                const aged = scoreAge(null);
                return { status: "UNKNOWN", score: aged.score, label: result.reason || aged.label };
            }

            if (result.status === "NO_DATE") {
                const aged = scoreAge(null);
                return { status: "NO_DATE", score: aged.score, label: aged.label };
            }

            const aged = scoreAge(result.ageDays);

            return {
                status:     result.status,
                score:      aged.score,
                label:      aged.label,
                registered: result.registered,
                ageDays:    result.ageDays
            };

        } catch (err) {
            clearTimeout(timer);
            // Same v3.2.0 unification as the UNKNOWN branch above — a timeout
            // or thrown fetch error is "age not determined", scored via
            // scoreAge(null), not neutral.
            const aged = scoreAge(null);
            if (err.name === "AbortError") {
                return { status: "UNKNOWN", score: aged.score, label: "RDAP check timed out" };
            }
            return { status: "UNKNOWN", score: aged.score, label: `RDAP error: ${err.message}` };
        }
    }

    /** Expose scoreAge so ScoringEngineV2 can use it for domain-list/TLD checks */
    return { check, scoreAge };
})();
