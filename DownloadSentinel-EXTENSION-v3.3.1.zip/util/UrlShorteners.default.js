"use strict";

/**
 * UrlShorteners.default.js — GENERATED FILE. Do not hand-edit; run
 * `node tools/gen-data-defaults.mjs` to regenerate from the single source
 * of truth, EXTENSION/data/UrlShorteners.json.
 *
 * This is the bundled/offline default: compiled into the reviewed CWS
 * package, so UrlShorteners always has a safe starting value from first install
 * onward. v3.3.0 (3P Matrix alignment item 18) — this is the ONLY source
 * UrlShorteners is ever loaded from; the remote-refresh mechanism that used to
 * sit in front of it (util/FilterDataLoader.js) was removed, so there is
 * no fetch/cache fallback chain to describe here anymore — just this file.
 *
 * Generated: 2026-10-21T08:04:44.189Z
 */
export const UrlShortenersDefault = [
    "bit.ly",
    "tinyurl.com",
    "t.co",
    "goo.gl",
    "ow.ly",
    "is.gd",
    "buff.ly",
    "rebrand.ly",
    "cutt.ly",
    "shorturl.at",
    "tiny.cc",
    "rb.gy",
    "bl.ink",
    "lnkd.in",
    "shorte.st",
    "v.gd",
    "qr.ae",
    "soo.gd",
    "s.id",
    "clck.ru"
];
