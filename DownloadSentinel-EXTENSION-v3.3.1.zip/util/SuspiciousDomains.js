"use strict";

/**
 * SuspiciousDomains.js
 * Risk scores (0–100) for domains that are frequently used in malware delivery.
 * Higher score = stronger indicator of risk.
 *
 * Lookup is done against the full hostname AND the registered domain (last two labels),
 * so "raw.githubusercontent.com" is matched even if the download comes from a subdomain.
 *
 * The raw TABLE data lives in EXTENSION/data/SuspiciousDomains.json (the
 * single source of truth) and this module only holds the lookup LOGIC. The
 * compiled-in default below is generated from that JSON (see
 * SuspiciousDomains.default.js's own header) and is the only data this
 * module ever loads at runtime — v3.3.0 (3P Matrix alignment item 18)
 * removed the remote-refresh mechanism (util/FilterDataLoader.js) that used
 * to call setData() here with a freshly-fetched copy. setData()/
 * resetToDefault() remain for tests, which still swap TABLE out directly.
 */
import { SuspiciousDomainsDefault } from "./SuspiciousDomains.default.js";

export const SuspiciousDomains = (function () {

    let TABLE = SuspiciousDomainsDefault;

    /**
     * Look up a hostname in the table.
     * Checks the full hostname first, then the registered domain (last two labels).
     * Returns { score, matchedDomain } or null if not found.
     */
    function lookup(hostname) {
        if (!hostname) return null;
        const h = hostname.toLowerCase();

        // Full hostname match (e.g. "raw.githubusercontent.com")
        if (TABLE[h] !== undefined) {
            return { score: TABLE[h], matchedDomain: h };
        }

        // Registered-domain match (last two labels)
        const parts = h.split(".");
        if (parts.length >= 2) {
            const reg = parts.slice(-2).join(".");
            if (TABLE[reg] !== undefined) {
                return { score: TABLE[reg], matchedDomain: reg };
            }
        }

        return null;
    }

    /**
     * Replace the in-memory table — used by tests to install a known
     * fixture or reset back to the bundled default. No production caller
     * remains since item 18 removed the remote-refresh mechanism; never
     * call this with unvalidated data.
     */
    function setData(newTable) {
        TABLE = newTable;
    }

    function resetToDefault() {
        TABLE = SuspiciousDomainsDefault;
    }

    return { lookup, setData, resetToDefault };
})();
