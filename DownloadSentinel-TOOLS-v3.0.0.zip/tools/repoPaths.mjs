"use strict";

// tools/repoPaths.mjs
//
// Single shared helper for the one small computation every TOOLS/tools/*.mjs
// script that reaches across into EXTENSION/ was duplicating line-for-line
// (jscpd flagged exactly this once the EXTENSION/TOOLS split landed — see
// DOCS/CHANGELOG.md's v2.10.0 entry): given a script's own import.meta.url
// (always TOOLS/tools/<script>.mjs), derive TOOLS_ROOT, REPO_ROOT, and
// EXT_ROOT.
//
// Usage:
//   import { repoPaths } from "./repoPaths.mjs";
//   const { TOOLS_ROOT, REPO_ROOT, EXT_ROOT } = repoPaths(import.meta.url);
import path from "node:path";
import { fileURLToPath } from "node:url";

export function repoPaths(importMetaUrl) {
    const TOOLS_ROOT = path.dirname(path.dirname(fileURLToPath(importMetaUrl)));
    const REPO_ROOT  = path.dirname(TOOLS_ROOT);
    const EXT_ROOT   = path.join(REPO_ROOT, "EXTENSION");
    return { TOOLS_ROOT, REPO_ROOT, EXT_ROOT };
}
