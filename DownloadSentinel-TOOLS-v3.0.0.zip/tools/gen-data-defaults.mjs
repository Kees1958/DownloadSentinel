#!/usr/bin/env node
"use strict";

// tools/gen-data-defaults.mjs
//
// Regenerates each extracted data module's compiled-in default
// (EXTENSION/util/<Name>.default.js) from its single source of truth,
// EXTENSION/data/<Name>.json.
//
// Why a generated *.default.js companion instead of importing the JSON
// directly: this is a vanilla, unbundled MV3 extension with no build step,
// and Node's own JSON-import syntax (import assertions / import attributes)
// has shifted across versions and isn't something the rest of this codebase
// relies on anywhere. Inlining the already-validated JSON as a plain JS
// object/array literal in a generated module keeps every consumer on the
// exact same `import { X } from "./X.js"` shape it already uses — no
// import-assertion/bundler complexity, and the file is still 100% derived
// from data/<Name>.json (hand-editing it is pointless; the next run of this
// script overwrites it).
//
// Usage:
//   node tools/gen-data-defaults.mjs
//
// Run this after hand-editing any EXTENSION/data/<Name>.json (e.g. adding a
// brand domain or a shortener), and after `tools/update-lists.mjs` rewrites
// EXTENSION/data/HostList.json.

import { readFileSync, writeFileSync } from "node:fs";
import path from "node:path";

import { repoPaths } from "./repoPaths.mjs";

const { EXT_ROOT } = repoPaths(import.meta.url);
const DATA_DIR   = path.join(EXT_ROOT, "data");
const UTIL_DIR   = path.join(EXT_ROOT, "util");

// Every data-extracted module, in one place. Each entry's `name` must match
// both data/<name>.json and the exported `<name>Default` identifier that
// util/<name>.js imports from util/<name>.default.js.
const MODULES = [
    "SuspiciousDomains",
    "SuspiciousTlds",
    "RiskyHostingSites",
    "HostList",
    "BrandDomains",
    "UrlShorteners",
];

for (const name of MODULES) {
    const jsonPath = path.join(DATA_DIR, `${name}.json`);
    const outPath  = path.join(UTIL_DIR, `${name}.default.js`);

    const raw = readFileSync(jsonPath, "utf8");
    const parsed = JSON.parse(raw); // validate it's real JSON before trusting it as a literal

    const literal = JSON.stringify(parsed, null, 4);

    const out = `"use strict";

/**
 * ${name}.default.js — GENERATED FILE. Do not hand-edit; run
 * \`node tools/gen-data-defaults.mjs\` to regenerate from the single source
 * of truth, EXTENSION/data/${name}.json.
 *
 * This is the bundled/offline default: compiled into the reviewed CWS
 * package so ${name} always has a safe starting value even before
 * util/FilterDataLoader.js ever attempts a remote fetch, and whenever that
 * fetch fails, is unavailable, or returns malformed data.
 *
 * Generated: ${new Date().toISOString()}
 */
export const ${name}Default = ${literal};
`;
    writeFileSync(outPath, out);
    const count = Array.isArray(parsed) ? parsed.length : Object.keys(parsed).length;
    console.log(`  ${name}.default.js  ←  data/${name}.json  (${count} entries)`);
}

console.log("\nAll data defaults regenerated.");
