#!/usr/bin/env node
"use strict";

// tools/fp-sweep.mjs
//
// Heuristics plan Step 0 (v2.7.0) — false-positive sweep.
//
// Scores every entry in tests/fixtures/fp-corpus.json through the exact same
// synchronous host-reputation signals BrowserProtection.checkHostReputation()
// uses (domain/TLD/HostList lookups, SketchyUrlCheck, MimeCheck, RiskyHosting,
// double-extension/script/launcher flags) and compares the result against the
// saved baseline (tests/fixtures/fp-baseline.json).
//
// Quad9 and RDAP are MOCKED per entry — this sweep runs fully offline, no
// live network calls, no live malware. Default mock: Quad9 ALLOWED, RDAP
// "no signal" (score 0, i.e. an established domain) — a corpus entry can
// override either via its own "mockQuad9"/"mockRdap" field when a specific
// scenario needs it.
//
// Hard gate (per the heuristics plan's own release table): every run must
// show NO knownGood entry crossing from its baseline warning level into a
// worse one, unless that specific entry carries "acceptedRegression": true
// and an "acceptedReason" string explaining why. stagingSynthetic entries are
// informational only in v2.7.0 (no new detection was added this step; they
// become a real gate once Step 2's staging checks land in v2.8.0).
//
// Usage:
//   node tools/fp-sweep.mjs              — run the sweep against the saved baseline
//   node tools/fp-sweep.mjs --update     — (re)write the baseline from the current run

import { readFileSync, writeFileSync, existsSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

import { FilenameAnalysis } from "../../EXTENSION/util/FilenameAnalysis.js";
import { UrlUtils } from "../../EXTENSION/util/UrlUtils.js";
import { SuspiciousDomains } from "../../EXTENSION/util/SuspiciousDomains.js";
import { SuspiciousTlds } from "../../EXTENSION/util/SuspiciousTlds.js";
import { RiskyHostingSites } from "../../EXTENSION/util/RiskyHostingSites.js";
import { HostList } from "../../EXTENSION/util/HostList.js";
import { SketchyUrlCheck } from "../../EXTENSION/protection/SketchyUrlCheck.js";
import { MimeCheck } from "../../EXTENSION/protection/MimeCheck.js";
import { ScoringEngineV2 } from "../../EXTENSION/protection/ScoringEngineV2.js";

const ROOT         = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const CORPUS_FILE   = path.join(ROOT, "tests", "fixtures", "fp-corpus.json");
const BASELINE_FILE = path.join(ROOT, "tests", "fixtures", "fp-baseline.json");

const SHOULD_UPDATE = process.argv.includes("--update");

// ── Warning-level ranking — must match ScoringEngineV2's own tier order so
// "did this get worse" is a simple integer comparison. ──────────────────────
const LEVEL_RANK = Object.freeze({
    "Probably Safe":          0,
    "Probably Inconclusive":  1,
    "Probably Suspicious":    2,
    "Probably Malicious":     3,
});

// ── Default mocks (per-entry overridable) — no live network calls. ─────────
const DEFAULT_MOCK_QUAD9 = Object.freeze({ status: "ALLOWED" });
const DEFAULT_MOCK_RDAP  = Object.freeze({ score: 0, label: "established domain (mocked)" });

/**
 * Score one corpus entry using exactly the synchronous signals
 * BrowserProtection.checkHostReputation() would use — Quad9/RDAP mocked.
 */
function scoreEntry(entry) {
    const url         = entry.url;
    const originalUrl = entry.originalUrl ?? url;
    const filename     = entry.filename ?? "";
    const mime         = entry.mime ?? "";
    const totalBytes   = entry.totalBytes ?? 0;

    const classified = FilenameAnalysis.classifyDownload(url, originalUrl, filename, mime);
    // Not a monitored file type at all — Download Sentinel would never have
    // scored this download in the first place. Report as a pass-through.
    if (!classified) {
        return { classification: "Not monitored", score: 0, breakdown: [] };
    }
    const { ext, fileType, isScript, isLinuxLauncher } = classified;

    const finalHostname = UrlUtils.getHostname(url);
    const finalTld      = UrlUtils.getTld(finalHostname);

    const domainHit   = SuspiciousDomains.lookup(finalHostname);
    const tldHit       = SuspiciousTlds.lookup(finalTld);
    const hostListHit  = HostList.lookup(finalHostname);
    const sketchyUrl    = SketchyUrlCheck.check(url);
    const mimeResult    = MimeCheck.checkMime(ext || "", mime || "");
    const sizeResult    = MimeCheck.checkSize(totalBytes || 0);
    const riskyHosting  = RiskyHostingSites.lookup(finalHostname);
    const doubleExt     = FilenameAnalysis.getDoubleExtension(filename);

    const quad9 = entry.mockQuad9 ?? DEFAULT_MOCK_QUAD9;
    const rdap  = entry.mockRdap  ?? DEFAULT_MOCK_RDAP;

    // v2.11.0 — Step 5 filename/URL heuristics (RLO, padded double extension,
    // brand homoglyph, URL shortener, referrer mismatch) run INSIDE
    // evaluateHostReputation() itself (see ScoringEngineV2.js), keyed off
    // `filename`/`referrer` below — no separate call needed here, just pass
    // the corpus entry's fields through same as BrowserProtection does.
    const referrer = entry.referrer ?? null;

    const evaluation = ScoringEngineV2.evaluateHostReputation({
        quad9, rdap,
        domainHit, tldHit, hostListHit,
        sketchyUrl, mimeResult, sizeResult, riskyHosting,
        url, originalUrl, fileType, isScript, doubleExt, isLinuxLauncher,
        filename, referrer,
        obfuscation: null, // onCreated-vs-onChanged signal — not applicable to a static corpus entry
    });

    return {
        classification: evaluation.classification,
        score:          evaluation.score,
        breakdown:       evaluation.breakdown.map(b => `${b.source}: ${b.score}`),
    };
}

function loadCorpus() {
    if (!existsSync(CORPUS_FILE)) {
        throw new Error(`corpus file not found: ${path.relative(ROOT, CORPUS_FILE)}`);
    }
    return JSON.parse(readFileSync(CORPUS_FILE, "utf8"));
}

function loadBaseline() {
    if (!existsSync(BASELINE_FILE)) return null;
    return JSON.parse(readFileSync(BASELINE_FILE, "utf8"));
}

function buildResults(corpus) {
    const results = { knownGood: {}, stagingSynthetic: {} };
    for (const entry of corpus.knownGood)       results.knownGood[entry.url]       = scoreEntry(entry);
    for (const entry of corpus.stagingSynthetic) results.stagingSynthetic[entry.url] = scoreEntry(entry);
    return results;
}

function main() {
    console.log("── tools/fp-sweep.mjs — false-positive sweep (heuristics plan Step 0) ──\n");

    const corpus  = loadCorpus();
    const results = buildResults(corpus);

    if (SHOULD_UPDATE || !existsSync(BASELINE_FILE)) {
        writeFileSync(BASELINE_FILE, JSON.stringify(results, null, 2) + "\n", "utf8");
        console.log(`Baseline written: ${path.relative(ROOT, BASELINE_FILE)}`);
        console.log(`  knownGood: ${corpus.knownGood.length} entries`);
        console.log(`  stagingSynthetic: ${corpus.stagingSynthetic.length} entries`);
        return;
    }

    const baseline = loadBaseline();
    let regressions = 0;
    let improvements = 0;

    console.log(`knownGood corpus (${corpus.knownGood.length} entries) — must not regress:`);
    for (const entry of corpus.knownGood) {
        const current  = results.knownGood[entry.url];
        const previous  = baseline.knownGood[entry.url];
        const currRank  = LEVEL_RANK[current.classification] ?? 99;
        const prevRank  = previous ? (LEVEL_RANK[previous.classification] ?? 99) : 0;

        if (!previous) {
            console.log(`  + NEW   ${entry.url}\n          → ${current.classification} (${current.score})`);
            continue;
        }
        if (currRank > prevRank) {
            if (entry.acceptedRegression) {
                console.log(`  ~ OK (accepted)  ${entry.url}`);
                console.log(`          ${previous.classification} → ${current.classification} — ${entry.acceptedReason || "(no reason given)"}`);
            } else {
                console.log(`  ✗ REGRESSION  ${entry.url}`);
                console.log(`          ${previous.classification} (${previous.score}) → ${current.classification} (${current.score})`);
                console.log(`          breakdown: ${current.breakdown.join(", ") || "(none)"}`);
                regressions++;
            }
        } else if (currRank < prevRank) {
            console.log(`  ✓ improved  ${entry.url}: ${previous.classification} → ${current.classification}`);
            improvements++;
        }
    }

    console.log(`\nstagingSynthetic corpus (${corpus.stagingSynthetic.length} entries) — informational only, no gate yet (see heuristics plan Step 3 / v2.9.0):`);
    for (const entry of corpus.stagingSynthetic) {
        const current = results.stagingSynthetic[entry.url];
        console.log(`  ${current.classification.padEnd(22)} (${String(current.score).padStart(4)})  ${entry.url}`);
    }

    console.log();
    if (regressions > 0) {
        console.log(`✗ fp-sweep FAILED — ${regressions} unexplained knownGood regression(s). Run with --update to accept, or add "acceptedRegression"/"acceptedReason" to the corpus entry if the new signal is correct.`);
        process.exit(1);
    }
    console.log(`✓ fp-sweep passed — no unexplained knownGood regressions (${improvements} improved).`);
}

main();
