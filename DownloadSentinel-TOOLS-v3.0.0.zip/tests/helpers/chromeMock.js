"use strict";

/**
 * chromeMock.js — minimal in-memory chrome.storage/chrome.alarms mock for
 * unit tests.
 *
 * Storage.js / Settings.js are the only modules allowed to touch
 * chrome.storage directly (C4 — single storage layer); util/FilterDataLoader.js
 * is the only module that touches chrome.alarms beyond background.js's own
 * sweep alarm. This is the one mock the test suite needs for both.
 *
 * Both chrome.storage.local.get/set and chrome.alarms.get/create/clear
 * support the real MV3 dual calling convention — callback OR Promise (no
 * callback passed) — since different callers in this codebase use either
 * form (Storage.js/Settings.js use the callback form; FilterDataLoader.js
 * uses the Promise form).
 *
 * Resource lifecycle (guard pattern, matches AppConstants.js conventions):
 *   installChromeMock()   — INIT:  attach globalThis.chrome, empty store
 *   resetChromeMock()     — CLEAR: wipe stored data/alarms between tests, keep mock installed
 *   uninstallChromeMock() — RELEASE: remove globalThis.chrome entirely
 */

let store = {};
let alarms = new Map();
let alarmListeners = [];

function installChromeMock() {
    store = {};
    alarms = new Map();
    alarmListeners = [];
    globalThis.chrome = {
        storage: {
            local: {
                get(key, callback) {
                    const result = {};
                    if (Object.prototype.hasOwnProperty.call(store, key)) {
                        result[key] = store[key];
                    }
                    if (callback) { queueMicrotask(() => callback(result)); return undefined; }
                    return Promise.resolve(result);
                },
                set(data, callback) {
                    Object.assign(store, data);
                    if (callback) { queueMicrotask(() => callback()); return undefined; }
                    return Promise.resolve();
                }
            }
        },
        alarms: {
            get(name, callback) {
                const alarm = alarms.get(name) || undefined;
                if (callback) { queueMicrotask(() => callback(alarm)); return undefined; }
                return Promise.resolve(alarm);
            },
            create(name, info) {
                alarms.set(name, { name, ...info });
            },
            clear(name, callback) {
                const existed = alarms.delete(name);
                if (callback) { queueMicrotask(() => callback(existed)); return undefined; }
                return Promise.resolve(existed);
            },
            onAlarm: {
                addListener(fn) { alarmListeners.push(fn); },
                removeListener(fn) { alarmListeners = alarmListeners.filter(l => l !== fn); }
            }
        },
        runtime: {
            lastError: undefined
        }
    };
}

function resetChromeMock() {
    store = {};
    alarms = new Map();
    alarmListeners = [];
}

function uninstallChromeMock() {
    delete globalThis.chrome;
    store = {};
    alarms = new Map();
    alarmListeners = [];
}

export { installChromeMock, resetChromeMock, uninstallChromeMock };
