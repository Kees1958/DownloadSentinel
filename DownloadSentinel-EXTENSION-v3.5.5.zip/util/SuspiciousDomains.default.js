"use strict";

/**
 * SuspiciousDomains.default.js — GENERATED FILE. Do not hand-edit; run
 * `node tools/gen-data-defaults.mjs` to regenerate from the single source
 * of truth, EXTENSION/data/SuspiciousDomains.json.
 *
 * This is the bundled/offline default: compiled into the reviewed CWS
 * package, so SuspiciousDomains always has a safe starting value from first install
 * onward. v3.3.0 (3P Matrix alignment item 18) — this is the ONLY source
 * SuspiciousDomains is ever loaded from; the remote-refresh mechanism that used to
 * sit in front of it (util/FilterDataLoader.js) was removed, so there is
 * no fetch/cache fallback chain to describe here anymore — just this file.
 *
 * Precompiled format (v3.5.5, = 3P Matrix 4.5.4): the data is ONE JSON string, parsed by
 * util/SuspiciousDomains.js on its first lookup (util/LazyJson.js) — never at service-worker start.
 *
 * Generated: 2026-11-06T08:40:55.266Z
 */
export const SuspiciousDomainsDefaultJson = "{\"duckdns.org\":95,\"3322.org\":95,\"ddns.net\":90,\"hopto.org\":90,\"zapto.org\":90,\"servehttp.com\":90,\"serveftp.com\":90,\"sytes.net\":90,\"myvnc.com\":90,\"mywire.org\":90,\"mooo.com\":90,\"dynu.net\":85,\"freedns.afraid.org\":85,\"redirectme.net\":85,\"ddns.me\":80,\"workers.dev\":85,\"pages.dev\":85,\"github.io\":75,\"netlify.app\":75,\"vercel.app\":75,\"onrender.com\":75,\"fly.dev\":70,\"firebaseapp.com\":70,\"web.app\":65,\"glitch.me\":65,\"surge.sh\":65,\"gist.githubusercontent.com\":80,\"catbox.moe\":80,\"pixeldrain.com\":75,\"file.io\":70,\"drive.google.com\":35,\"docs.google.com\":30,\"is.gd\":70,\"tinyurl.com\":65,\"bit.ly\":60,\"cutt.ly\":60,\"rebrand.ly\":55,\"shorturl.at\":55,\"tiny.cc\":55,\"rb.gy\":50,\"t.ly\":50,\"ow.ly\":40,\"s.id\":40,\"discord.com\":60,\"t.me\":55,\"telegram.org\":40,\"raw.githack.com\":75,\"jsdelivr.net\":35}";
