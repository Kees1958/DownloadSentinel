"use strict";

/**
 * SuspiciousTlds.default.js — GENERATED FILE. Do not hand-edit; run
 * `node tools/gen-data-defaults.mjs` to regenerate from the single source
 * of truth, EXTENSION/data/SuspiciousTlds.json.
 *
 * This is the bundled/offline default: compiled into the reviewed CWS
 * package, so SuspiciousTlds always has a safe starting value from first install
 * onward. v3.3.0 (3P Matrix alignment item 18) — this is the ONLY source
 * SuspiciousTlds is ever loaded from; the remote-refresh mechanism that used to
 * sit in front of it (util/FilterDataLoader.js) was removed, so there is
 * no fetch/cache fallback chain to describe here anymore — just this file.
 *
 * Precompiled format (v3.5.5, = 3P Matrix 4.5.4): the data is ONE JSON string, parsed by
 * util/SuspiciousTlds.js on its first lookup (util/LazyJson.js) — never at service-worker start.
 *
 * Generated: 2026-11-06T08:40:55.268Z
 */
export const SuspiciousTldsDefaultJson = "{\"zip\":100,\"click\":85,\"cfd\":85,\"rest\":80,\"surf\":80,\"top\":75,\"icu\":70,\"shop\":68,\"xyz\":65,\"online\":65,\"site\":65,\"mov\":62,\"review\":60,\"download\":58,\"monster\":55,\"buzz\":52,\"fun\":50,\"live\":50,\"sbs\":45,\"store\":42,\"space\":42,\"website\":42,\"digital\":40,\"solutions\":40,\"agency\":38,\"email\":38,\"info\":30}";
