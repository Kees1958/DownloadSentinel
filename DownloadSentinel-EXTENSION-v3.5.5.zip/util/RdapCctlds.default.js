"use strict";

/**
 * RdapCctlds.default.js — GENERATED FILE. Do not hand-edit; run
 * `node tools/gen-data-defaults.mjs` to regenerate from the single source
 * of truth, EXTENSION/data/RdapCctlds.json.
 *
 * This is the bundled/offline default: compiled into the reviewed CWS
 * package, so RdapCctlds always has a safe starting value from first install
 * onward. v3.3.0 (3P Matrix alignment item 18) — this is the ONLY source
 * RdapCctlds is ever loaded from; the remote-refresh mechanism that used to
 * sit in front of it (util/FilterDataLoader.js) was removed, so there is
 * no fetch/cache fallback chain to describe here anymore — just this file.
 *
 * Precompiled format (v3.5.5, = 3P Matrix 4.5.4): the data is ONE JSON string, parsed by
 * util/RdapCctlds.js on its first lookup (util/LazyJson.js) — never at service-worker start.
 *
 * Generated: 2026-11-06T08:40:55.286Z
 */
export const RdapCctldsDefaultJson = "[\"ad\",\"ai\",\"ar\",\"as\",\"au\",\"bh\",\"bm\",\"br\",\"ca\",\"cc\",\"cm\",\"cr\",\"cv\",\"cx\",\"cz\",\"ec\",\"fi\",\"fj\",\"fm\",\"fo\",\"fr\",\"gd\",\"gs\",\"gy\",\"hn\",\"ht\",\"id\",\"in\",\"is\",\"ke\",\"kg\",\"kr\",\"ky\",\"lb\",\"ly\",\"mg\",\"ml\",\"ms\",\"mu\",\"na\",\"nf\",\"ng\",\"nl\",\"no\",\"pg\",\"pl\",\"pm\",\"pn\",\"pw\",\"re\",\"rw\",\"sc\",\"sd\",\"sg\",\"si\",\"sn\",\"sr\",\"ss\",\"tf\",\"th\",\"to\",\"tv\",\"tw\",\"tz\",\"ua\",\"uk\",\"uz\",\"vg\",\"vi\",\"wf\",\"ye\",\"yt\",\"zm\"]";
