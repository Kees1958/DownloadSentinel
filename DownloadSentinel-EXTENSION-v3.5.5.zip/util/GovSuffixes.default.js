"use strict";

/**
 * GovSuffixes.default.js — GENERATED FILE. Do not hand-edit; run
 * `node tools/gen-data-defaults.mjs` to regenerate from the single source
 * of truth, EXTENSION/data/GovSuffixes.json.
 *
 * This is the bundled/offline default: compiled into the reviewed CWS
 * package, so GovSuffixes always has a safe starting value from first install
 * onward. v3.3.0 (3P Matrix alignment item 18) — this is the ONLY source
 * GovSuffixes is ever loaded from; the remote-refresh mechanism that used to
 * sit in front of it (util/FilterDataLoader.js) was removed, so there is
 * no fetch/cache fallback chain to describe here anymore — just this file.
 *
 * Precompiled format (v3.5.5, = 3P Matrix 4.5.4): the data is ONE JSON string, parsed by
 * util/GovSuffixes.js on its first lookup (util/LazyJson.js) — never at service-worker start.
 *
 * Generated: 2026-11-06T08:40:55.284Z
 */
export const GovSuffixesDefaultJson = "[\"gob.mx\",\"gov.br\",\"gov.gr\",\"gov.kr\",\"gov.pl\",\"gov.uk\"]";
