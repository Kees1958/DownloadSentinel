#!/usr/bin/env node
// ── tools/complete-check.mjs ────────────────────────────────────────────────
// Automated pre-release check suite (Part D of the programming-principles
// audit standard), ported from 3P-Matrix-lite's tools/complete-check.mjs and
// adapted to this project's own layout (protection/, pages/, util/, assets/
// instead of core/ui/data). Run via `npm run check` before every version
// bump that is about to be zipped.
//
// Covers: syntax, ESLint, JSON validity, a file cross-reference (C20 —
// every manifest path / <script src> / import resolves to a real file),
// a message-routing cross-reference (C20a — every MSG.* has a router case
// and a real sender, or is in the documented BROADCAST_ONLY set with a
// reader), and a manifest/package.json version-sync check.
//
// Does NOT cover: a JSDOM dry-run, a functional smoke test against mocked
// chrome.storage, or a CSS class cross-reference — same intentional scope
// limits as the sibling script, for the same reasons (see that file).
// ─────────────────────────────────────────────────────────────────────────────

import { execFileSync } from "node:child_process";
import { readFileSync, readdirSync, statSync, existsSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

// ── Config ───────────────────────────────────────────────────────────────
// Directories scanned for .js files (relative to ROOT), recursively.
const JS_SCAN_DIRS = ["", "protection", "util", "pages"];
// Message types sent only via a broadcast/push (background → page), by
// design — expected to have NO router case in background.js. Maintain by
// hand whenever a broadcast-only type is added (see C20a).
const BROADCAST_ONLY = new Set(["VT_RESULT_UPDATE"]);
// Message types with a router case but no current UI sender, kept
// deliberately (documented in CHANGELOG/comments) rather than dead by
// accident. Listed explicitly so the check reports them as a known,
// tracked state rather than a fresh discovery every run.
const KNOWN_UNSENT = new Set(["SUBMIT_URL_TO_VT"]);

let failed = false;
const warn = (msg) => console.warn(`⚠ WARN  ${msg}`);
const fail = (msg) => { failed = true; console.error(`✗ FAIL  ${msg}`); };
const ok   = (msg) => console.log(`✓ OK    ${msg}`);

// Directories never scanned even if nested under a JS_SCAN_DIRS entry —
// build/dev artifacts, not extension source.
const EXCLUDED_DIR_NAMES = new Set(["node_modules", ".git"]);

function listJsFiles() {
  const out = [];
  const walk = (dir) => {
    for (const entry of readdirSync(dir)) {
      if (EXCLUDED_DIR_NAMES.has(entry)) continue;
      const full = path.join(dir, entry);
      const st = statSync(full);
      if (st.isDirectory()) { walk(full); continue; }
      if (entry.endsWith(".js")) out.push(full);
    }
  };
  for (const dir of JS_SCAN_DIRS) {
    const abs = path.join(ROOT, dir);
    if (existsSync(abs)) walk(abs);
  }
  return out;
}

// ── 1. Syntax check ─────────────────────────────────────────────────────────
function checkSyntax() {
  console.log("\n── 1. Syntax (node --check) ──");
  const files = listJsFiles();
  for (const file of files) {
    try {
      execFileSync(process.execPath, ["--check", file], { stdio: "pipe" });
    } catch (e) {
      fail(`${path.relative(ROOT, file)}: ${e.stderr?.toString().trim() || e.message}`);
    }
  }
  if (!failed) ok(`${files.length} files parsed cleanly`);
}

// ── 2. ESLint ────────────────────────────────────────────────────────────────
function checkLint() {
  console.log("\n── 2. ESLint ──");
  if (!existsSync(path.join(ROOT, ".eslintrc.json"))) {
    warn("no .eslintrc.json found — skipping lint step");
    return;
  }
  const localBin = path.join(ROOT, "node_modules", ".bin", process.platform === "win32" ? "eslint.cmd" : "eslint");
  if (!existsSync(localBin)) {
    warn("eslint not installed locally — run `npm install` first; skipping lint step");
    return;
  }
  try {
    execFileSync(localBin, [".", "--ext", ".js"], { cwd: ROOT, stdio: "pipe" });
    ok("eslint clean");
  } catch (e) {
    fail(`eslint reported issues:\n${e.stdout?.toString() || e.message}`);
  }
}

// ── 3. JSON validity ─────────────────────────────────────────────────────────
function loadJson(relPath) {
  const full = path.join(ROOT, relPath);
  if (!existsSync(full)) { fail(`${relPath}: file not found`); return null; }
  try {
    return JSON.parse(readFileSync(full, "utf8"));
  } catch (e) {
    fail(`${relPath}: invalid JSON — ${e.message}`);
    return null;
  }
}

function checkJson() {
  console.log("\n── 3. JSON validity ──");
  const manifest = loadJson("manifest.json");
  const pkg      = loadJson("package.json");
  if (manifest && pkg) ok("manifest.json and package.json parse cleanly");
  return { manifest, pkg };
}

// ── 4. File cross-reference (C20) ───────────────────────────────────────────
function stripComments(src) {
  return src
    .replace(/\/\*[\s\S]*?\*\//g, "")
    .replace(/(^|[^:])\/\/.*$/gm, "$1");
}

function extractImportPaths(file) {
  const src = stripComments(readFileSync(file, "utf8"));
  const paths = [];
  const importRe = /\bimport\s+(?:[\s\S]*?\bfrom\s+)?["']([^"']+)["']/g;
  let m;
  while ((m = importRe.exec(src)) !== null) {
    if (m[1].startsWith(".") || m[1].startsWith("/")) paths.push(m[1]);
  }
  return paths;
}

function extractHtmlScriptSrcs(file) {
  const src = readFileSync(file, "utf8").replace(/<!--[\s\S]*?-->/g, "");
  const paths = [];
  const re = /<script[^>]+src=["']([^"']+)["']/g;
  let m;
  while ((m = re.exec(src)) !== null) paths.push(m[1]);
  return paths;
}

function checkFileReferences(manifest) {
  console.log("\n── 4. File cross-reference (C20) ──");
  if (!manifest) { warn("skipped — manifest.json failed to parse"); return; }

  const declared = new Set();
  if (manifest.background?.service_worker) declared.add(manifest.background.service_worker);
  if (manifest.action?.default_popup) declared.add(manifest.action.default_popup);
  if (manifest.options_ui?.page) declared.add(manifest.options_ui.page);
  for (const iconPath of Object.values(manifest.icons || {})) declared.add(iconPath);
  for (const iconPath of Object.values(manifest.action?.default_icon || {})) declared.add(iconPath);
  for (const war of manifest.web_accessible_resources || []) {
    for (const r of war.resources || []) declared.add(r);
  }

  for (const p of declared) {
    if (!existsSync(path.join(ROOT, p))) fail(`manifest.json references missing file: ${p}`);
  }

  const visited = new Set();
  const toVisit = [...declared].filter((p) => p.endsWith(".js") || p.endsWith(".html"));

  while (toVisit.length) {
    const rel = toVisit.pop();
    if (visited.has(rel)) continue;
    visited.add(rel);
    const abs = path.join(ROOT, rel);
    if (!existsSync(abs)) continue;

    const dir = path.dirname(rel);
    if (rel.endsWith(".html")) {
      for (const src of extractHtmlScriptSrcs(abs)) {
        const resolved = path.normalize(path.join(dir, src));
        if (!existsSync(path.join(ROOT, resolved))) {
          fail(`${rel}: <script src="${src}"> does not resolve to a file on disk`);
        } else {
          toVisit.push(resolved);
        }
      }
    } else if (rel.endsWith(".js")) {
      for (const imp of extractImportPaths(abs)) {
        const resolved = path.normalize(path.join(dir, imp));
        if (!existsSync(path.join(ROOT, resolved))) {
          fail(`${rel}: import "${imp}" does not resolve to a file on disk`);
        } else {
          toVisit.push(resolved);
        }
      }
    }
  }

  const buildOnly = new Set(["tools/complete-check.mjs"]);
  for (const file of listJsFiles()) {
    const rel = path.relative(ROOT, file).split(path.sep).join("/");
    if (buildOnly.has(rel)) continue;
    if (!visited.has(rel)) warn(`${rel} is not reachable from manifest.json — orphaned file, or an untracked entry point`);
  }

  if (!failed) ok("all declared/imported/script-src paths resolve to real files");
}

// ── 5. Message-routing cross-reference (C20a) ───────────────────────────────
function checkMessageRouting() {
  console.log("\n── 5. Message-routing cross-reference (C20a) ──");
  const typesFile = path.join(ROOT, "util/MessageTypes.js");
  if (!existsSync(typesFile)) { warn("util/MessageTypes.js not found — skipped"); return; }

  const typesSrc = readFileSync(typesFile, "utf8");
  // MSG is a single frozen object here (not one export per constant, unlike
  // 3P-Matrix-lite) — pull key names out of the object literal.
  const constNames = [...typesSrc.matchAll(/^\s{4}([A-Z_]+):\s*"[A-Z_]+"/gm)].map((m) => m[1]);

  const bgFile = path.join(ROOT, "background.js");
  const bgSrc  = existsSync(bgFile) ? readFileSync(bgFile, "utf8") : "";
  const allSrc = listJsFiles().map((f) => readFileSync(f, "utf8")).join("\n");

  for (const name of constNames) {
    const hasRouterCase = new RegExp(`case\\s+MSG\\.${name}\\s*:`).test(bgSrc);
    const hasAnySender   = new RegExp(`type:\\s*MSG\\.${name}\\b`).test(allSrc);

    if (BROADCAST_ONLY.has(name)) {
      const hasReader = new RegExp(`MSG\\.${name}`).test(allSrc.replace(bgSrc, ""));
      if (!hasReader) fail(`MSG.${name} is in BROADCAST_ONLY but no reader found outside background.js`);
      if (hasRouterCase) warn(`MSG.${name} is in BROADCAST_ONLY but ALSO has a background.js router case — is it still broadcast-only?`);
    } else {
      if (!hasRouterCase) fail(`MSG.${name}: no router case in background.js (and not in BROADCAST_ONLY)`);
      if (!hasAnySender && !KNOWN_UNSENT.has(name)) {
        warn(`MSG.${name}: has a router case but no sendMessage call site found anywhere — dead message type?`);
      } else if (!hasAnySender && KNOWN_UNSENT.has(name)) {
        warn(`MSG.${name}: confirmed still unsent (tracked in KNOWN_UNSENT) — see CHANGELOG for status`);
      }
    }
  }
  if (!failed) ok(`${constNames.length} message types checked (${BROADCAST_ONLY.size} broadcast-only, ${KNOWN_UNSENT.size} known-unsent)`);
}

// ── 6. Version sync ──────────────────────────────────────────────────────────
function checkVersionSync(manifest, pkg) {
  console.log("\n── 6. Version sync ──");
  if (!manifest || !pkg) { warn("skipped — manifest.json or package.json failed to parse"); return; }
  if (manifest.version !== pkg.version) {
    fail(`version mismatch: manifest.json=${manifest.version} package.json=${pkg.version}`);
  } else {
    ok(`manifest.json and package.json both at ${manifest.version}`);
  }

  const lockPath = path.join(ROOT, "package-lock.json");
  if (existsSync(lockPath)) {
    try {
      const lock = JSON.parse(readFileSync(lockPath, "utf8"));
      if (lock.version !== pkg.version) {
        fail(`package-lock.json (${lock.version}) is out of sync with package.json (${pkg.version}) — run \`npm install\` (not just \`npm install --package-lock-only\`) after every version bump`);
      } else {
        ok(`package-lock.json also at ${lock.version}`);
      }
    } catch (e) {
      warn(`package-lock.json: could not parse to check version — ${e.message}`);
    }
  }
}

// ── Run ──────────────────────────────────────────────────────────────────────
checkSyntax();
checkLint();
const { manifest, pkg } = checkJson();
checkFileReferences(manifest);
checkMessageRouting();
checkVersionSync(manifest, pkg);

console.log("\n" + (failed ? "✗ complete-check FAILED — see above" : "✓ complete-check passed"));
process.exit(failed ? 1 : 0);
