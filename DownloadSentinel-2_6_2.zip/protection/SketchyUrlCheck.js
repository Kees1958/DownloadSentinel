"use strict";

/**
 * SketchyUrlCheck.js
 *
 * Heuristic analysis of a download URL's structural properties.
 * Returns a score 0–100 (0 = nothing suspicious, 100 = maximally sketchy).
 *
 * Checks performed (in order):
 *   1. IP address as host                          → handled by IpAddressCheck in ScoringEngineV2
 *   2. Punycode (xn--) — homograph/lookalike trick → SCORES.PUNYCODE
 *   3. Excessive subdomains (> 3 labels)           → SCORES.EXCESSIVE_SUBDOMAINS
 *   4. Brand impersonation in hostname             → SCORES.BRAND_IMPERSONATION per matched brand
 *   4a. Fuzzy (typo) brand impersonation           → SCORES.FUZZY_BRAND_IMPERSONATION per matched brand
 *   5. Lookalike character substitution            → SCORES.LOOKALIKE_CHAR (generic + brand normalisation)
 *   6. Opaque/parameterised download path          → SCORES.OPAQUE_PATH
 *
 * Dropped vs. original sketch:
 *   - Brand name in path  (too much noise)
 *   - Urgency words in path (too much noise)
 *   - Special characters in hostname (too much noise)
 *   - Suspicious TLD (scored as a separate host-reputation check in ScoringEngineV2)
 *
 * V2.4.1: the generic lookalike-character check (item 5) was temporarily
 * disabled because it flagged legitimate trailing-digit hostnames like
 * "download3.operacdn.com" (numbered mirrors/CDN pool servers). Fixed and
 * re-enabled — see hasLookalikeChar() below for the corrected boundary rules.
 *
 * V2.6.1: added item 4a, fuzzy (edit-distance) brand-name matching, and
 * expanded the BRANDS table from 29 to ~110 entries (Interbrand Best Global
 * Brands 2025 + Comparably Top 1000 Brands 2022). Exact substring matching
 * (item 4) only catches a correctly-spelled brand name in a suspicious
 * position; it does not catch a genuine misspelling like "gooogle.com" or
 * "microsft.com" used as the whole domain — that is what item 4a adds.
 * Scope limit: item 4a compares each hostname LABEL as a whole against each
 * brand keyword, so it catches a bare typo'd domain but not a typo combined
 * with a suffix (e.g. "micrsoft-support.com") — that would need a more
 * expensive sliding-window comparison, deliberately not implemented here to
 * keep this addition proportionate; item 4 (exact match) already covers the
 * suffix case when the brand name itself is spelled correctly.
 */
export const SketchyUrlCheck = (function () {

    // ── Score weights ──────────────────────────────────────────────────────────
    // All point contributions for this file's checks, gathered here per project
    // convention (single source of truth for magic numbers, with rationale).
    const SCORES = Object.freeze({
        PUNYCODE:               30, // xn-- prefix — homograph/lookalike domain trick
        EXCESSIVE_SUBDOMAINS:   10, // hostname has > 3 dot-separated labels
        BRAND_IMPERSONATION:    15, // per matched brand keyword, on a non-canonical host
        FUZZY_BRAND_IMPERSONATION: 12, // per typo'd brand keyword — slightly lower than an
                                        // exact match since edit-distance matching is inherently
                                        // less certain (a coincidental near-miss is more plausible
                                        // than a coincidental exact substring)
        LOOKALIKE_CHAR:         15, // generic letter-substitution pattern, e.g. m1cr0s0ft
        OPAQUE_PATH:            20  // script endpoint / query-param delivery, no visible extension
    });

    // Fuzzy brand-matching tuning — gathered here per project convention.
    const FUZZY_MIN_BRAND_LENGTH = 5; // brand keywords shorter than this are exact-match only
                                       // (e.g. "bmw", "byd", "uber", "dior") — edit-distance
                                       // scoring is unreliable on very short strings: a distance
                                       // of 1 on a 3-4 letter word is a huge, easily-coincidental
                                       // proportion of the word
    const FUZZY_MAX_EDIT_DISTANCE = 2;    // ceiling — see maxAllowedDistance() below, which
                                           // scales this down for shorter keywords
    const FUZZY_LONG_KEYWORD_LENGTH = 7;  // keywords at/above this length may use the full
                                           // FUZZY_MAX_EDIT_DISTANCE; shorter ones (5-6 letters)
                                           // are capped at 1 — found by testing that 5-letter
                                           // keywords ("slack", "teams") were coincidentally
                                           // edit-distance 2 from ordinary English words
                                           // ("space"/"place", "teach") — 2 edits is 40% of a
                                           // 5-letter word, too loose to mean anything
    const FUZZY_MAX_LENGTH_DELTA  = 2; // skip comparing a label against a keyword when their
                                        // lengths differ by more than this — keeps comparisons
                                        // cheap and avoids nonsensical long-vs-short matches

    // Extremely common subdomain labels, excluded from fuzzy brand matching.
    // These are short, generic infrastructure words that coincidentally land
    // within 1-2 edits of many real brand names purely by chance — "app" is
    // edit-distance 2 from "apple", "mail" is edit-distance 1 from "gmail" —
    // not because of any typosquatting intent. The exact-match check above
    // is unaffected by this list; it only narrows the newer fuzzy layer.
    // (Discovered via a real test failure on "app.zoominfo.com" — see
    // tests/SketchyUrlCheck.test.js and the CHANGELOG for that regression.)
    const FUZZY_EXCLUDED_LABELS = new Set([
        "www", "app", "api", "cdn", "ftp", "mail", "shop", "blog", "help",
        "docs", "dev", "test", "staging", "admin", "portal", "secure",
        "login", "account", "my", "get", "download", "dl", "static",
        "assets", "img", "images", "m", "mobile", "beta", "news", "support",
        "care", "chat", "jobs", "web", "go", "id", "auth", "sso",
        "cloud", "team", "store", "data", "service", "services", "hub",
        "group", "world", "live", "media", "central"
    ]);

    // ── Brand table ────────────────────────────────────────────────────────────
    // canonical = the real hostname the brand owns.
    // Any host containing the keyword that is NOT the canonical or a subdomain
    // of it is flagged as impersonation.
    // exceptions = other real, unrelated companies whose legitimate domain
    // happens to contain this keyword as a substring (e.g. "zoominfo.com"
    // contains "zoom") — excluded so they're never misflagged.
    //
    // Canonical domains were individually verified rather than assumed from
    // the company name — several are non-obvious corporate domains that
    // would otherwise have made this list actively wrong (Schneider Electric
    // → se.com, not schneiderelectric.com; Monster → monsterenergy.com, not
    // monster.com; American Eagle → ae.com; Peloton → onepeloton.com; Bungie
    // → bungie.net, not .com).
    //
    // Some keywords are deliberately the *full* brand context rather than a
    // bare word, specifically to avoid flagging ordinary use of a common
    // English word: "booking.com" (not "booking") and "monsterenergy" (not
    // "monster"). A few short (3-4 letter) keywords are kept as exact-match
    // only by design — see FUZZY_MIN_BRAND_LENGTH below, which excludes them
    // from the fuzzy layer since edit-distance scoring is unreliable on very
    // short strings.
    const BRANDS = [
        // Identity / OS / Productivity
        { keyword: "microsoft",     canonical: "microsoft.com"       },
        { keyword: "office",        canonical: "office.com"          },
        { keyword: "onedrive",      canonical: "onedrive.com"        },
        { keyword: "teams",         canonical: "teams.microsoft.com" },
        { keyword: "google",        canonical: "google.com"          },
        { keyword: "gmail",         canonical: "gmail.com"           },
        { keyword: "googledrive",   canonical: "drive.google.com"    },
        { keyword: "apple",         canonical: "apple.com"           },
        { keyword: "icloud",        canonical: "icloud.com"          },
        // E-commerce / Finance
        { keyword: "amazon",        canonical: "amazon.com"          },
        { keyword: "paypal",        canonical: "paypal.com"          },
        { keyword: "bankofamerica", canonical: "bankofamerica.com"   },
        { keyword: "hsbc",          canonical: "hsbc.com"            },
        { keyword: "revolut",       canonical: "revolut.com"         },
        { keyword: "blackrock",     canonical: "blackrock.com"       },
        { keyword: "mastercard",    canonical: "mastercard.com"      },
        { keyword: "visa",          canonical: "visa.com"            },
        { keyword: "americanexpress", canonical: "americanexpress.com" },
        { keyword: "jpmorganchase", canonical: "jpmorganchase.com"   }, // not bare "chase" — common English verb
        { keyword: "usaa",          canonical: "usaa.com"            },
        { keyword: "nasdaq",        canonical: "nasdaq.com"          },
        { keyword: "coinbase",      canonical: "coinbase.com"        },
        { keyword: "shopify",       canonical: "shopify.com"         },
        // Social / Media
        { keyword: "meta",          canonical: "meta.com"            },
        { keyword: "facebook",      canonical: "facebook.com"        },
        { keyword: "instagram",     canonical: "instagram.com"       },
        { keyword: "netflix",       canonical: "netflix.com"         },
        { keyword: "spotify",       canonical: "spotify.com"         },
        { keyword: "linkedin",      canonical: "linkedin.com"        },
        { keyword: "youtube",       canonical: "youtube.com"         },
        { keyword: "pinterest",     canonical: "pinterest.com"       },
        { keyword: "nationalgeographic", canonical: "nationalgeographic.com" },
        // Productivity / Collaboration
        { keyword: "adobe",         canonical: "adobe.com"           },
        { keyword: "dropbox",       canonical: "dropbox.com"         },
        { keyword: "docusign",      canonical: "docusign.com"        },
        { keyword: "zoom",          canonical: "zoom.us", exceptions: ["zoominfo.com"] },
        { keyword: "slack",         canonical: "slack.com"           },
        { keyword: "zoominfo",      canonical: "zoominfo.com"        },
        { keyword: "airbnb",        canonical: "airbnb.com"          },
        { keyword: "booking.com",   canonical: "booking.com"         }, // full context, not bare "booking"
        { keyword: "logitech",      canonical: "logitech.com"        },
        // Logistics
        { keyword: "fedex",         canonical: "fedex.com"           },
        { keyword: "dhl",           canonical: "dhl.com"             },
        { keyword: "ups",           canonical: "ups.com"             },
        { keyword: "johndeere",     canonical: "johndeere.com"       },
        // Tech / Chips / Enterprise
        { keyword: "nvidia",        canonical: "nvidia.com"          },
        { keyword: "qualcomm",      canonical: "qualcomm.com"        },
        { keyword: "amd",           canonical: "amd.com"             },
        { keyword: "cisco",         canonical: "cisco.com"           },
        { keyword: "geaerospace",   canonical: "geaerospace.com"     },
        { keyword: "schneiderelectric", canonical: "se.com"          }, // not bare "schneider" — common surname
        // Gaming / Entertainment
        { keyword: "nintendo",      canonical: "nintendo.com"        },
        { keyword: "playstation",   canonical: "playstation.com"     },
        { keyword: "roblox",        canonical: "roblox.com"          },
        { keyword: "riotgames",     canonical: "riotgames.com"       },
        { keyword: "ubisoft",       canonical: "ubisoft.com"         },
        { keyword: "bungie",        canonical: "bungie.net"          }, // .net, not .com
        // Automotive
        { keyword: "toyota",        canonical: "toyota.com"          },
        { keyword: "bmw",           canonical: "bmw.com"             },
        { keyword: "mercedes",      canonical: "mercedes-benz.com"   },
        { keyword: "tesla",         canonical: "tesla.com"           },
        { keyword: "ferrari",       canonical: "ferrari.com"         },
        { keyword: "byd",           canonical: "byd.com"             },
        { keyword: "honda",         canonical: "honda.com"           },
        { keyword: "audi",          canonical: "audi.com"            },
        { keyword: "porsche",       canonical: "porsche.com"         },
        // Fashion / Luxury / Retail
        { keyword: "chanel",        canonical: "chanel.com"          },
        { keyword: "louisvuitton",  canonical: "louisvuitton.com"    },
        { keyword: "gucci",         canonical: "gucci.com"           },
        { keyword: "hermes",        canonical: "hermes.com"          },
        { keyword: "dior",          canonical: "dior.com"            },
        { keyword: "uniqlo",        canonical: "uniqlo.com"          },
        { keyword: "adidas",        canonical: "adidas.com"          },
        { keyword: "puma",          canonical: "puma.com"            },
        { keyword: "versace",       canonical: "versace.com"         },
        { keyword: "tiffany",       canonical: "tiffany.com"         },
        { keyword: "vans",          canonical: "vans.com"            },
        { keyword: "crocs",         canonical: "crocs.com"           },
        { keyword: "americaneagle", canonical: "ae.com"              },
        { keyword: "costco",        canonical: "costco.com"          },
        { keyword: "nordstrom",     canonical: "nordstrom.com"       },
        { keyword: "footlocker",    canonical: "footlocker.com"      },
        { keyword: "sephora",       canonical: "sephora.com"         },
        { keyword: "glossier",      canonical: "glossier.com"        },
        { keyword: "homedepot",     canonical: "homedepot.com"       },
        { keyword: "maccosmetics",  canonical: "maccosmetics.com"    }, // not bare "mac" — collides with MacBook/macOS
        { keyword: "lvmh",          canonical: "lvmh.com"            },
        // Food / Beverage / Travel / Hospitality
        { keyword: "mcdonalds",     canonical: "mcdonalds.com"       },
        { keyword: "cocacola",      canonical: "coca-cola.com"       },
        { keyword: "starbucks",     canonical: "starbucks.com"       },
        { keyword: "chipotle",      canonical: "chipotle.com"        },
        { keyword: "monsterenergy", canonical: "monsterenergy.com"   }, // full context, not bare "monster"
        { keyword: "redbull",       canonical: "redbull.com"         },
        { keyword: "dunkin",        canonical: "dunkin.com"          },
        { keyword: "chickfila",     canonical: "chick-fil-a.com"     },
        { keyword: "traderjoes",    canonical: "traderjoes.com"      },
        { keyword: "innoutburger",  canonical: "in-n-out.com"        },
        { keyword: "baskinrobbins", canonical: "baskinrobbins.com"   },
        { keyword: "ritzcarlton",   canonical: "ritzcarlton.com"     },
        { keyword: "marriott",      canonical: "marriott.com"        },
        { keyword: "hilton",        canonical: "hilton.com"          },
        { keyword: "bathandbodyworks", canonical: "bathandbodyworks.com" },
        // Consumer goods / Conglomerates
        { keyword: "lego",          canonical: "lego.com"            },
        { keyword: "colgate",       canonical: "colgate.com"         },
        { keyword: "johnsonjohnson", canonical: "jnj.com"            }, // corporate domain is jnj.com
        { keyword: "proctergamble", canonical: "pg.com"              }, // corporate domain is pg.com
        { keyword: "hersheys",      canonical: "hersheys.com"        },
        { keyword: "unilever",      canonical: "unilever.com"        },
        { keyword: "headspace",     canonical: "headspace.com"       },
        { keyword: "peloton",       canonical: "onepeloton.com"      },
        { keyword: "philips",       canonical: "philips.com"         },
        { keyword: "bose",          canonical: "bose.com"            },
        { keyword: "7eleven",       canonical: "7-eleven.com"        },
    ];

    // Characters visually similar to letters used in homograph/typosquatting attacks:
    // 0→o, 1→i/l, 3→e, 4→a, 5→s, 6→g, 8→b, @→a
    const LOOKALIKE_CHARS = new Set(["0", "1", "3", "4", "5", "6", "8", "@"]);

    // Separators that count as boundaries (like letter adjacency) for lookalike detection
    const SEPARATORS = new Set(["-", "_", ".", "~"]);

    // Lookalike normalisation map — maps substitute characters back to their
    // letter equivalents, both for brand matching (normaliseHost) and for
    // recognising plausible multi-character runs (LOOKALIKE_SEQUENCES below).
    const NORMALISE_MAP = {
        "0": "o",
        "1": "i",
        "3": "e",
        "4": "a",
        "5": "s",
        "6": "g",
        "8": "b",
        "@": "a"
    };

    // Common English letter-pairs that a *run* of 2+ lookalike characters is
    // allowed to represent (e.g. "00" → "oo" as in g00gle, "10" → "io" as in
    // prev10us). A single lookalike character is inherently letter-like on its
    // own and needs no such check; a run of 2+ digits is only meaningful if it
    // actually spells a plausible letter sequence — otherwise arbitrary digit
    // runs (version numbers, resolutions, IDs) would be flagged as noise.
    const LOOKALIKE_SEQUENCES = new Set(["oo", "ee", "ie", "ei", "oi", "io", "ea", "ai", "ia", "ss"]);

    /**
     * Returns true when the hostname contains a run of one or more lookalike
     * characters that is:
     *   - sandwiched between two letters (strongest signal — mid-word
     *     substitution, e.g. m1cr0s0ft, g00gle, prev10us), or
     *   - immediately after a separator (- _ . ~) or at the very start of the
     *     hostname, and immediately followed by a letter (start-of-label
     *     substitution, e.g. 0ffice365-login, p@ypal-secure), or
     *   - preceded by a letter and immediately followed by a hyphen,
     *     underscore, or tilde (still inside the same DNS label — e.g.
     *     paypa1-security.info), or by the absolute end of the hostname with
     *     no TLD following (unusual/malformed — worth flagging).
     *
     * A run of 2+ lookalike characters only counts when it normalises to a
     * plausible letter pair (LOOKALIKE_SEQUENCES) — this is what catches
     * "g00gle" without also flagging meaningless digit runs.
     *
     * Deliberately does NOT flag a lookalike run immediately before a literal
     * dot — that is a real DNS label boundary, and a trailing digit there is
     * extremely common in legitimate infrastructure naming (download3.,
     * cdn1., mirror2., s3.amazonaws.com, ns2.example.com) and reads as a
     * numeric suffix, not a letter substitution. Flagging that produced too
     * many false positives (see CHANGELOG V2.4.1). A trailing digit before a
     * hyphen (e.g. "app-v1-prod") can still occasionally be a legitimate
     * version-number idiom rather than an attack — a known precision/recall
     * trade-off of catching genuine cases like "paypa1-security.info".
     *
     * Flat +SCORES.LOOKALIKE_CHAR — does not stack per run.
     *
     * Examples that trigger:       1ink, m1cr0s0ft, g00gle, p@ypal-secure, paypa1-security
     * Examples that do NOT trigger: download3, cdn1, server2, s3 (in s3.amazonaws.com)
     */
    function hasLookalikeChar(host) {
        const chars = host.split("");
        let i = 0;

        while (i < chars.length) {
            if (!LOOKALIKE_CHARS.has(chars[i])) { i++; continue; }

            // Extend to the full contiguous run of lookalike characters.
            let end = i;
            while (end < chars.length && LOOKALIKE_CHARS.has(chars[end])) end++;

            const prev = i > 0          ? chars[i - 1] : null;
            const next = end < chars.length ? chars[end]  : null;

            const prevIsLetter      = prev !== null && /[a-z]/i.test(prev);
            const nextIsLetter      = next !== null && /[a-z]/i.test(next);
            const prevIsSeparator   = prev !== null && SEPARATORS.has(prev);
            const nextIsNonDotSep   = next !== null && SEPARATORS.has(next) && next !== ".";
            const atStart           = prev === null;
            const atEnd             = next === null;

            const runLength    = end - i;
            const normalisedRun = chars.slice(i, end).map(ch => NORMALISE_MAP[ch] || ch).join("");
            const isPlausibleRun = runLength === 1 || LOOKALIKE_SEQUENCES.has(normalisedRun);

            if (isPlausibleRun && (
                (prevIsLetter    && nextIsLetter)    ||  // sandwiched between letters
                (prevIsSeparator && nextIsLetter)    ||  // separator then letter
                (atStart         && nextIsLetter)    ||  // start of label, followed by letter
                (prevIsLetter    && nextIsNonDotSep) ||  // letter then hyphen/underscore/tilde
                (prevIsLetter    && atEnd)               // letter then absolute end (no TLD)
            )) {
                return true;
            }

            i = end; // advance past this run
        }
        return false;
    }

    /**
     * Normalise a hostname by replacing lookalike characters with their letter
     * equivalents. Used so brand checks catch e.g. "micr0s0ft" → "microsoft",
     * "p@ypal" → "paypal", "paypa1" → "paypayi" (close enough for includes()).
     */
    function normaliseHost(host) {
        return host.split("").map(ch => NORMALISE_MAP[ch] || ch).join("");
    }

    /**
     * Returns true when host is the brand's canonical domain, a subdomain of
     * it, or one of its declared exceptions (another real company's domain
     * that happens to contain the same keyword — e.g. "zoominfo.com" vs the
     * "zoom" brand). Shared by both the exact-match and fuzzy-match checks so
     * the exemption rule is defined in exactly one place.
     */
    function isExemptHost(host, brand) {
        const canon = brand.canonical;
        if (host === canon || host.endsWith("." + canon)) return true;
        if (brand.exceptions) {
            for (const exception of brand.exceptions) {
                if (host === exception || host.endsWith("." + exception)) return true;
            }
        }
        return false;
    }

    /**
     * Returns true when the host (or its normalised form) contains the brand
     * keyword but is NOT the canonical domain or a legitimate subdomain of it.
     */
    function isBrandImpersonation(host, brand) {
        const normHost = normaliseHost(host);
        const matchesOriginal   = host.includes(brand.keyword);
        const matchesNormalised = normHost.includes(brand.keyword);
        if (!matchesOriginal && !matchesNormalised) return false;
        return !isExemptHost(host, brand);
    }

    /**
     * Standard Levenshtein edit distance (insertions/deletions/substitutions)
     * between two strings. Used by isFuzzyBrandImpersonation() below to catch
     * a misspelled brand name (e.g. "gooogle" vs "google", distance 1).
     */
    function levenshtein(a, b) {
        const rows = a.length + 1;
        const cols = b.length + 1;
        const dp = Array.from({ length: rows }, () => new Array(cols).fill(0));
        for (let i = 0; i < rows; i++) dp[i][0] = i;
        for (let j = 0; j < cols; j++) dp[0][j] = j;
        for (let i = 1; i < rows; i++) {
            for (let j = 1; j < cols; j++) {
                dp[i][j] = a[i - 1] === b[j - 1]
                    ? dp[i - 1][j - 1]
                    : 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
            }
        }
        return dp[rows - 1][cols - 1];
    }

    /**
     * The edit-distance ceiling for a given keyword length — scaled down for
     * shorter keywords so a "typo" always represents a small percentage of
     * the word, not up to 40% of it. See FUZZY_LONG_KEYWORD_LENGTH above.
     *
     * Known accepted gap: this means a 6-letter-or-shorter brand ("amazon")
     * won't fuzzy-match a 2-edit classic homograph trick like "arnazon.com"
     * (the "rn"→"m" visual substitution) — that specific case needs a
     * bigram-aware check (recognizing "rn" as a lookalike for "m", similar
     * to NORMALISE_MAP's single-character mappings above) rather than a
     * looser generic distance threshold, which reintroduced real false
     * positives during testing (see "slack"/"teams" in the CHANGELOG).
     * Not implemented here — flagged as a possible future, more surgical
     * addition rather than reopening this threshold.
     */
    function maxAllowedDistance(keywordLength) {
        return keywordLength >= FUZZY_LONG_KEYWORD_LENGTH ? FUZZY_MAX_EDIT_DISTANCE : 1;
    }

    /**
     * Returns true when some whole dot-separated label of the hostname is a
     * near-miss (1-2 character edit distance) of the brand's keyword — a
     * genuine misspelling used as the domain itself (e.g. "microsft.com",
     * "gooogle.com") — and the host is not exempt (see isExemptHost).
     *
     * Deliberately whole-label, not substring: comparing a short keyword
     * against every possible window of a longer label (to also catch a typo
     * PLUS a suffix, e.g. "micrsoft-support.com") would need a sliding-window
     * scan. Skipped here to keep this check cheap and its false-positive
     * surface small — see the V2.6.1 header note above for the scope call.
     * The exact-match check above already covers the suffix case whenever
     * the brand name itself is spelled correctly.
     */
    function isFuzzyBrandImpersonation(host, brand) {
        if (brand.keyword.length < FUZZY_MIN_BRAND_LENGTH) return false;
        if (isExemptHost(host, brand)) return false;

        const labels = host.split(".");
        for (const label of labels) {
            if (label === brand.keyword) continue;          // exact match — handled by isBrandImpersonation
            if (FUZZY_EXCLUDED_LABELS.has(label)) continue;  // common generic infra label — see set above
            if (label.length < 3) continue;                  // too short to meaningfully compare
            if (Math.abs(label.length - brand.keyword.length) > FUZZY_MAX_LENGTH_DELTA) continue;

            const distance = levenshtein(label, brand.keyword);
            if (distance >= 1 && distance <= maxAllowedDistance(brand.keyword.length)) return true;
        }
        return false;
    }

    /**
     * Returns true when host is the canonical domain (or a subdomain, or a
     * declared exception) of ANY brand in BRANDS — used as a whole-host
     * early-out so a real brand's own domain is never evaluated against
     * every OTHER brand's keyword. See the call site in check() for why
     * this matters (shopify.com vs "spotify", cisco.com vs "costco").
     */
    function isKnownLegitimateBrandHost(host) {
        return BRANDS.some(brand => isExemptHost(host, brand));
    }

    // ── Main function ──────────────────────────────────────────────────────────

    /**
     * Analyse a URL string for suspicious structural patterns.
     *
     * @param {string} inputUrl
     * @returns {{ score: number, signals: string[] }}
     *   score   — 0 (nothing suspicious) to 100 (maximally sketchy)
     *   signals — human-readable descriptions of triggered checks
     */
    function check(inputUrl) {
        let score     = 0;
        const signals = [];

        let url;
        try {
            url = new URL(inputUrl);
        } catch {
            // Unparseable URL — no score
            return { score: 0, signals: [] };
        }

        const host = url.hostname.toLowerCase();

        // ── 1. IP address — handled by IpAddressCheck in ScoringEngineV2 ──────

        // ── 2. Punycode ──────────────────────────────────────────────────────
        if (host.includes("xn--")) {
            score += SCORES.PUNYCODE;
            signals.push(`Punycode detected — possible lookalike domain (+${SCORES.PUNYCODE})`);
        }

        // ── 3. Excessive subdomains ──────────────────────────────────────────
        const parts = host.split(".");
        if (parts.length > 3) {
            score += SCORES.EXCESSIVE_SUBDOMAINS;
            signals.push(`Excessive subdomains: ${parts.length - 1} levels (+${SCORES.EXCESSIVE_SUBDOMAINS})`);
        }

        // ── 4. Brand impersonation (exact) ────────────────────────────────────
        // ── 4a. Brand impersonation (fuzzy — typo of a brand name) ────────────
        // Fuzzy only runs for a brand when the exact check didn't already fire
        // for it, so a single brand can't score twice on the same URL.
        //
        // If the host is itself one of OUR OWN brands' verified canonical
        // domains (or a subdomain of one, or a declared exception), skip
        // impersonation checks entirely — a real, known-legitimate brand
        // domain can never be "impersonating" a different brand, even if its
        // name happens to be a coincidental edit-distance-2 near-miss of
        // another brand's keyword (found in testing: shopify.com is
        // edit-distance 2 from "spotify"; cisco.com is edit-distance 2 from
        // "costco" — two pairs of real, unrelated brands in this same table).
        if (!isKnownLegitimateBrandHost(host)) {
            for (const brand of BRANDS) {
                if (isBrandImpersonation(host, brand)) {
                    score += SCORES.BRAND_IMPERSONATION;
                    signals.push(`Brand impersonation: "${brand.keyword}" in hostname (+${SCORES.BRAND_IMPERSONATION})`);
                } else if (isFuzzyBrandImpersonation(host, brand)) {
                    score += SCORES.FUZZY_BRAND_IMPERSONATION;
                    signals.push(`Possible typo of brand "${brand.keyword}" in hostname (+${SCORES.FUZZY_BRAND_IMPERSONATION})`);
                }
            }
        }

        // Clamp before lookalike so headroom calculation is accurate
        score = Math.min(score, 100);

        // ── 5. Lookalike character substitution ──────────────────────────────
        // Generic check (re-enabled in V2.4.1 after fixing the trailing-digit
        // false positive — see hasLookalikeChar() docs). Independent of and
        // stacks with brand impersonation above: a lookalike-substituted brand
        // name (e.g. "micr0s0ft-updates.xyz") legitimately triggers both.
        if (hasLookalikeChar(host)) {
            score += SCORES.LOOKALIKE_CHAR;
            signals.push(`Lookalike character substitution in hostname (+${SCORES.LOOKALIKE_CHAR})`);
        }

        // ── 6. Opaque / parameterised download path ──────────────────────────
        // Legitimate software distribution almost always serves files with a
        // meaningful filename in the URL path (e.g. /files/setup.exe).
        // A path that ends in a script endpoint (?id=, .php, .aspx, /download)
        // with no filename extension is a common pattern for redirect-chain
        // malware delivery and drive-by downloads.
        // Skip check if the path already has a visible dangerous extension —
        // those are caught by the extension classifier, not this heuristic.
        const pathname = url.pathname.toLowerCase();
        const hasVisibleExt = /\.(exe|msi|bat|cmd|ps1|vbs|sh|py|rb|zip|rar|7z|iso|dmg|pkg|deb|rpm)$/.test(pathname);
        if (!hasVisibleExt) {
            const opaquePatterns = [
                /[?&](id|file|dl|download|token|key|hash)=/i,  // query param delivery
                /\/(download|dl|get|serve|fetch)(\/|$)/i,      // generic download endpoint
                /\.(php|aspx|asp|cfm|cgi|jsp)(\/|$|\?)/i,     // server-side script endpoint
            ];
            for (const pattern of opaquePatterns) {
                if (pattern.test(url.href)) {
                    score += SCORES.OPAQUE_PATH;
                    signals.push(`Opaque download path — file served via script or parameter (+${SCORES.OPAQUE_PATH})`);
                    break; // one signal per URL, no stacking
                }
            }
        }

        return { score: Math.max(0, Math.min(100, score)), signals };
    }

    return { check };

})();
