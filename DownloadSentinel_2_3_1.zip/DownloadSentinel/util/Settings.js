"use strict";

// ── Settings.js ───────────────────────────────────────────────────────────────
// Manages user preferences: merge-with-defaults, read, and write.
//
// Public interface:
//   Settings.get(callback)              — read merged settings (defaults + stored)
//   Settings.set(newSettings, callback) — write partial update (merged with stored)
//
// Dependencies (must be loaded before this file):
//   Storage.js   — getFromLocalStore / setToLocalStore
//   AppConstants.js — APP.WARNING_TITLE_DEFAULT, APP.AUTO_ALLOW_THRESHOLD_DEFAULT
//
// State owned:
//   defaultSettings  {Object}  — stateless template; never mutated at runtime.
//
// NOTE: Do not add settings keys without also adding them to the options UI
// and verifying backward-compatible defaults (audit item B9).
// ─────────────────────────────────────────────────────────────────────────────

const Settings = (function () {

    // ── Storage key ───────────────────────────────────────────────────────────
    // Must not be renamed — it is a stored-data contract with existing users.
    const SETTINGS_KEY = "Settings";

    // ── Default settings ──────────────────────────────────────────────────────
    // Every key must have a sensible default that works correctly on first
    // install and after extension updates (backward-compatible defaults).
    const defaultSettings = {
        // Master on/off switch for the extension
        extensionEnabled: true,

        // Whether VT URL check is active (requires API key)
        virusTotalEnabled: true,

        // VirusTotal API key entered by the user
        vtApiKey: "",

        // Whether the user has provided a VT API key
        isVtApiKeySet: false,

        // Auto-allow when combined score exceeds threshold
        autoAllow: false,
        autoAllowThreshold: APP.AUTO_ALLOW_THRESHOLD_DEFAULT,

        // Custom warning background color (default: Google Red)
        warningColorR: 179,
        warningColorG: 38,
        warningColorB: 30,

        // Custom warning window title — single source of truth via APP constant
        warningTitle: APP.WARNING_TITLE_DEFAULT,

        // Custom whitelist domains (up to APP.DOMAIN_WHITELIST_MAX).
        // sharepoint.com is provided as a first example — org-controlled
        // content hosting that was previously in the built-in whitelist.
        // Users can remove it if they do not use SharePoint.
        customDomains: ["sharepoint.com"],

        // False positive reduction level: "NONE" | "LOW" | "MEDIUM" | "HIGH"
        fpReductionLevel: "MEDIUM",
    };

    // ── Private helpers ───────────────────────────────────────────────────────

    // Apply fields from source into target; returns true if anything changed.
    function updateIfChanged(target, source) {
        let hasChanges = false;
        if (source) {
            for (const key in source) {
                if (source[key] !== target[key]) {
                    target[key] = source[key];
                    hasChanges = true;
                }
            }
        }
        return hasChanges;
    }

    // ── Public API ────────────────────────────────────────────────────────────

    return {

        get: function (callback) {
            Storage.getFromLocalStore(SETTINGS_KEY, function (storedSettings) {
                const merged = JSON.parse(JSON.stringify(defaultSettings));
                updateIfChanged(merged, storedSettings);
                if (callback) callback(merged);
            });
        },

        set: function (newSettings, callback) {
            Storage.getFromLocalStore(SETTINGS_KEY, function (storedSettings) {
                const merged = JSON.parse(JSON.stringify(defaultSettings));
                if (storedSettings) updateIfChanged(merged, storedSettings);
                updateIfChanged(merged, newSettings);
                Storage.setToLocalStore(SETTINGS_KEY, merged, callback);
            });
        }
    };
})();
