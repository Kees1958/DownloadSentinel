# Architecture — the DOCS / TOOLS / EXTENSION split (v2.10.0)

This document explains the three-way top-level restructure introduced in
v2.10.0, and the runtime mechanism it exists to enable: updating filter/list
data (domains, TLDs, brand names, URL shorteners, host-risk entries) **without
triggering a new Chrome Web Store manual-review cycle**.

See `DOCS/CHANGELOG.md`'s `## V2.10.0` entry for the release-note version of
this; this file is the living design reference.

## Why this exists

Chrome Web Store review covers the code you submit in a version — the
manifest and every script it loads. Remotely-fetched **pure JSON data** (no
executable code, no `eval`/`new Function`, no injected scripts) is allowed to
change an extension's live behavior between reviews, as long as the
fetching/parsing/applying *code* that handles it was already reviewed and
doesn't itself change. The practical consequence: if the frequently-changing
parts of this extension — domain/TLD/host-risk lists, the brand list, the
shortener list — live as standalone JSON instead of being compiled into the
reviewed JS bundle, those lists can be updated (e.g. a new commit to a JSON
file in this repo) without a new CWS submission, because the EXTENSION
package itself (manifest + code) never changes.

## The three top-level directories

```
EXTENSION/   — everything that ships in the Chrome Web Store zip
TOOLS/       — everything NOT shipped: build/check scripts, tests, dev config
DOCS/        — all documentation
```

**`EXTENSION/` is the package root** — `manifest.json` stays at its top level
because Chrome loads a package from its own root; `TOOLS/` and `DOCS/` are
siblings to it at the repo root, never nested inside it.

```
EXTENSION/
  manifest.json
  background.js
  protection/          9 files — scoring/heuristics LOGIC, unchanged shape
  util/                logic + the 6 extracted data-module wrappers (below)
  data/                NEW — bundled JSON snapshots, single source of truth
  pages/                popup / options / warning UI
  assets/               icons

TOOLS/
  package.json, package-lock.json, node_modules/
  .eslintrc.json, .depcheckrc.json, knip.json, .gitignore
  tests/                unit tests (node --test) + fixtures + helpers
  tools/                complete-check.mjs, fp-sweep.mjs, update-lists.mjs,
                        gen-data-defaults.mjs, run-knip.mjs, repoPaths.mjs

DOCS/
  CHANGELOG.md
  ARCHITECTURE.md       this file
```

## The data extraction

Six modules were identified as genuinely **pure data** (no derived logic,
just lists/tables of domains, TLDs, or scores) and split into a JSON file
plus a thin logic wrapper:

| Module | Data file | Shape |
|---|---|---|
| `util/SuspiciousDomains.js` | `data/SuspiciousDomains.json` | `{ domain: score }` |
| `util/SuspiciousTlds.js` | `data/SuspiciousTlds.json` | `{ tld: score }` |
| `util/RiskyHostingSites.js` | `data/RiskyHostingSites.json` | `[{ host, score, exact }]` |
| `util/HostList.js` | `data/HostList.json` | `{ domain: { score, source } }` |
| `util/BrandDomains.js` | `data/BrandDomains.json` | `[domain, …]` |
| `util/UrlShorteners.js` | `data/UrlShorteners.json` | `[domain, …]` |

Each wrapper module now holds **only the lookup logic** (`lookup()`, or the
`.list`/`.set` convenience derivation for the two flat-array modules, shared
via `util/ListSetModule.js`'s factory). The data itself lives in
`EXTENSION/data/<Name>.json` — edit that JSON (and, for the two
hand-maintained brand/shortener lists, nothing else) to change what a module
matches.

**Left alone, deliberately:** `util/DangerousExts.js` and
`util/DangerousMimes.js` mix real data with *derived* logic
(`DangerousMimes.EXECUTABLE_MIMES` is computed from `MIME_TO_EXTS` at module
load, keyed against `DangerousExts.DANGEROUS`) — splitting them cleanly would
mean either shipping the derivation logic as "data" (defeating the point) or
a more invasive refactor than this pass's conservative scope calls for.
They're flagged here as a future candidate, not touched.

### The compiled-in default (`*.default.js`)

This is a vanilla, unbundled MV3 extension with no build step, and JSON
import syntax (import assertions/attributes) isn't used anywhere else in this
codebase. Rather than introduce that complexity for six files, each data
module's compiled-in default is a **generated** companion file —
`util/<Name>.default.js`, produced by `tools/gen-data-defaults.mjs` from
`data/<Name>.json` — containing the exact same data as a plain JS literal
export. Every consumer still writes the same `import { X } from "./X.js"` it
always has; only `X.js` itself now delegates its starting value to
`X.default.js`.

Run `node tools/gen-data-defaults.mjs` after hand-editing any
`data/<Name>.json` (e.g. adding a brand domain). `tools/update-lists.mjs`
(which regenerates `data/HostList.json` from the HaGeZi/Kees1958 upstream
lists, unchanged in purpose from pre-v2.10.0) calls this automatically at the
end of its own run, so a plain `node tools/update-lists.mjs` keeps both in
sync in one step.

## `util/FilterDataLoader.js` — the runtime mechanism

A new small module, following this codebase's existing IIFE-singleton
convention. For each of the six modules above, it:

1. **Does nothing extra at import time** — each module already has its own
   bundled default active as soon as it's imported, exactly as before.
2. **On `init()`** (called once, unconditionally, from `background.js`'s
   startup path) and on a recurring `chrome.alarms` alarm, attempts to fetch
   that module's live JSON from `REMOTE_BASE_URL + "/<Name>.json"`.
3. **Validates the shape** of whatever comes back (an object-of-numbers, an
   array-of-strings, or one of the two structured-array/object shapes above)
   before trusting it at all. A shape failure is just "don't apply this" —
   never a thrown error, never a half-applied state.
4. **Caches** a validated fetch in `chrome.storage.local` with a timestamp.
5. **Applies**, in order of preference: a fresh, valid fetch → the
   last-known-good cached copy → the compiled-in default (already active, so
   "do nothing" is correct there). A network failure, a host not covered by
   `host_permissions`, a CORS rejection, and malformed JSON all fail into
   this same safe chain — nothing distinguishes them from each other at the
   call site; see `FilterDataLoader.js`'s own header for the full guard-list.

`lookup()` (and `.list`/`.set`) on every one of the six modules **stays
synchronous** throughout. `FilterDataLoader` swaps the in-memory table behind
it via a `setData()`/`resetToDefault()` pair each module exposes — nothing
about the 312 existing/current unit tests, `tools/fp-sweep.mjs`, or any
scoring code had to become `async` to support this.

### Idempotent lifecycle

- `init()` is safe to call more than once — a second call returns the same
  in-flight/settled promise rather than refetching or recreating the alarm.
  This matters because `background.js`'s service worker restarts routinely
  under MV3, with no corresponding `onStartup`/`onInstalled` event.
- The refresh alarm is created idempotently: `chrome.alarms.get()` is checked
  before `chrome.alarms.create()`.
- `clear()` removes the alarm listener, clears the alarm, and resets every
  module back to its bundled default — for tests only; production code never
  calls it.

## Resolved — as of this restructure (pre-v3.0.0)

1. **`REMOTE_BASE_URL` now points at this project's own repo**:
   `https://raw.githubusercontent.com/Kees1958/uBol-stripped/main/EXTENSION/data`
   (the same repo this project's own docs/style guides already live in). The
   `data/*.json` files must actually exist at that path in the repo for
   fetches to succeed — until they are pushed there, fetches 404 and every
   list keeps using its bundled default (safe by design, see module header).
2. **`host_permissions` now includes `https://raw.githubusercontent.com/Kees1958/uBol-stripped/*`**,
   added explicitly (not silently) alongside this restructure, scoped to this
   one repo path rather than the whole `raw.githubusercontent.com` host.
   This is a manifest permission change and is called out plainly here and
   in the v3.0.0 CHANGELOG entry as exactly that.
3. `raw.githubusercontent.com` is reused as the transport because
   `tools/update-lists.mjs` already fetches its upstream sources from that
   same host for its own, separate, dev-time purpose. It has no built-in
   versioning/rollback or rate-limit story beyond what GitHub itself
   provides — worth revisiting if filter-update volume grows, but adequate
   for the twice-daily refresh cadence this module uses today.

## Adding a new extractable data list in future

1. Confirm it's genuinely pure data (see "Left alone, deliberately" above for
   the counter-example).
2. Add `EXTENSION/data/<Name>.json`.
3. Add `<Name>` to `tools/gen-data-defaults.mjs`'s `MODULES` list; run it.
4. Write `util/<Name>.js` importing `<Name>Default` from `./<Name>.default.js`,
   exposing whatever lookup shape its consumers need, plus `setData()` and
   `resetToDefault()` (or use `util/ListSetModule.js`'s factory if the shape
   is a flat list exposed as `.list`/`.set`).
5. Register it in `util/FilterDataLoader.js`'s `SOURCES` array with an
   appropriate shape validator.
6. Add a unit test file, same pattern as every other module here.
