"use strict";

// ── Storage.js ────────────────────────────────────────────────────────────────
// Single storage-access layer for chrome.storage.local.
//
// Public interface:
//   Storage.getFromLocalStore(key, callback)       — read one key
//   Storage.setToLocalStore(key, value, callback)  — write one key
//
// Dependencies: none
//
// State owned: none (stateless pass-through to chrome.storage.local)
//
// NOTE: All chrome.storage.local access in the extension must go through this
// module (audit item C4). Feature modules must not call chrome.storage directly.
// ─────────────────────────────────────────────────────────────────────────────

export const Storage = {

    getFromLocalStore: function (key, callback) {
        chrome.storage.local.get(key, function (result) {
            if (chrome.runtime.lastError) {
                console.error("[Sentinel] storage.get error:", chrome.runtime.lastError.message);
            }
            callback(result && result[key]);
        });
    },

    setToLocalStore: function (key, value, callback) {
        const data = {};
        data[key] = value;
        chrome.storage.local.set(data, function () {
            if (chrome.runtime.lastError) {
                console.error("[Sentinel] storage.set error:", chrome.runtime.lastError.message);
            }
            if (callback) callback();
        });
    }
};
