"use strict";

/**
 * SketchyUrlCheck.js
 *
 * Heuristic analysis of a download URL's structural properties.
 * Returns a score 0–100 (0 = nothing suspicious, 100 = maximally sketchy).
 *
 * Checks performed (in order):
 *   1. IP address as host                          → handled by IpAddressCheck in ScoringEngineV2
 *   2. Punycode (xn--) — homograph/lookalike trick → SCORES.PUNYCODE
 *   3. Excessive subdomains (> 3 labels)           → SCORES.EXCESSIVE_SUBDOMAINS
 *   4. Brand impersonation in hostname             → SCORES.BRAND_IMPERSONATION per matched brand
 *   5. Lookalike character substitution            → SCORES.LOOKALIKE_CHAR (generic + brand normalisation)
 *   6. Opaque/parameterised download path          → SCORES.OPAQUE_PATH
 *
 * Dropped vs. original sketch:
 *   - Brand name in path  (too much noise)
 *   - Urgency words in path (too much noise)
 *   - Special characters in hostname (too much noise)
 *   - Suspicious TLD (scored as a separate host-reputation check in ScoringEngineV2)
 *
 * V2.4.1: the generic lookalike-character check (item 5) was temporarily
 * disabled because it flagged legitimate trailing-digit hostnames like
 * "download3.operacdn.com" (numbered mirrors/CDN pool servers). Fixed and
 * re-enabled — see hasLookalikeChar() below for the corrected boundary rules.
 */
export const SketchyUrlCheck = (function () {

    // ── Score weights ──────────────────────────────────────────────────────────
    // All point contributions for this file's checks, gathered here per project
    // convention (single source of truth for magic numbers, with rationale).
    const SCORES = Object.freeze({
        PUNYCODE:             30, // xn-- prefix — homograph/lookalike domain trick
        EXCESSIVE_SUBDOMAINS: 10, // hostname has > 3 dot-separated labels
        BRAND_IMPERSONATION:  15, // per matched brand keyword, on a non-canonical host
        LOOKALIKE_CHAR:       15, // generic letter-substitution pattern, e.g. m1cr0s0ft
        OPAQUE_PATH:          20  // script endpoint / query-param delivery, no visible extension
    });

    // ── Brand table ────────────────────────────────────────────────────────────
    // canonical = the real hostname the brand owns.
    // Any host containing the keyword that is NOT the canonical or a subdomain
    // of it is flagged as impersonation.
    const BRANDS = [
        // Identity / OS / Productivity
        { keyword: "microsoft",     canonical: "microsoft.com"       },
        { keyword: "office",        canonical: "office.com"          },
        { keyword: "onedrive",      canonical: "onedrive.com"        },
        { keyword: "teams",         canonical: "teams.microsoft.com" },
        { keyword: "google",        canonical: "google.com"          },
        { keyword: "gmail",         canonical: "gmail.com"           },
        { keyword: "googledrive",   canonical: "drive.google.com"    },
        { keyword: "apple",         canonical: "apple.com"           },
        { keyword: "icloud",        canonical: "icloud.com"          },
        // E-commerce / Finance
        { keyword: "amazon",        canonical: "amazon.com"          },
        { keyword: "paypal",        canonical: "paypal.com"          },
        { keyword: "bankofamerica", canonical: "bankofamerica.com"   },
        { keyword: "hsbc",          canonical: "hsbc.com"            },
        { keyword: "revolut",       canonical: "revolut.com"         },
        // Social / Media
        { keyword: "meta",          canonical: "meta.com"            },
        { keyword: "facebook",      canonical: "facebook.com"        },
        { keyword: "instagram",     canonical: "instagram.com"       },
        { keyword: "netflix",       canonical: "netflix.com"         },
        { keyword: "spotify",       canonical: "spotify.com"         },
        { keyword: "linkedin",      canonical: "linkedin.com"        },
        // Productivity / Collaboration
        { keyword: "adobe",         canonical: "adobe.com"           },
        { keyword: "dropbox",       canonical: "dropbox.com"         },
        { keyword: "docusign",      canonical: "docusign.com"        },
        { keyword: "zoom",          canonical: "zoom.us"             },
        { keyword: "slack",         canonical: "slack.com"           },
        // Logistics
        { keyword: "fedex",         canonical: "fedex.com"           },
        { keyword: "dhl",           canonical: "dhl.com"             },
        { keyword: "ups",           canonical: "ups.com"             },
    ];

    // Characters visually similar to letters used in homograph/typosquatting attacks:
    // 0→o, 1→i/l, 3→e, 4→a, 5→s, 6→g, 8→b, @→a
    const LOOKALIKE_CHARS = new Set(["0", "1", "3", "4", "5", "6", "8", "@"]);

    // Separators that count as boundaries (like letter adjacency) for lookalike detection
    const SEPARATORS = new Set(["-", "_", ".", "~"]);

    // Lookalike normalisation map — maps substitute characters back to their
    // letter equivalents, both for brand matching (normaliseHost) and for
    // recognising plausible multi-character runs (LOOKALIKE_SEQUENCES below).
    const NORMALISE_MAP = {
        "0": "o",
        "1": "i",
        "3": "e",
        "4": "a",
        "5": "s",
        "6": "g",
        "8": "b",
        "@": "a"
    };

    // Common English letter-pairs that a *run* of 2+ lookalike characters is
    // allowed to represent (e.g. "00" → "oo" as in g00gle, "10" → "io" as in
    // prev10us). A single lookalike character is inherently letter-like on its
    // own and needs no such check; a run of 2+ digits is only meaningful if it
    // actually spells a plausible letter sequence — otherwise arbitrary digit
    // runs (version numbers, resolutions, IDs) would be flagged as noise.
    const LOOKALIKE_SEQUENCES = new Set(["oo", "ee", "ie", "ei", "oi", "io", "ea", "ai", "ia", "ss"]);

    /**
     * Returns true when the hostname contains a run of one or more lookalike
     * characters that is:
     *   - sandwiched between two letters (strongest signal — mid-word
     *     substitution, e.g. m1cr0s0ft, g00gle, prev10us), or
     *   - immediately after a separator (- _ . ~) or at the very start of the
     *     hostname, and immediately followed by a letter (start-of-label
     *     substitution, e.g. 0ffice365-login, p@ypal-secure), or
     *   - preceded by a letter and immediately followed by a hyphen,
     *     underscore, or tilde (still inside the same DNS label — e.g.
     *     paypa1-security.info), or by the absolute end of the hostname with
     *     no TLD following (unusual/malformed — worth flagging).
     *
     * A run of 2+ lookalike characters only counts when it normalises to a
     * plausible letter pair (LOOKALIKE_SEQUENCES) — this is what catches
     * "g00gle" without also flagging meaningless digit runs.
     *
     * Deliberately does NOT flag a lookalike run immediately before a literal
     * dot — that is a real DNS label boundary, and a trailing digit there is
     * extremely common in legitimate infrastructure naming (download3.,
     * cdn1., mirror2., s3.amazonaws.com, ns2.example.com) and reads as a
     * numeric suffix, not a letter substitution. Flagging that produced too
     * many false positives (see CHANGELOG V2.4.1). A trailing digit before a
     * hyphen (e.g. "app-v1-prod") can still occasionally be a legitimate
     * version-number idiom rather than an attack — a known precision/recall
     * trade-off of catching genuine cases like "paypa1-security.info".
     *
     * Flat +SCORES.LOOKALIKE_CHAR — does not stack per run.
     *
     * Examples that trigger:       1ink, m1cr0s0ft, g00gle, p@ypal-secure, paypa1-security
     * Examples that do NOT trigger: download3, cdn1, server2, s3 (in s3.amazonaws.com)
     */
    function hasLookalikeChar(host) {
        const chars = host.split("");
        let i = 0;

        while (i < chars.length) {
            if (!LOOKALIKE_CHARS.has(chars[i])) { i++; continue; }

            // Extend to the full contiguous run of lookalike characters.
            let end = i;
            while (end < chars.length && LOOKALIKE_CHARS.has(chars[end])) end++;

            const prev = i > 0          ? chars[i - 1] : null;
            const next = end < chars.length ? chars[end]  : null;

            const prevIsLetter      = prev !== null && /[a-z]/i.test(prev);
            const nextIsLetter      = next !== null && /[a-z]/i.test(next);
            const prevIsSeparator   = prev !== null && SEPARATORS.has(prev);
            const nextIsNonDotSep   = next !== null && SEPARATORS.has(next) && next !== ".";
            const atStart           = prev === null;
            const atEnd             = next === null;

            const runLength    = end - i;
            const normalisedRun = chars.slice(i, end).map(ch => NORMALISE_MAP[ch] || ch).join("");
            const isPlausibleRun = runLength === 1 || LOOKALIKE_SEQUENCES.has(normalisedRun);

            if (isPlausibleRun && (
                (prevIsLetter    && nextIsLetter)    ||  // sandwiched between letters
                (prevIsSeparator && nextIsLetter)    ||  // separator then letter
                (atStart         && nextIsLetter)    ||  // start of label, followed by letter
                (prevIsLetter    && nextIsNonDotSep) ||  // letter then hyphen/underscore/tilde
                (prevIsLetter    && atEnd)               // letter then absolute end (no TLD)
            )) {
                return true;
            }

            i = end; // advance past this run
        }
        return false;
    }

    /**
     * Normalise a hostname by replacing lookalike characters with their letter
     * equivalents. Used so brand checks catch e.g. "micr0s0ft" → "microsoft",
     * "p@ypal" → "paypal", "paypa1" → "paypayi" (close enough for includes()).
     */
    function normaliseHost(host) {
        return host.split("").map(ch => NORMALISE_MAP[ch] || ch).join("");
    }

    /**
     * Returns true when the host (or its normalised form) contains the brand
     * keyword but is NOT the canonical domain or a legitimate subdomain of it.
     */
    function isBrandImpersonation(host, brand) {
        const normHost = normaliseHost(host);
        const canon    = brand.canonical;
        const matchesOriginal   = host.includes(brand.keyword);
        const matchesNormalised = normHost.includes(brand.keyword);
        if (!matchesOriginal && !matchesNormalised) return false;
        return host !== canon && !host.endsWith("." + canon);
    }

    // ── Main function ──────────────────────────────────────────────────────────

    /**
     * Analyse a URL string for suspicious structural patterns.
     *
     * @param {string} inputUrl
     * @returns {{ score: number, signals: string[] }}
     *   score   — 0 (nothing suspicious) to 100 (maximally sketchy)
     *   signals — human-readable descriptions of triggered checks
     */
    function check(inputUrl) {
        let score     = 0;
        const signals = [];

        let url;
        try {
            url = new URL(inputUrl);
        } catch {
            // Unparseable URL — no score
            return { score: 0, signals: [] };
        }

        const host = url.hostname.toLowerCase();

        // ── 1. IP address — handled by IpAddressCheck in ScoringEngineV2 ──────

        // ── 2. Punycode ──────────────────────────────────────────────────────
        if (host.includes("xn--")) {
            score += SCORES.PUNYCODE;
            signals.push(`Punycode detected — possible lookalike domain (+${SCORES.PUNYCODE})`);
        }

        // ── 3. Excessive subdomains ──────────────────────────────────────────
        const parts = host.split(".");
        if (parts.length > 3) {
            score += SCORES.EXCESSIVE_SUBDOMAINS;
            signals.push(`Excessive subdomains: ${parts.length - 1} levels (+${SCORES.EXCESSIVE_SUBDOMAINS})`);
        }

        // ── 4. Brand impersonation ───────────────────────────────────────────
        for (const brand of BRANDS) {
            if (isBrandImpersonation(host, brand)) {
                score += SCORES.BRAND_IMPERSONATION;
                signals.push(`Brand impersonation: "${brand.keyword}" in hostname (+${SCORES.BRAND_IMPERSONATION})`);
            }
        }

        // Clamp before lookalike so headroom calculation is accurate
        score = Math.min(score, 100);

        // ── 5. Lookalike character substitution ──────────────────────────────
        // Generic check (re-enabled in V2.4.1 after fixing the trailing-digit
        // false positive — see hasLookalikeChar() docs). Independent of and
        // stacks with brand impersonation above: a lookalike-substituted brand
        // name (e.g. "micr0s0ft-updates.xyz") legitimately triggers both.
        if (hasLookalikeChar(host)) {
            score += SCORES.LOOKALIKE_CHAR;
            signals.push(`Lookalike character substitution in hostname (+${SCORES.LOOKALIKE_CHAR})`);
        }

        // ── 6. Opaque / parameterised download path ──────────────────────────
        // Legitimate software distribution almost always serves files with a
        // meaningful filename in the URL path (e.g. /files/setup.exe).
        // A path that ends in a script endpoint (?id=, .php, .aspx, /download)
        // with no filename extension is a common pattern for redirect-chain
        // malware delivery and drive-by downloads.
        // Skip check if the path already has a visible dangerous extension —
        // those are caught by the extension classifier, not this heuristic.
        const pathname = url.pathname.toLowerCase();
        const hasVisibleExt = /\.(exe|msi|bat|cmd|ps1|vbs|sh|py|rb|zip|rar|7z|iso|dmg|pkg|deb|rpm)$/.test(pathname);
        if (!hasVisibleExt) {
            const opaquePatterns = [
                /[?&](id|file|dl|download|token|key|hash)=/i,  // query param delivery
                /\/(download|dl|get|serve|fetch)(\/|$)/i,      // generic download endpoint
                /\.(php|aspx|asp|cfm|cgi|jsp)(\/|$|\?)/i,     // server-side script endpoint
            ];
            for (const pattern of opaquePatterns) {
                if (pattern.test(url.href)) {
                    score += SCORES.OPAQUE_PATH;
                    signals.push(`Opaque download path — file served via script or parameter (+${SCORES.OPAQUE_PATH})`);
                    break; // one signal per URL, no stacking
                }
            }
        }

        return { score: Math.max(0, Math.min(100, score)), signals };
    }

    return { check };

})();
