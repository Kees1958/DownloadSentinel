"use strict";

// ── PopupPage.js ──────────────────────────────────────────────────────────────
// Popup controller — displays extension and VT on/off state; routes to options.
//
// Public interface:
//   window.SentinelPopup.initialize()  — called on DOMContentLoaded
//
// State owned: none (all state is in chrome.storage via Settings)
// ─────────────────────────────────────────────────────────────────────────────

import { MSG } from "../../util/MessageTypes.js";
import { Settings } from "../../util/Settings.js";

window.SentinelPopup = window.SentinelPopup || (function () {

    // ── State helpers ──────────────────────────────────────────────────────────

    function getState(settings) {
        if (!settings.extensionEnabled) return "off";
        const hasKey = settings.isVtApiKeySet &&
                       settings.vtApiKey &&
                       settings.vtApiKey.trim() !== "";
        if (!hasKey || !settings.virusTotalEnabled) return "no-key";
        return "ready";
    }

    function hasApiKey(settings) {
        return !!(settings.isVtApiKeySet &&
                  settings.vtApiKey &&
                  settings.vtApiKey.trim() !== "");
    }

    // ── UI update ──────────────────────────────────────────────────────────────

    function applyUI(settings) {
        const state      = getState(settings);
        const banner     = document.getElementById("banner");
        const logo       = document.getElementById("logo");
        const sw         = document.getElementById("extSwitch");
        const statusLbl  = document.getElementById("extStatus");
        const optionsBtn = document.getElementById("optionsBtn");

        banner.className = "banner state-" + state;

        logo.src = settings.extensionEnabled
            ? "../../assets/icons/icon128.png"
            : "../../assets/icons/icon128_OFF.png";

        sw.className = "switch " + (settings.extensionEnabled ? "on" : "off");

        if (state === "off") {
            statusLbl.textContent = "download warning disabled";
            statusLbl.className   = "status-label inactive";
        } else {
            statusLbl.textContent = "download warning enabled";
            statusLbl.className   = "status-label";
        }

        optionsBtn.className = "options-btn";
        applyVtSwitch(settings);
    }

    // ── VT switch ──────────────────────────────────────────────────────────────

    function applyVtSwitch(settings) {
        const keyPresent = hasApiKey(settings);
        const enabled    = keyPresent && settings.virusTotalEnabled;

        const sw  = document.getElementById("vtSwitch");
        const lbl = document.getElementById("vtStatus");

        sw.className = "switch " +
            (enabled ? "on" : "off") +
            (keyPresent ? "" : " vt-locked");

        lbl.textContent = enabled
            ? "reputation check enabled"
            : "reputation check disabled";

        lbl.className = "status-label vt-label" + (enabled ? "" : " vt-disabled");
    }

    function bindVtSwitch() {
        document.getElementById("vtSwitch").addEventListener("click", () => {
            Settings.get(settings => {
                if (!hasApiKey(settings)) return;

                const newVal = !settings.virusTotalEnabled;
                Settings.set({ virusTotalEnabled: newVal }, () => {
                    chrome.runtime.sendMessage({ type: MSG.SETTINGS_UPDATED }).catch(() => {});
                    applyUI({ ...settings, virusTotalEnabled: newVal });
                });
            });
        });
    }

    // ── Main extension switch ──────────────────────────────────────────────────

    function bindSwitch() {
        document.getElementById("extSwitch").addEventListener("click", () => {
            Settings.get(settings => {
                const newEnabled = !settings.extensionEnabled;
                Settings.set({ extensionEnabled: newEnabled }, () => {
                    chrome.runtime.sendMessage({
                        type:    MSG.EXTENSION_TOGGLE,
                        enabled: newEnabled
                    }).catch(() => {});
                    applyUI({ ...settings, extensionEnabled: newEnabled });
                });
            });
        });
    }

    // ── Options button ────────────────────────────────────────────────────────

    function bindOptionsButton() {
        document.getElementById("optionsBtn").addEventListener("click", () => {
            chrome.runtime.openOptionsPage();
            window.close();
        });
    }

    // ── Init ──────────────────────────────────────────────────────────────────

    function initialize() {
        bindSwitch();
        bindVtSwitch();
        bindOptionsButton();
        Settings.get(settings => applyUI(settings));
    }

    return { initialize };
})();

document.addEventListener("DOMContentLoaded", () => {
    window.SentinelPopup.initialize();
});
