# Architecture — the DOCS / TOOLS / EXTENSION split (v2.10.0)

This document explains the three-way top-level restructure introduced in
v2.10.0: splitting the extension's frequently-edited filter/list data
(domains, TLDs, brand names, URL shorteners, host-risk entries) out of the
JS logic they're looked up through, into standalone JSON files.

See `DOCS/CHANGELOG.md`'s `## V2.10.0` entry for the release-note version of
this; this file is the living design reference.

> **v3.3.0 update (3P Matrix alignment item 18):** this restructure
> originally existed to ALSO enable a remote-refresh mechanism
> (`util/FilterDataLoader.js`) that could fetch updated JSON from this
> project's GitHub repo at runtime, changing the extension's live behavior
> without a new Chrome Web Store review. That mechanism has been removed
> entirely — every list below is now loaded exclusively from its
> compiled-in bundled default, the same as any other install, full stop.
> The DOCS/TOOLS/EXTENSION split and the JSON/`*.default.js` generation
> pipeline are kept regardless: they're a genuinely useful separation of
> data from logic for maintainability (editing a domain list is editing
> JSON, not JS), independent of whether anything ever fetches it remotely.
> The sections below describing the removed mechanism are kept as
> historical record, clearly marked, rather than deleted outright.

## Why the data/logic split exists

Even without a remote-fetch story, keeping the frequently-changing parts of
this extension — domain/TLD/host-risk lists, the brand list, the shortener
list — as standalone JSON rather than inline in the JS logic that reads
them keeps those two concerns (what's listed vs. how lookup works)
editable independently, and keeps jscpd/review diffs on a list change to
"a JSON file changed," not "a JS file changed."

## The three top-level directories

```
EXTENSION/   — everything that ships in the Chrome Web Store zip
TOOLS/       — everything NOT shipped: build/check scripts, tests, dev config
DOCS/        — all documentation
```

**`EXTENSION/` is the package root** — `manifest.json` stays at its top level
because Chrome loads a package from its own root; `TOOLS/` and `DOCS/` are
siblings to it at the repo root, never nested inside it.

```
EXTENSION/
  manifest.json
  background.js
  protection/          9 files — scoring/heuristics LOGIC, unchanged shape
  util/                logic + the 6 extracted data-module wrappers (below)
  data/                NEW — bundled JSON snapshots, single source of truth
  pages/                popup / options / warning UI
  assets/               icons

TOOLS/
  package.json, package-lock.json, node_modules/
  .eslintrc.json, .depcheckrc.json, knip.json, .gitignore
  tests/                unit tests (node --test) + fixtures + helpers
  tools/                complete-check.mjs, fp-sweep.mjs, update-lists.mjs,
                        gen-data-defaults.mjs, run-knip.mjs, repoPaths.mjs

DOCS/
  CHANGELOG.md
  ARCHITECTURE.md       this file
```

## The data extraction

Six modules were identified as genuinely **pure data** (no derived logic,
just lists/tables of domains, TLDs, or scores) and split into a JSON file
plus a thin logic wrapper:

| Module | Data file | Shape |
|---|---|---|
| `util/SuspiciousDomains.js` | `data/SuspiciousDomains.json` | `{ domain: score }` |
| `util/SuspiciousTlds.js` | `data/SuspiciousTlds.json` | `{ tld: score }` |
| `util/RiskyHostingSites.js` | `data/RiskyHostingSites.json` | `[{ host, score, exact }]` |
| `util/HostList.js` | `data/HostList.json` | `{ domain: { score, source } }` |
| `util/Brands.js` | `data/Brands.json` | `[{ keyword, domains, exceptions?, wholeNameOnly? }]` |
| `util/UrlShorteners.js` | `data/UrlShorteners.json` | `[domain, …]` |

`util/Brands.js` (v3.2.0, 3P Matrix alignment §2) replaces the earlier
`util/BrandDomains.js`/`BrandDomains.json` (a flat `[domain, …]` list, 22
entries) — one unified, richer brand table (539 keywords, regionally
extended) shared by `SketchyUrlCheck.js`'s direct/fuzzy brand matching and
`LookalikeDomainCheck.js`'s look-alike-variant matching. `data/GovSuffixes.json`
(shared government-registration suffixes like `gov.uk`) is consumed at
BUILD time by `tools/build-top-sites-filter.mjs` (folded into
`TopSitesFilter.json`), and, since v3.3.0 (3P Matrix alignment item 17),
also at RUNTIME via `util/GovSuffixes.js`, by
`LookalikeDomainCheck.js`'s gov-suffix exemption (an exact-suffix check the
lossy Bloom-filter union can't do). `util/PlatformSuffixes.js` and
`util/RdapCctlds.js` (v3.3.0, item 1) are two more flat list modules of
this same shape, consumed by `util/DomainAge.js`.

Each wrapper module now holds **only the lookup logic** (`lookup()`, or the
`.list`/`.set` convenience derivation for the two flat-array modules, shared
via `util/ListSetModule.js`'s factory). The data itself lives in
`EXTENSION/data/<Name>.json` — edit that JSON (and, for the two
hand-maintained brand/shortener lists, nothing else) to change what a module
matches.

**Left alone, deliberately:** `util/DangerousExts.js` and
`util/DangerousMimes.js` mix real data with *derived* logic
(`DangerousMimes.EXECUTABLE_MIMES` is computed from `MIME_TO_EXTS` at module
load, keyed against `DangerousExts.DANGEROUS`) — splitting them cleanly would
mean either shipping the derivation logic as "data" (defeating the point) or
a more invasive refactor than this pass's conservative scope calls for.
They're flagged here as a future candidate, not touched.

### The compiled-in default (`*.default.js`)

This is a vanilla, unbundled MV3 extension with no build step, and JSON
import syntax (import assertions/attributes) isn't used anywhere else in this
codebase. Rather than introduce that complexity for six files, each data
module's compiled-in default is a **generated** companion file —
`util/<Name>.default.js`, produced by `tools/gen-data-defaults.mjs` from
`data/<Name>.json` — containing the exact same data as a plain JS literal
export. Every consumer still writes the same `import { X } from "./X.js"` it
always has; only `X.js` itself now delegates its starting value to
`X.default.js`.

Run `node tools/gen-data-defaults.mjs` after hand-editing any
`data/<Name>.json` (e.g. adding a brand domain). `tools/update-lists.mjs`
(which regenerates `data/HostList.json` from the HaGeZi/Kees1958 upstream
lists, unchanged in purpose from pre-v2.10.0) calls this automatically at the
end of its own run, so a plain `node tools/update-lists.mjs` keeps both in
sync in one step.

## `util/FilterDataLoader.js` — REMOVED, v3.3.0 (3P Matrix alignment item 18)

> **This entire section describes a mechanism that no longer exists.** Kept
> for historical context (and because the removal rationale below is itself
> useful to a future reader wondering "why isn't there a remote-update
> story here"), not as current behavior.

The module used to do the following, for each of the modules above:

1. Did nothing extra at import time — each module already had its own
   bundled default active as soon as it was imported.
2. On `init()` (called once, unconditionally, from `background.js`'s
   startup path) and on a recurring `chrome.alarms` alarm, attempted to
   fetch that module's live JSON from this project's own GitHub repo
   (`raw.githubusercontent.com/Kees1958/uBol-stripped`).
3. Validated the shape of whatever came back before trusting it at all — a
   shape failure was just "don't apply this," never a thrown error.
4. Cached a validated fetch in `chrome.storage.local` with a timestamp.
5. Applied, in order of preference: a fresh, valid fetch → the
   last-known-good cached copy → the compiled-in default.

**Why it was removed, not just left dormant:** the data files were never
actually published at the path `REMOTE_BASE_URL` pointed to, so in
practice every fetch had 404'd since this mechanism's introduction — it
was dead weight carrying real costs with no working benefit: a
`host_permissions` entry reviewers have to reason about, a recurring
`chrome.alarms` wakeup, a `chrome.storage.local` cache layer, and a second
code path (remote JSON) for every one of the extracted lists that the
bundled default's own code path already had to handle correctly anyway.
3P Matrix's own design reached the same conclusion from the other
direction (publish the files and make the fetch real) — this project
instead chose to drop the mechanism entirely, on the view that a
compiled-in default refreshed through ordinary version releases is simpler
and no less maintainable than a live remote-fetch pipeline, for list data
that changes on the order of weeks, not hours.

## Adding a new extractable data list

1. Confirm it's genuinely pure data (see "Left alone, deliberately" above for
   the counter-example).
2. Add `EXTENSION/data/<Name>.json`.
3. Add `<Name>` to `tools/gen-data-defaults.mjs`'s `MODULES` list; run it.
4. Write `util/<Name>.js` importing `<Name>Default` from `./<Name>.default.js`,
   exposing whatever lookup shape its consumers need, plus `setData()` and
   `resetToDefault()` for tests (or use `util/ListSetModule.js`'s factory if
   the shape is a flat list exposed as `.list`/`.set`).
5. Add a unit test file, same pattern as every other module here.
