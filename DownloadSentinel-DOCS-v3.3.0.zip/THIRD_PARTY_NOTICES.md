# Third-Party Notices

DownloadSentinel's own code (everything under `EXTENSION/protection/`,
`EXTENSION/util/`, `EXTENSION/pages/`, `EXTENSION/background.js`, and all of
`TOOLS/`) is first-party, written for this project — there is no vendored or
bundled third-party **code** anywhere in the shipped extension (verified
v3.3.0: no `node_modules`, vendor directories, or minified bundles exist
under `EXTENSION/`).

What this project *does* bundle is derived **data** — build-time tooling
(`TOOLS/tools/update-*.mjs`) fetches a handful of external lists and bakes a
compiled snapshot into `EXTENSION/data/*.json` (compiled further into
`EXTENSION/util/*.default.js` by `gen-data-defaults.mjs`). This file is the
single place that tracks what those sources are and what license applies, so
it doesn't only live in `TOOLS/data-sources.json`'s per-entry comments. The
authoritative, machine-readable version of this table is
`TOOLS/data-sources.json`; this doc is the human-readable summary.

| Source | License | Feeds | Shipped form | Notes |
|---|---|---|---|---|
| [HaGeZi `dns-blocklists`](https://github.com/hagezi/dns-blocklists) (DynDNS + Badware Hoster lists) | **GPL-3.0**, explicitly confirmed 2026-10-21 against the repo's own "Redistribution and licensing" disclaimer (quoted below) | `EXTENSION/data/HostList.json` | Literal, enumerable domain names (merged into the ~2,642-entry list) | License text now accompanies this redistribution (`DOCS/THIRD_PARTY_LICENSES/GPL-3.0.txt`) per the repo's own stated requirement. **One question still open — see below.** |
| [Kees1958 `W3C_annual_most_used_survey_blocklist`](https://github.com/Kees1958/W3C_annual_most_used_survey_blocklist) ("Suspicious websites" list) | No LICENSE file found in the repo | `EXTENSION/data/HostList.json` | Literal, enumerable domain names | Same GitHub account as this project — not a third party in the usual sense, but still unlicensed data; worth a LICENSE file in that repo too if it's meant to be reused. |
| [Public Suffix List](https://github.com/publicsuffix/list) | MPL-2.0 | `EXTENSION/data/PublicSuffixList.json`, `EXTENSION/data/PlatformSuffixes.json` | Extracted suffix/ccTLD strings | MPL-2.0 is designed for exactly this kind of data reuse; no action needed. |
| [CrUX top sites](https://github.com/zakird/crux-top-lists) (underlying data: Google's Chrome UX Report, ODbL) | Repo license unverified; underlying CrUX dataset is ODbL | `EXTENSION/data/TopSitesFilter.json` | **One-way Bloom filter** (80,140 entries compressed into a 768,147-bit hash) — not an extractable or enumerable copy of the source list | Low risk: the shipped artifact can only answer "is X probably a member," it cannot reconstruct the source list. |
| IANA RDAP bootstrap registry | Public registry data, not copyrighted | `EXTENSION/data/RdapCctlds.json` | Extracted ccTLD list | No action needed. |
| Brands / regional brand table | n/a — hand-curated by this project | `EXTENSION/data/Brands.json`, `EXTENSION/data/GovSuffixes.json` | — | Not an external source. |

## HaGeZi's own license disclaimer (confirmed 2026-10-21)

Directly from `https://github.com/hagezi/dns-blocklists`'s README, under
"Redistribution and licensing" (quoted in full, since it is the controlling
text for how `HostList.json` may use this data):

> **Redistribution and licensing.** The Lists are published under the
> [GNU General Public License v3.0 (GPL-3.0)](https://github.com/hagezi/dns-blocklists/blob/main/LICENSE).
> A copy of the license is included in this repository and has to accompany
> any redistribution. You may redistribute, modify, and adapt the Lists
> only under the terms of that license. This disclaimer applies in addition
> to, and does not replace, the warranty and liability terms already
> contained in the GPL-3.0 (Sections 15 to 17). Some inputs come from
> third-party sources with their own licenses or terms of use. GPL-3.0
> covers the Lists as published here; it doesn't hand you any rights in the
> upstream data itself, so if you build on that data directly, checking
> those terms is on you. It's on you to read, understand, and follow the
> license terms before using or redistributing anything.

What this confirms and what it leaves open:

- **Confirmed, and acted on:** redistribution must be "only under the
  terms of" GPL-3.0, and "a copy of the license... has to accompany any
  redistribution." That copy now lives at
  `DOCS/THIRD_PARTY_LICENSES/GPL-3.0.txt` (fetched verbatim from the
  canonical SPDX license-text source, matching `gnu.org/licenses/gpl-3.0.txt`)
  and this notices file documents the source and the obligation. That is
  the mechanical, non-judgment-call part of compliance, and it's done.
- **Still open — a legal judgment, not a mechanical one:** whether merging
  ~2,642 extracted domain names into `HostList.json`, inside a
  Chrome extension whose own code is unlicensed/private, satisfies "only
  under the terms of that license" — i.e. whether GPL-3.0's copyleft
  extends to this project's own combined work, or whether a plain list of
  domain names (as opposed to the generator code around it) is the kind of
  "copy" GPL-3.0's redistribution terms are really aimed at. HaGeZi's own
  text explicitly declines to answer this for you ("it's on you to read,
  understand, and follow the license terms"). If you want certainty rather
  than a reasonable-effort interpretation, ask HaGeZi directly (a GitHub
  issue is the obvious channel) or get it checked by someone qualified to
  read GPL-3.0's copyleft scope for this exact situation — a plain list of
  facts/domain names arranged by someone else's selection, bundled into a
  separately-licensed codebase.
- **Cheap fallback if the answer is unclear or no:** drop HaGeZi as a
  `HostList.json` source (a one-line change to `TOOLS/tools/update-lists.mjs`'s
  `SOURCES` array) or replace it with a differently-licensed equivalent
  blocklist — this is a content/build-config change, not an architecture
  change.
