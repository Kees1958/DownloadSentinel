#!/usr/bin/env node
// ── tools/update-domain-age-lists.mjs ────────────────────────────────────────────
// Rebuilds the two lists that tell the domain-age (RDAP) check when a lookup cannot give an answer, so
// it is skipped instead of failing. Since 4.3.4 they are DownloadSentinel 3.3.0's own list modules
// (lib/downloadsentinel/util/DomainAge.js — one rule for site and download checks), so this tool writes
// DS's generated format byte for byte (only the "Generated:" line differs from a DS rebuild):
//   lib/downloadsentinel/util/PlatformSuffixes.default.js — the PRIVATE section of the Public Suffix List:
//        platforms where anyone gets a subdomain (github.io, blogspot.com, pages.dev …). The registry only
//        knows the platform, never the user's site → no age for the site.
//   lib/downloadsentinel/util/RdapCctlds.default.js — the two-letter country-code TLDs that HAVE an RDAP
//        service, from IANA's RDAP bootstrap file (dns.json). A ccTLD not listed (de, it, es, ch, jp …) has
//        no RDAP → no age. Every gTLD has RDAP (ICANN contract) → always asked.
// Same arrangement as update-top-sites.mjs (also writes into lib). DownloadSentinel rebuilds the same lists
// with its own tool; whichever runs, the data is the same.
// Records both in data-sources.json (updateOn "minor", like the top-sites list).
//
// Usage:  node update-domain-age-lists.mjs [--extension ../3P-Matrix] [--psl public_suffix_list.dat]
//                                          [--rdap dns.json]
//         Without --psl / --rdap the files are downloaded from the register's "source" URLs.
// Exit:   0 = written · 1 = refused (sanity guard) · 2 = did not run (download/parse/folder)
// ─────────────────────────────────────────────────────────────────────────────

import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { join, resolve, dirname } from "node:path";
import { fileURLToPath } from "node:url";

// ── Settings (one place) ─────────────────────────────────────────────────────
const HERE = dirname(fileURLToPath(import.meta.url));
const EXIT = Object.freeze({ OK: 0, REFUSED: 1, DID_NOT_RUN: 2 });
const REGISTER_FILE = join(HERE, "data-sources.json");
const DEFAULT_EXTENSION = join(HERE, "..", "3P-Matrix");
const LIST = Object.freeze({ PLATFORMS: "platform-suffixes", RDAP: "rdap-cctlds" });
const PSL_BEGIN_PRIVATE = "===BEGIN PRIVATE DOMAINS===";
const PSL_END_PRIVATE = "===END PRIVATE DOMAINS===";
const PSL_COMMENT = "//";
const PSL_EXCEPTION = "!";                                  // exception rules: none matter for platforms
const PSL_WILDCARD = "*.";
const PSL_VERSION_RE = /^\/\/ VERSION: (\S+)/m;
const CCTLD_RE = /^[a-z]{2}$/;
const MIN_PLATFORMS = 2000;                                  // guard (2026-10: 3,4xx rules)
const MIN_RDAP_CCTLDS = 40;                                  // guard (2026-09-30: 72)
const PLATFORMS_MUST = Object.freeze(["github.io", "blogspot.com", "pages.dev"]);
const RDAP_MUST = Object.freeze(["fr", "nl", "uk"]);
const RDAP_MUST_NOT = Object.freeze(["de", "com"]);          // de: no RDAP service; com: a gTLD, never listed here
const JSON_INDENT = 2;
const JSON_LIST_INDENT = 4;                                  // DownloadSentinel's generated-file indent
const MODULE = Object.freeze({ PLATFORMS: "PlatformSuffixes", RDAP: "RdapCctlds" });   // DS module names
const DATE_LENGTH = 10;                                      // "YYYY-MM-DD" of an ISO timestamp
const VERSION_MINOR_RE = /^(\d+\.\d+)/;

function didNotRun(msg) { console.error(`update-domain-age-lists: DID NOT RUN — ${msg}`); process.exit(EXIT.DID_NOT_RUN); }
function refuse(msg) { console.error(`update-domain-age-lists: REFUSED — ${msg}`); process.exit(EXIT.REFUSED); }
function arg(name) { const i = process.argv.indexOf(`--${name}`); return i === -1 ? null : process.argv[i + 1]; }

async function readSource(file, url) {
  if (file) {
    if (!existsSync(file)) didNotRun(`input not found: ${file}`);
    return readFileSync(file, "utf8");
  }
  try {
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.text();
  } catch (e) {
    didNotRun(`download failed (${e.message}) — download ${url} yourself and pass it as input`);
  }
  return "";                                                 // unreachable (didNotRun exits)
}

// A rule as the URL API reports host names (punycode); a leading "*." wildcard is kept.
function toAscii(rule) {
  const wild = rule.startsWith(PSL_WILDCARD);
  const ascii = new URL(`http://${wild ? rule.slice(PSL_WILDCARD.length) : rule}/`).hostname;
  return wild ? PSL_WILDCARD + ascii : ascii;
}

function parsePrivate(text) {
  const begin = text.indexOf(PSL_BEGIN_PRIVATE), end = text.indexOf(PSL_END_PRIVATE);
  if (begin === -1 || end === -1) didNotRun("no PRIVATE DOMAINS section in the Public Suffix List");
  const rules = new Set();
  for (const raw of text.slice(text.indexOf("\n", begin), end).split(/\r?\n/)) {   // after the marker line
    const line = raw.trim().toLowerCase();
    if (!line || line.startsWith(PSL_COMMENT) || line.startsWith(PSL_EXCEPTION)) continue;
    rules.add(toAscii(line));
  }
  const m = PSL_VERSION_RE.exec(text);
  return { rules: [...rules].sort(), release: m ? m[1] : `retrieved ${new Date().toISOString().slice(0, DATE_LENGTH)}` };   // the list has no version line
}

function parseRdap(text) {
  let json;
  try { json = JSON.parse(text); } catch (e) { didNotRun(`dns.json is not JSON: ${e.message}`); }
  const tlds = new Set();
  for (const service of json.services || []) for (const tld of service[0] || []) if (CCTLD_RE.test(tld)) tlds.add(tld);
  return { tlds: [...tlds].sort(), release: json.publication || "unknown" };
}

// DownloadSentinel's generated-file format (util/<Module>.default.js) — kept identical so lib stays DS's.
function render(module, generatedAt, list) {
  return `"use strict";

/**
 * ${module}.default.js — GENERATED FILE. Do not hand-edit; run
 * \`node tools/gen-data-defaults.mjs\` to regenerate from the single source
 * of truth, EXTENSION/data/${module}.json.
 *
 * This is the bundled/offline default: compiled into the reviewed CWS
 * package, so ${module} always has a safe starting value from first install
 * onward. v3.3.0 (3P Matrix alignment item 18) — this is the ONLY source
 * ${module} is ever loaded from; the remote-refresh mechanism that used to
 * sit in front of it (util/FilterDataLoader.js) was removed, so there is
 * no fetch/cache fallback chain to describe here anymore — just this file.
 *
 * Generated: ${generatedAt}
 */
export const ${module}Default = ${JSON.stringify(list, null, JSON_LIST_INDENT)};
`;
}

async function main() {
  const ext = resolve(arg("extension") || DEFAULT_EXTENSION);
  if (!existsSync(join(ext, "manifest.json"))) didNotRun(`not an extension folder: ${ext}`);
  let registerFile;
  try { registerFile = JSON.parse(readFileSync(REGISTER_FILE, "utf8")); } catch (e) { didNotRun(`cannot read ${REGISTER_FILE}: ${e.message}`); }
  const regP = registerFile.lists[LIST.PLATFORMS], regR = registerFile.lists[LIST.RDAP];
  if (!regP || !regR) didNotRun(`data-sources.json needs "${LIST.PLATFORMS}" and "${LIST.RDAP}" entries`);

  const platforms = parsePrivate(await readSource(arg("psl"), regP.source));
  const rdap = parseRdap(await readSource(arg("rdap"), regR.source));
  if (platforms.rules.length < MIN_PLATFORMS) refuse(`only ${platforms.rules.length} platform rules (expected ≥ ${MIN_PLATFORMS})`);
  if (rdap.tlds.length < MIN_RDAP_CCTLDS) refuse(`only ${rdap.tlds.length} ccTLDs with RDAP (expected ≥ ${MIN_RDAP_CCTLDS})`);
  const missing = PLATFORMS_MUST.filter((p) => !platforms.rules.includes(p)).concat(RDAP_MUST.filter((t) => !rdap.tlds.includes(t)));
  const wrong = RDAP_MUST_NOT.filter((t) => rdap.tlds.includes(t));
  if (missing.length || wrong.length) refuse(`sanity check failed — missing: ${missing.join(", ") || "none"}; unexpected: ${wrong.join(", ") || "none"}`);

  const generatedAt = new Date().toISOString();
  writeFileSync(join(ext, regP.file), render(MODULE.PLATFORMS, generatedAt, platforms.rules));
  writeFileSync(join(ext, regR.file), render(MODULE.RDAP, generatedAt, rdap.tlds));

  const manifest = JSON.parse(readFileSync(join(ext, "manifest.json"), "utf8"));
  const versionMinor = (VERSION_MINOR_RE.exec(manifest.version) || [])[1] || manifest.version;
  const today = new Date().toISOString().slice(0, DATE_LENGTH);
  Object.assign(regP, { sourceRelease: platforms.release, entries: platforms.rules.length, updatedForVersion: versionMinor, updatedAt: today });
  Object.assign(regR, { sourceRelease: rdap.release, entries: rdap.tlds.length, updatedForVersion: versionMinor, updatedAt: today });
  writeFileSync(REGISTER_FILE, JSON.stringify(registerFile, null, JSON_INDENT) + "\n");
  console.log(`update-domain-age-lists: ${platforms.rules.length} platform suffixes (PSL ${platforms.release}), ` +
              `${rdap.tlds.length} ccTLDs with RDAP (IANA ${rdap.release}), recorded for ${versionMinor}`);
  process.exit(EXIT.OK);
}

await main();
